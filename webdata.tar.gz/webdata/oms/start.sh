omspath="/data/webdata/oms"

cd $omspath/oms/uxin/views/

ps -ef | grep uwsgi | grep -v grep | awk '{print $2}'  |  xargs kill -9
#uwsgi --ini /home/wanglong/python/oms/oms/uwsig.ini
/usr/sbin/uwsgi -s 127.0.0.1:9000 -t 120  -M -p 4 -C -w wsgi  \
--pidfile $omspath/oms/logs/uwsgi.pid \
--logdate --pp $omspath/oms \
-d $omspath/oms/logs/run.log


ps -ef | grep shellinaboxd | grep -v grep | awk '{print $2}' | xargs kill -9
cd $omspath/oms/shellinabox/bin ;./shellinaboxd -t -b -q --localhost-only -p 1105 --css=white-on-black.css

ps -ef | grep 'websockify.*5909' | grep -v grep | awk '{print $2}' |xargs kill -9
nohup $omspath/oms/VNC/utils/launch.sh --listen 1202 --vnc 121.201.59.73:5909  >> $omspath/oms/logs/vnc &
find $omspath -name '*.pyc' | grep -v passwd.pyc | xargs rm -rf
