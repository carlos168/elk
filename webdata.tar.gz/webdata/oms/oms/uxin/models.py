#-*- coding:UTF-8 -*-
from django.db import models

# Create your models here.



class Devbase(models.Model):
  cabinet = models.CharField(max_length=20,blank=True)
  project = models.CharField(max_length=20,blank=True)
  subprojects = models.CharField(max_length=20,blank=True)
  brand = models.CharField(max_length=20,blank=True)
  srvmodel = models.CharField(max_length=500,blank=True)
  cconfig = models.CharField(max_length=300,blank=True)
  distributor = models.CharField(max_length=20,blank=True)
  riskowner  = models.CharField(max_length=20,blank=True)
  sconfig = models.CharField(max_length=300,blank=True)

  def __unicode__(self):
      return self.cabinet


class Device(models.Model):    
  wanip = models.IPAddressField()
  lanip = models.IPAddressField()
  mip = models.IPAddressField()
  mroom = models.CharField(max_length=20)
  cabinet = models.CharField(max_length=20)
  project = models.CharField(max_length=20)
  runsrv = models.CharField(max_length=10000)
  brand = models.CharField(max_length=20)
  srvmodel = models.CharField(max_length=500)
  cconfig = models.CharField(max_length=500)
  riskowner  = models.CharField(max_length=20)
  purchased = models.CharField(max_length=50)
  usedate = models.CharField(max_length=50)
  distributor = models.CharField(max_length=20)
  contractsn = models.CharField(max_length=50)
  price = models.CharField(max_length=50)
  servicesn = models.CharField(max_length=50)
  subprojects = models.CharField(max_length=20)
  exp       = models.CharField(max_length=50)
  stats = models.CharField(max_length=50)
  machine_type =  models.CharField(max_length=50)  
  remarks =  models.CharField(max_length=1000)
  systemcheck = models.TextField(max_length=50000)
  device_port = models.TextField(max_length=50)
  bakpath = models.TextField(max_length=50000)
  baklog = models.TextField(max_length=50000)
  bakipaddr = models.TextField(max_length=50000)
  def __unicode__(self):
      return self.wanip



class Idc(models.Model):
  mroom = models.CharField(max_length=100)
  compactno = models.CharField(max_length=100)
  compactlimit  = models.CharField(max_length=100)
  validdate = models.CharField(max_length=100)  
  invaliddate = models.CharField(max_length=100) 
  monthfee = models.CharField(max_length=100)   
  comtactclient = models.CharField(max_length=500) 
  comtactoperation = models.CharField(max_length=500)
  addr = models.CharField(max_length=500)
  ipnet = models.CharField(max_length=500)
  remark = models.CharField(max_length=500)

  def __unicode__(self):
      return self.mroom

class Domain(models.Model):
  domain_name = models.CharField(max_length=100)
  domain_use = models.CharField(max_length=100)
  valid_date  = models.CharField(max_length=100)
  reg = models.CharField(max_length=100)
  parsing = models.CharField(max_length=100)
  register_no = models.CharField(max_length=100)
  record_type = models.CharField(max_length=100)
  remark = models.CharField(max_length=500)
  username = models.CharField(max_length=100)
  passwd = models.CharField(max_length=100)
  company = models.CharField(max_length=100)
  Real_time = models.CharField(max_length=1000)
  delete_time = models.CharField(max_length=100)

  def __unicode__(self):
      return self.domain_name

class Link (models.Model):
  name= models.CharField(max_length=50)
  link = models.CharField(max_length=200)
  username = models.CharField(max_length=20)
  password = models.CharField(max_length=40)

  def __unicode__(self):
      return self.name




class Alarm_email (models.Model):
  smtp_server = models.CharField(max_length=50)
  smtp_user = models.CharField(max_length=50)
  smtp_pass = models.CharField(max_length=50)
  test_send = models.CharField(max_length=50)
  test_title = models.CharField(max_length=50)
  test_text = models.CharField(max_length=500)


  def __unicode__(self):
      return self.smtp_user



class Alarm_sms (models.Model):
  sms_server = models.CharField(max_length=5000)
  sms_user = models.CharField(max_length=500)
  sms_pass = models.CharField(max_length=500)
  test_send = models.CharField(max_length=500)
  test_text = models.CharField(max_length=500)


  def __unicode__(self):
      return self.sms_user


class Alarm_grp (models.Model):
  alarm_type = models.CharField(max_length=50)
  alarm_name = models.CharField(max_length=50)
  alarm_count = models.CharField(max_length=5000)


  def __unicode__(self):
      return self.alarm_type



class Alarm_weixin (models.Model):
  wx_name = models.CharField(max_length=50)
  wx_department = models.CharField(max_length=100)
  wx_phone = models.CharField(max_length=50)
  wx_mail = models.CharField(max_length=50)
  wx_uid = models.CharField(max_length=50)

  def __unicode__(self):
      return self.wx_name




   
class Alarm (models.Model):
  Alarm_type = models.CharField(max_length=50)
  Alarm_ip = models.CharField(max_length=50)
  Alarm_name = models.CharField(max_length=50)
  Alarm_server = models.CharField(max_length=1500)
  Alarm_frequency = models.CharField(max_length=50)
  Alarm_email_num = models.CharField(max_length=50)
  alarm_phone = models.CharField(max_length=50)
  Alarm_num = models.CharField(max_length=50)
  Alarm_retry = models.CharField(max_length=50)
  last_time = models.CharField(max_length=50)
  last_result = models.CharField(max_length=1500)
  next_time = models.CharField(max_length=50)
  fail_count = models.CharField(max_length=50)
  remarks = models.CharField(max_length=50)
  Alarm_state = models.CharField(max_length=50)
  diff_web = models.CharField(max_length=50)
  notify_object = models.CharField(max_length=500)
  status=models.CharField(max_length=10)
  base_check=models.CharField(max_length=10)
  lock_status=models.CharField(max_length=10)
  notify_object_weixin = models.CharField(max_length=50000)
  error_start_time = models.CharField(max_length=50)

  def __unicode__(self):
      return self.Alarm_type


class Alarm_log (models.Model):

  ip = models.CharField(max_length=50)
  name = models.CharField(max_length=30)
  date = models.CharField(max_length=50)
  text = models.CharField(max_length=500)
  status = models.CharField(max_length=50)

  def __unicode__(self):
      return self.ip



class Systeminit_log (models.Model):

  ip = models.CharField(max_length=50)
  date = models.CharField(max_length=50)
  enddate = models.CharField(max_length=50)
  text = models.CharField(max_length=500)
  user = models.CharField(max_length=50)
  in_device = models.CharField(max_length=50)

  def __unicode__(self):
      return self.ip





class permissions_list (models.Model):

  permissions = models.CharField(max_length=5000)

  def __unicode__(self):
      return self.permissions




class permissions_user (models.Model):

  username = models.CharField(max_length=50)
  permissions_list = models.CharField(max_length=5000)
  group = models.CharField(max_length=50)

  def __unicode__(self):
      return self.username

class permissions_group (models.Model):

  groupname = models.CharField(max_length=50)
  permissions_list = models.CharField(max_length=5000)
  def __unicode__(self):
      return self.groupname



class Switch(models.Model):
  mip = models.IPAddressField()
  mroom = models.CharField(max_length=20)
  cabinet = models.CharField(max_length=20)
  brand = models.CharField(max_length=20)
  runsrv = models.CharField(max_length=10000)
  srvmodel = models.CharField(max_length=500)
  cconfig = models.CharField(max_length=500)
  riskowner  = models.CharField(max_length=20)
  purchased = models.CharField(max_length=50)
  usedate = models.CharField(max_length=50)
  price = models.CharField(max_length=50)
  servicesn = models.CharField(max_length=50)
  exp       = models.CharField(max_length=50)
  stats = models.CharField(max_length=50)
  remarks =  models.CharField(max_length=1000)
  password =  models.CharField(max_length=100)
  def __unicode__(self):
      return self.mip


class Mysql(models.Model):
  ipaddr = models.IPAddressField()
  port = models.CharField(max_length=20)
  mysql_user = models.CharField(max_length=20)
  password = models.CharField(max_length=200)
  version = models.CharField(max_length=500)
  pm = models.CharField(max_length=500)
  remark = models.CharField(max_length=10000)
  mysqlcheck  = models.CharField(max_length=50000)
  audit = models.CharField(max_length=500)
  def __unicode__(self):
      return self.ipaddr


class Automation(models.Model):
  appname = models.CharField(max_length=2000)
  remark = models.CharField(max_length=2000)
  adddate = models.CharField(max_length=200)
  lastdate = models.CharField(max_length=200)
  role = models.CharField(max_length=30)
  updatever = models.CharField(max_length=30)
  updatestatus = models.CharField(max_length=30)
  def __unicode__(self):
      return self.appname


#部署什么类型的软件 【远程机器YAML文件】
class Automation_device_type(models.Model):
  typename = models.CharField(max_length=2000)
  typepath = models.CharField(max_length=2000)
  def __unicode__(self):
      return self.typename


class Automation_log(models.Model):
  appname = models.CharField(max_length=200)
  appversion = models.CharField(max_length=200)
  data_type = models.CharField(max_length=200)
  filename = models.CharField(max_length=200)
  auto_type = models.CharField(max_length=200)
  lastdate = models.CharField(max_length=200)
  role = models.CharField(max_length=30)
  ip = models.CharField(max_length=30)
  status = models.CharField(max_length=30)
  remark = models.CharField(max_length=2000)
  result = models.CharField(max_length=2000)
  def __unicode__(self):
      return self.appname

class Automation_version(models.Model):
  appname = models.CharField(max_length=50)
  appversion = models.CharField(max_length=50)
  data_type = models.CharField(max_length=2000)
  download_addr = models.CharField(max_length=2000)
  username = models.CharField(max_length=200)
  password = models.CharField(max_length=200)
  remark = models.CharField(max_length=2000)
  adddate = models.CharField(max_length=200)
  filename = models.CharField(max_length=200)
  filepath = models.CharField(max_length=200)
  def __unicode__(self):
      return self.appname

#部署界面
class Automatic_deployment(models.Model):
  appname = models.CharField(max_length=25)
  appversion = models.CharField(max_length=25)
  auto_type = models.CharField(max_length=2000)
  auto_mode = models.CharField(max_length=2000)
  auto_device = models.CharField(max_length=5000)
  remark = models.CharField(max_length=2000)
  autodate = models.CharField(max_length=200)
  lastdate = models.CharField(max_length=30)
  parameters = models.CharField(max_length=5000)
  def __unicode__(self):
      return self.appname


class Auto_cluster(models.Model):
  cluster_name = models.CharField(max_length=500)
  def __unicode__(self):
      return self.cluster_name


class Auto_cluster_device(models.Model):
  cluster_name = models.CharField(max_length=50)
  wanip= models.CharField(max_length=50)
  def __unicode__(self):
      return self.cluster_name


class Automation_device_set(models.Model):
  ipaddr = models.CharField(max_length=50)
  port = models.CharField(max_length=50)
  username = models.CharField(max_length=50)
  passwd = models.CharField(max_length=500)

  def __unicode__(self):
      return self.ipaddr
