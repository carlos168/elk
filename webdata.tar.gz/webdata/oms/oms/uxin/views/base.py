#!/usr/bin/env python
#-*- coding:UTF-8 -*-
from django.http import *
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.contrib.auth.decorators import login_required
from django.utils import simplejson
from uxin.models import *
from django.conf import settings
from django.contrib.auth.models import User

from django.template import loader, RequestContext

from dbutil import *
from tool import *
from LogLib import *


@login_required()
def Addbase(request):
    User=request.user.username
    if permissions_check(User,'device_base_add') != True:
        return render_to_response('permissions_error.html')
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST' or request.GET:
        n = request.REQUEST.get('STATE')
	l = request.REQUEST.get('line')

        INFO = {}
        Tuple = ('cabinet','project','brand','cconfig','distributor','riskowner','subprojects','srvmodel','sconfig')
 	
	if l:
	    for i in  Tuple:
		if i==n:
		    INFO[i]=l
		    cmd = '''Devbase.objects.raw('select id,%s from uxin_devbase where %s !=""')''' %(i,i)
		    #判断数据是否存在
		    diff="Devbase.objects.filter(%s='%s')" %(i,l)
		    diff=eval(diff)
		    if diff:
		        return render_to_response('addbase.html',{'error':'数据已经存在','User':User,n:'i'})
			
		    
		else:
		    INFO[i]=''

            DBDA = Devbase(cabinet=INFO['cabinet'],project=INFO['project'],brand=INFO['brand'],\
                           cconfig=INFO['cconfig'],distributor=INFO['distributor'],riskowner=INFO['riskowner'],\
                           subprojects=INFO['subprojects'],srvmodel=INFO['srvmodel'],sconfig=INFO['sconfig'])	
            DBDA.save()
	    log_info("登陆用户:" + str(User) + " 新增基础数据:" +str(l) + " 成功")

            Results = eval(cmd)
            return render_to_response('chabase.html',{'DBDA':'INFO','results':Results,'User':User,n:'i'},context_instance=RequestContext(request))


        else:
	    return render_to_response('addbase.html',{'User':User,n:'i'})
    return render_to_response('addbase.html',{'User':User},context_instance=RequestContext(request))


@login_required()
def Chabase(request):
    User=request.user.username
    if permissions_check(User,'device_base_view') != True:
        return render_to_response('permissions_error.html')
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST':
        name = request.REQUEST.get('STATE')
        MDID = request.REQUEST.get('MDID')
        DLID = request.REQUEST.get('DLID')
        Change = request.REQUEST.get('Change')

	INFO = {}
	Tuple = ('cabinet','project','brand','cconfig','distributor','riskowner','subprojects','srvmodel','sconfig')

        for i in Tuple:
            INFO[i] = request.REQUEST.get(i)

        if Change and MDID:
     
            
            
#            INFO = {}
#	    Tuple = ('cabinet','project','brand','cconfig','distributor','riskowner','subprojects','srvmodel')
            for i in Tuple:
                INFO[i] = request.REQUEST.get(i)


		#修改基础数据，关键修改设备
                if INFO[i] and INFO[i] != "":
		    p = Devbase.objects.get(id=MDID)
	 	    if p.cabinet and p.cabinet != "":
				sql='update uxin_device set cabinet="%s" where cabinet="%s";' %(INFO[i],p.cabinet)
	                        sql=sql.encode("utf-8")
			        device_update(sql)
                    if p.project and p.project != "":
                                sql='update uxin_device set project="%s" where project="%s";' %(INFO[i],p.project)
                                sql=sql.encode("utf-8")
                                device_update(sql)
                    if p.brand and p.brand != "":
                                sql='update uxin_device set brand="%s" where brand="%s";' %(INFO[i],p.brand)
                                sql=sql.encode("utf-8")
                                device_update(sql)
                    if p.cconfig and p.cconfig != "":
                                sql='update uxin_device set cconfig="%s" where cconfig="%s";' %(INFO[i],p.cconfig)
                                sql=sql.encode("utf-8")
                                device_update(sql)
                    if p.distributor and p.distributor != "":
                                sql='update uxin_device set distributor="%s" where distributor="%s";' %(INFO[i],p.distributor)
                                sql=sql.encode("utf-8")
                                device_update(sql)
                    if p.riskowner and p.riskowner != "":
                                sql='update uxin_device set riskowner="%s" where riskowner="%s";' %(INFO[i],p.riskowner)
                                sql=sql.encode("utf-8")
                                device_update(sql)
                    if p.subprojects and p.subprojects != "":
                                sql='update uxin_device set subprojects="%s" where subprojects="%s";' %(INFO[i],p.subprojects)
                                sql=sql.encode("utf-8")
                                device_update(sql)

                    if p.srvmodel and p.srvmodel != "":
                                sql='update uxin_device set srvmodel="%s" where srvmodel="%s";' %(INFO[i],p.srvmodel)
                                sql=sql.encode("utf-8")
                                device_update(sql)
                    if p.srvmodel and p.srvmodel != "":
                                sql='update uxin_device set srvmodel="%s" where sconfig="%s";' %(INFO[i],p.sconfig)
                                sql=sql.encode("utf-8")
                                device_update(sql)
		else:
		    INFO[i]=''
#		else:
#		    cmd = "Device.objects.get(%s__exact='%s')" %(i,INFO[i])
#		    p=eval(cmd)
#		    cmd1='p.%s="%s"' %(i,INFO[i])
#		    p=eval(cmd1)
#		    p.save()
                
           
	    DBDA = Devbase(id=MDID,cabinet=INFO['cabinet'],project=INFO['project'],brand=INFO['brand'],\
                           cconfig=INFO['cconfig'],distributor=INFO['distributor'],riskowner=INFO['riskowner'],\
			   subprojects=INFO['subprojects'],srvmodel=INFO['srvmodel'],sconfig=INFO['sconfig'])
            DBDA.save()
	    log_info("登陆用户:" + str(User) + " 修改基础数据:" + " 成功")

            Results = Devbase.objects.get(id=MDID)
            for i in Tuple:
                var='Results.%s' %i
                var=eval(var)
                if var:
                    cmd = '''Devbase.objects.raw('select id,%s from uxin_devbase where %s !=""')''' %(i,i)
                    Results=eval(cmd)
                    return render_to_response('chabase.html',{'results':Results,'User':User,i:'i'},context_instance=RequestContext(request))

#            return render_to_response('chabase.html',{'Change':'OK','User':User},context_instance=RequestContext(request)) 

	#查找

        for i in Tuple:
            INFO[i] = request.REQUEST.get(i)
	    if name==i and not MDID:
		var=request.REQUEST.get('sea')
		if var and var != "":
#		    cmd = '''Devbase.objects.raw('select id,%s from uxin_devbase where %s !=""' and %s like %%%s%%)''' %(i,i,i,INFO[i])
		    cmd = "Devbase.objects.filter(%s__icontains='%s')" %(i,var)
		    Results = eval(cmd)
		    return render_to_response('chabase.html',{'results':Results,'User':User,i:'i'},context_instance=RequestContext(request))
		else:
		    cmd = '''Devbase.objects.raw('select id,%s from uxin_devbase where %s !=""')''' %(i,i)
		Results = eval(cmd)
#		Results = Devbase.objects.raw('select id,brand from uxin_devbase where brand !=""')
		return render_to_response('chabase.html',{'results':Results,'User':User,i:'i'},context_instance=RequestContext(request))

        if MDID and not Change:
	    if permissions_check(User,'device_base_change') != True:
        	return render_to_response('permissions_error.html')
            Results = Devbase.objects.get(id=MDID)
            if Results.cabinet != '':
	        #查询Id 机柜不为空
                R=Devbase.objects.filter(id=MDID,cabinet__isnull=False)
                return render_to_response('chabase.html',{'MDID':R,'cabinet':R,'User':User},context_instance=RequestContext(request))
            elif Results.project != '':
                R=Devbase.objects.filter(id=MDID,project__isnull=False)
                return render_to_response('chabase.html',{'MDID':R,'project':R,'User':User},context_instance=RequestContext(request))

            elif Results.subprojects != '':
                R=Devbase.objects.filter(id=MDID,subprojects__isnull=False)
                return render_to_response('chabase.html',{'MDID':R,'subprojects':R,'User':User},context_instance=RequestContext(request))

            elif Results.cconfig != '':
                R=Devbase.objects.filter(id=MDID,cconfig__isnull=False)
                return render_to_response('chabase.html',{'MDID':R,'cconfig':R,'User':User},context_instance=RequestContext(request))

            elif Results.distributor != '':
                R=Devbase.objects.filter(id=MDID,distributor__isnull=False)
                return render_to_response('chabase.html',{'MDID':R,'distributor':R,'User':User},context_instance=RequestContext(request))

            elif Results.riskowner != '':
                R=Devbase.objects.filter(id=MDID,riskowner__isnull=False)
                return render_to_response('chabase.html',{'MDID':R,'riskowner':R,'User':User},context_instance=RequestContext(request))

            elif Results.srvmodel != '':
                R=Devbase.objects.filter(id=MDID,srvmodel__isnull=False)
                return render_to_response('chabase.html',{'MDID':R,'srvmodel':R,'User':User},context_instance=RequestContext(request))

            elif Results.sconfig != '':
                R=Devbase.objects.filter(id=MDID,srvmodel__isnull=False)
                return render_to_response('chabase.html',{'MDID':R,'sconfig':R,'User':User},context_instance=RequestContext(request))
            else:
                R=Devbase.objects.filter(id=MDID,cabinet__isnull=False)
                return render_to_response('chabase.html',{'MDID':R,'cabinet':R,'User':User},context_instance=RequestContext(request))

        elif DLID and not name:
	    if permissions_check(User,'device_base_delete') != True:
                return render_to_response('permissions_error.html')
            Results = Devbase.objects.get(id=DLID)
            for i in Tuple:
		var='Results.%s' %i
		var=eval(var)
		if var:
            	    Results.delete()
                    cmd = '''Devbase.objects.raw('select id,%s from uxin_devbase where %s !=""')''' %(i,i)
		    Results=eval(cmd)
		    log_info("登陆用户:" + str(User) + " 删除基础数据:" +str(var) + " 成功")
		    return render_to_response('chabase.html',{'results':Results,'User':User,i:'i'},context_instance=RequestContext(request))


		    
#取不为空的字段
#	    Resultss = Devbase.objects.exclude(cabinet = '')
#            return render_to_response('chabase.html',{'results':Resultss,'User':User},context_instance=RequestContext(request))
    Results = Devbase.objects.exclude(cabinet = '')
    return render_to_response('chabase.html',{'User':User,'results':Results},context_instance=RequestContext(request))
