#!/usr/bin/env python
#-*- coding:UTF-8 -*-
import sys
reload(sys)
sys.setdefaultencoding( "utf-8" )

from django.http import *
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.contrib.auth.decorators import login_required
from django.utils import simplejson
from uxin.models import *
from django.conf import settings
from django.contrib.auth.models import User
from django.http import HttpResponseRedirect

from django.template import loader, RequestContext
import MySQLdb.cursors
import commands
from LogLib import *
import dbutil
import time
import re
from config import *
import urllib

import get_userlist
import os
import send_alarm
from tool import *
import json


def select(sql):
    conn=MySQLdb.connect(host=CACTICF['SQLIP'],user=CACTICF['SQLUSER'],passwd=CACTICF['SQLPASS'],db=CACTICF['SQLDB'],port=CACTICF['SQLPORT'],cursorclass=MySQLdb.cursors.DictCursor)
    cursor = conn.cursor()
#    cursor.execute('set names utf8')
    cursor.execute(sql)
    row=cursor.fetchall()
    cursor.close()
    conn.close()
    return row




def userlist():
     
    #清空数据
    try:
     Alarm_weixin.objects.all().delete()
    except:
     pass

    #所有用户列表
    try:
     Results = json.loads(urllib.urlopen(WEIXIN_ADDR + "GetUserList").read())

    #所有部门列表
     department = json.loads(urllib.urlopen(WEIXIN_ADDR + "GetDepartmentList").read())
    except Exception, e:
     return render_to_response('weixin.html',{'User':User,'error':'连接错误'})

    #用户列表，部门对应
    for u in Results['userlist']:
        for d in department['department']:
            if u['department'][0] == d['id']:
                u['department'] = d['name']


    for update in Results['userlist']:
    #每次查询时，更新数据库数据
	try:
         DBDA = Alarm_weixin(wx_name=update['name'],wx_department=update['department'],wx_phone=update['mobile'],wx_mail=update['email'],wx_uid=update['userid'])
         DBDA.save()
	except:
	 pass
    return Results['userlist']


def Departmentlist():
    try:
     department = json.loads(urllib.urlopen(WEIXIN_ADDR + "GetDepartmentList").read())
    except Exception, e:
     return render_to_response('weixin.html',{'User':User,'error':'连接错误'})
    return department['department']


def Chaweixin(request):
    User=request.user.username
    #返回state 表示显示顶部搜索新增行
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})

    if request.method == 'POST' or request.GET:
	DELETE = request.REQUEST.get('DLID')
	ADD = request.REQUEST.get('ADD')
        department = request.REQUEST.get('department')
	name = request.REQUEST.get('name')
	phone = request.REQUEST.get('phone')
	email = request.REQUEST.get('email')

        if DELETE:
	    url = WEIXIN_ADDR+"DelUserList?userlist=%s" %DELETE
	    Results = json.loads(urllib.urlopen(url).read())
	    return render_to_response('weixin.html',{'User':User,'results':userlist()})

	if ADD:
	    if department and name and phone and email:
		url = WEIXIN_ADDR+"AddUser?phone=%s&email=%s&name=%s&department=%s" %(phone,email,name,department)
		r = urllib.urlopen(url.encode('utf-8')).read()
		s = json.loads(r)
		if s['errcode'] == 0:
		    #如果新增成功，则邀请关注
		    url = WEIXIN_ADDR+"InviteUser?userid=%s" %email
                    r = urllib.urlopen(url.encode('utf-8')).read()
	        return render_to_response('weixin.html',{'User':User,'results':userlist()})
            return render_to_response('weixin.html',{'User':User,'ADD':Departmentlist()})

	    

    
    return render_to_response('weixin.html',{'User':User,'results':userlist()})


def Split_list(str):
        '''
        @将字符转分割放入列表中
        '''
        list = []
        for element in str.split('\n'):
                list.append(element)
        return list



