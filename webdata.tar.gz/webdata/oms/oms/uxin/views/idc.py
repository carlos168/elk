#!/usr/bin/env python
#-*- coding:UTF-8 -*-
from django.http import *
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.contrib.auth.decorators import login_required
from django.utils import simplejson
from uxin.models import Idc
from django.conf import settings
from django.contrib.auth.models import User

from django.template import loader, RequestContext
from dbutil import *
from tool import *
from LogLib import *

@login_required()
def Addidc(request):
    User=request.user.username
    if permissions_check(User,'idc_add') != True:
        return render_to_response('permissions_error.html')
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST':
        mroom = request.REQUEST.get('mroom')
        compactno = request.REQUEST.get('compactno')
        compactlimit = request.REQUEST.get('compactlimit')
        validdate = request.REQUEST.get('validdate')
        invaliddate = request.REQUEST.get('invaliddate')
        monthfee = request.REQUEST.get('monthfee')
        comtactclient = request.REQUEST.get('comtactclient')
        comtactoperation = request.REQUEST.get('comtactoperation')
        addr = request.REQUEST.get('addr')
        remark = request.REQUEST.get('remark')
        INFO = {}
        Tuple = ('mroom','compactno','compactlimit','validdate','invaliddate','monthfee','comtactclient','comtactoperation','addr','remark','ipnet')
        if mroom and comtactclient:
            for i in Tuple:
                INFO[i] = request.REQUEST.get(i)
            DBDA = Idc(mroom=INFO['mroom'].strip(),compactno=INFO['compactno'].strip(),compactlimit=INFO['compactlimit'].strip(),validdate=INFO['validdate'].strip(),\
                       invaliddate=INFO['invaliddate'].strip(),monthfee=INFO['monthfee'].strip(),comtactclient=INFO['comtactclient'].strip(),\
                       comtactoperation=INFO['comtactoperation'].strip(),addr=INFO['addr'].strip(),remark=INFO['remark'].strip(),ipnet=INFO['ipnet'].strip())
            DBDA.save()
	    log_info("登陆用户:" + str(User) + " 新增IDC:" +str(INFO['mroom']) + " 成功")
            return render_to_response('addidc.html',{'DBDA':INFO,'User':User,'error':'输入错误',})
        else:
            return render_to_response('addidc.html',{'ERROR':'输入错误','User':User})
    return render_to_response('addidc.html',{'User':User,'error':'输入错误',})


@login_required()
def Chaidc(request):
    User=request.user.username
    if permissions_check(User,'idc_view') != True:
        return render_to_response('permissions_error.html')
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST' or request.GET:
        mroom = request.REQUEST.get('mroom')
        MDID = request.REQUEST.get('MDID')
        DLID = request.REQUEST.get('DLID')
        Change = request.REQUEST.get('Change')
	view = request.REQUEST.get('VIEW')
        if mroom and MDID and Change:
	    if permissions_check(User,'idc_change') != True:
        	return render_to_response('permissions_error.html')
            INFO = {}
            Tuple = ('mroom','compactno','compactlimit','validdate','invaliddate','monthfee','comtactclient','comtactoperation','addr','remark','ipnet')
            for i in Tuple:
                INFO[i] = request.REQUEST.get(i)


                #修改基础数据，关键修改设备
                if INFO['mroom'] and INFO['mroom'] != "":
                    p = Idc.objects.get(id=MDID)
                    if p.mroom and p.mroom != "":
                                sql='update uxin_device set mroom="%s" where mroom="%s";' %(INFO['mroom'].strip(),p.mroom)
                                sql=sql.encode("utf-8")
                                device_update(sql)


            DBDA = Idc(id=MDID,mroom=INFO['mroom'].strip(),compactno=INFO['compactno'].strip(),compactlimit=INFO['compactlimit'].strip(),validdate=INFO['validdate'].strip(),\
                       invaliddate=INFO['invaliddate'].strip(),monthfee=INFO['monthfee'].strip(),comtactclient=INFO['comtactclient'].strip(),\
			comtactoperation=INFO['comtactoperation'].strip(),addr=INFO['addr'].strip(),remark=INFO['remark'].strip(),ipnet=INFO['ipnet'].strip())
            DBDA.save()
	    log_info("登陆用户:" + str(User) + " 修改IDC:" +str(INFO['mroom']) + " 成功")
            return render_to_response('chaidc.html',{'Change':'OK','User':User},context_instance=RequestContext(request)) 
        if mroom and not MDID:
            Results = Idc.objects.filter(mroom__icontains=mroom.strip())
            return render_to_response('chaidc.html',{'results':Results,'User':User},context_instance=RequestContext(request))
        elif MDID :
            if permissions_check(User,'idc_change') != True:
                return render_to_response('permissions_error.html')
            Results = Idc.objects.get(id=MDID)
            return render_to_response('chaidc.html',{'MDID':Results,'User':User},context_instance=RequestContext(request))
        elif DLID and not mroom:
            if permissions_check(User,'idc_delete') != True:
                return render_to_response('permissions_error.html')
            Results = Idc.objects.get(id=DLID)
            Results.delete()
            Resultss = Idc.objects.all()
	    log_info("登陆用户:" + str(User) + " 删除IDC:" +str(Results) + " 成功")
            return render_to_response('chaidc.html',{'results':Resultss,'User':User},context_instance=RequestContext(request))
        elif mroom:
            Results = Idc.objects.filter(mroom__contains='mroom')
            return render_to_response('chaidc.html',{'results':Results,'User':User},context_instance=RequestContext(request))
	elif view:
	    Results = Idc.objects.get(id=view)
	    return render_to_response('chaidc.html',{'VIEW': Results,'User':User})
        else:
            Results = Idc.objects.all()
            return render_to_response('chaidc.html',{'results':Results,'User':User},context_instance=RequestContext(request))
	
	

#    if 'VIEW' in request.GET and request.GET['VIEW']:
#        view = request.GET['VIEW']
#        Results = Idc.objects.filter(id__icontains=view)
#        Results = Idc.objects.get(id=view)
#        return render_to_response('chaidc.html',{'VIEW': Results,'User':User})


    Results = Idc.objects.all()
    return render_to_response('chaidc.html',{'results':Results,'User':User},context_instance=RequestContext(request))
