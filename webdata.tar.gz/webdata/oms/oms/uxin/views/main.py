#!/usr/bin/env python
#-*- coding:UTF-8 -*-
#####################################################
from django.http import HttpResponse
from django.http import HttpResponseRedirect
#from Context.Render import render
from django.shortcuts import render_to_response
#from Context.Render import render
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.contrib.auth import login
from django.contrib.auth import logout
#from django.utils import simplejson
import json
from django.conf import settings
#from uxin.models import REG
import re
import random

from django import forms
from captcha.fields import CaptchaField
from DjangoCaptcha import Captcha

import pyotp
import dbutil
from tool import *
from dbutil import *

def Login(request):
    if request.method == 'POST':
        try:
            Pwd = request.REQUEST.get('pwd').encode('utf-8')
            Loguser = request.REQUEST.get('log').encode('utf-8')
        except:
            return render_to_response('Login.html',{'error':'用户名或密码不能为空',})

        try:
            _code = request.REQUEST.get('cap').encode('utf-8')
            code = secureauth(Loguser)
        except:
            return render_to_response('Login.html',{'error':'动态口令不能为空',})


        if Pwd and Loguser:
            user = authenticate(username=Loguser, password=Pwd)
            if user is not None:
		#认证关键，代表已经登陆
                login(request,user)
                Username = request.user.username
                Next = re.search(r"=/(\w+)/", request.get_full_path())

		#设定sess过期时间
	        request.session.set_expiry(21600)
		

		#if _code == code:
		try:
		    
		    if  int(_code) == int(code):
			dese="delete from uxin_permissions_user where username='%s' and permissions='no_sercure'" %(Loguser)
			upcode="update auth_user set sercure='19' where username='%s'" %(Loguser)
                        if Next:
			    Next = Next.group(1)
			    if int(code) == 100000:
	  		        #删除授权，只允许登陆一次
			        dbutil.device_update(dese)
				#登陆CODE
				dbutil.device_update(upcode)

		        else:
			    Next = "index"
                            if int(code) == 100000:
                                #删除授权，只允许登陆一次
                                dbutil.device_update(dese)
                                #登陆CODE
                                dbutil.device_update(upcode)
                    
		        return HttpResponseRedirect("/%s" % Next)
                    else:
                        return render_to_response('Login.html',{'error':'输入错误',})
		except:
	  	        return render_to_response('Login.html',{'error':'输入错误-1',})

            else:
                return render_to_response('Login.html',{'error':'用户名或密码错误',})
        else:
	    return render_to_response('Login.html',{'error':'用户名或密码不能为空',})

    else:
	return render_to_response('Login.html')

def _Randstr(len):
    return ''.join(random.sample([chr(i) for i in range(48, 123)], len))


@login_required()
def index(request):
    User=request.user.username
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    return render_to_response('index.html',{'User':User,})



@login_required()
def Secure2(request):
    User=request.user.username
    otp_secret=pyotp.random_base32()

    if request.method == 'POST':
        sql="select last_name from auth_user where username='%s'" %(User)
        otp_secret=dbutil.select(sql)
        secret2 = request.REQUEST.get('secret2')
	totp = pyotp.TOTP(otp_secret[0]['last_name'])
	    
	if totp.now() == secret2:
            #认证通过后，更新字段
	    sql1="update auth_user set sercure='20' where username='%s'" %(User);
            dbutil.device_update(sql1)
            return render_to_response('Secure2.html',{'User':User,'issecret':'ok'})
	else:
	    #返回KEY 测试使用
	    #return render_to_response('Secure2.html',{'User':User,'error1':'动态令牌输入错误','error':totp.now(),'secretcode':otp_secret[0]['last_name'],'nosecret':'ok'})
	    return render_to_response('Secure2.html',{'User':User,'error':'动态令牌输入错误','secretcode':otp_secret[0]['last_name'],'nosecret':'ok'})

    #在权限管理加上no_secure后，直接get请求， 重新生成验证码
    if request.GET:
        bornagain=request.REQUEST.get('reset_key')
	if bornagain == User:
            sql1="update auth_user set sercure='1',last_name='' where username='%s'" %(User);
            dbutil.device_update(sql1)

    sql="select sercure from auth_user where username='%s'" %(User)
    otp_secret1=dbutil.select(sql)
    if otp_secret1[0]['sercure'] != 20:
        sql="update auth_user set last_name='%s' where username='%s'" %(otp_secret,User)
        dbutil.device_update(sql)
        return render_to_response('Secure2.html',{'User':User,'secretcode':otp_secret,'nosecret':'ok'})
    else:
	return render_to_response('Secure2.html',{'User':User,'issecret':'ok'})


def Logout(request):
    User=request.user.username
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    logout(request)
#  return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/login/'))
    return HttpResponseRedirect('/login/')


def secureauth(username):

    #临时登陆,手机验证码，无法找到时。 通过更改后台权限，允许临时登陆一次
    nosercuresql='select permissions from uxin_permissions_user where username="%s" and permissions="no_sercure"' %(username)
    nosercure=dbutil.select(nosercuresql)
    #初次登陆，需要扫码
    sql="select last_name from auth_user where username='%s' and sercure='20'" %(username)
    otp_secret=dbutil.select(sql)
    if nosercure:
        #删除授权，只允许登陆一次
        #dese="delete from uxin_permissions_user where username='%s' and permissions='no_sercure'" %(username)
        #dbutil.device_update(dese)
	#更新字段，登陆成功后， 显示扫码
	#dbutil.device_update("update auth_user set sercure='19' where username=%s" %User)
        return 100000
    elif otp_secret:
        totp = pyotp.TOTP(otp_secret[0]['last_name'])
        return totp.now()
    else:
        return 100000

def Cap(request):
    #figures         = [0,1,2,3,4,5,6,7,8,9,'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K',\
#		      'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',\
#		      'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',\
#		      'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

    figures	    = [1,2,3,4,5,6,7,8,9]
    ca              = Captcha(request)
    #ca.words = ['1','2','3','4']
    #ca.type = 'word'
    ca.words        = [''.join([str(random.sample(figures,1)[0]) for i in range(0,4)])]
    ca.type         = 'word'
    ca.img_width    = 60
    ca.img_height   = 25
    return ca.display()
