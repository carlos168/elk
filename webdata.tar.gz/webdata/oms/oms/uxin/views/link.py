#!/usr/bin/env python
#-*- coding:UTF-8 -*-
from django.http import *
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.contrib.auth.decorators import login_required
from django.utils import simplejson
import simplejson
from uxin.models import Link
from django.conf import settings
from django.contrib.auth.models import User

from django.template import loader, RequestContext

from LogLib import *
from tool import *

@login_required()
def Addlink(request):
    User=request.user.username
    if permissions_check(User,'link_add') != True:
	return render_to_response('permissions_error.html')

    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
             
    if request.method == 'POST':
        name = request.REQUEST.get('name')
        link = request.REQUEST.get('link')
        username = request.REQUEST.get('username')
        password = request.REQUEST.get('password')
        INFO = {}
        Tuple = ('name','link','username','password')
        if name and link:
            for i in Tuple:
                INFO[i] = request.REQUEST.get(i)
            DBDA = Link(name=INFO['name'].strip(),link=INFO['link'].strip(),username=INFO['username'].strip(),password=INFO['password'].strip())
	    
            DBDA.save()
	    log_info("登陆用户:" + str(User) + " 新增链接:" +str(INFO['link']) + " 成功")
            return render_to_response('addlink.html',{'DBDA':INFO,'User':User})
        else:
            return render_to_response('addlink.html',{'error':'用户名或密码不能为空','User':User})
    return render_to_response('addlink.html',{'User':User})

@login_required()
def Chalink(request):
    User=request.user.username
    if permissions_check(User,'link_view') != True:
        return render_to_response('permissions_error.html')
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST':
        name = request.REQUEST.get('name')
        addr = request.REQUEST.get('addr')
        MDID = request.REQUEST.get('MDID')
        DLID = request.REQUEST.get('DLID')
        Change = request.REQUEST.get('Change')

	
        if name and MDID and Change:
	    if permissions_check(User,'link_delete') != True:
                return render_to_response('permissions_error.html')
            INFO = {}
            Tuple = ('name','link','username','password')
            for i in Tuple:
                INFO[i] = request.REQUEST.get(i)
            DBDA = Link(id=MDID,name=INFO['name'].strip(),link=INFO['link'].strip(),username=INFO['username'].strip(),password=INFO['password'].strip())

            DBDA.save()
	    log_info("登陆用户:" + str(User) + " 修改链接:" +str(INFO['link']) + " 成功")
            return render_to_response('chalink.html',{'Change':'OK','User':User},context_instance=RequestContext(request)) 
        if name and not MDID:
            Results = Link.objects.filter(name__icontains=name.strip())
#            Results = Link.objects.get(name__contains='name')
#            for Results in Link.objects.raw('SELECT * FROM uxin_link where name like "%KC%" limit 1')
            return render_to_response('chalink.html',{'results':Results,'User':User},context_instance=RequestContext(request))
        if addr and not MDID:
            Results = Link.objects.filter(link__icontains=addr.strip())
#            Results = Link.objects.get(name__contains='name')
#            for Results in Link.objects.raw('SELECT * FROM uxin_link where name like "%KC%" limit 1')
            return render_to_response('chalink.html',{'results':Results,'User':User},context_instance=RequestContext(request))
        elif MDID:
            if permissions_check(User,'link_delete') != True:
                return render_to_response('permissions_error.html')
            Results = Link.objects.get(id=MDID)
            return render_to_response('chalink.html',{'MDID':Results,'User':User},context_instance=RequestContext(request))
        elif DLID and not name:
            if permissions_check(User,'link_delete') != True:
                return render_to_response('permissions_error.html')
            Results = Link.objects.get(id=DLID)
            Results.delete()
            Resultss = Link.objects.all()
	    log_info("登陆用户:" + str(User) + " 删除链接:" +str(Results) + " 成功")
            return render_to_response('chalink.html',{'results':Resultss,'User':User},context_instance=RequestContext(request))
        elif name:
#            Results = Link.objects.filter(name=name)
#            Results = Link.objects.get(headline__contains=name)
            Results = Link.objects.filter(name__contains='name')
            return render_to_response('chalink.html',{'results':Results,'User':User},context_instance=RequestContext(request))
        else:
            Results = Link.objects.all()
            return render_to_response('chalink.html',{'results':Results,'User':User},context_instance=RequestContext(request))
    Results = Link.objects.all()
    return render_to_response('chalink.html',{'results':Results,'User':User},context_instance=RequestContext(request))

