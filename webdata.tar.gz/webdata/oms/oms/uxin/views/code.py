#!/usr/bin/env python
#-*- coding:UTF-8 -*-
from django.http import *
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.contrib.auth.decorators import login_required
from django.utils import simplejson
import simplejson
from uxin.models import Link
from django.conf import settings
from django.contrib.auth.models import User

from django.template import loader, RequestContext

from LogLib import *
from tool import *
import StringIO

import pyqrcode
import pyotp
from dbutil import *

@login_required()
def OMSCODE(request):
    User=request.user.username

    #生成随机KEY  登陆界面生面KEY后，保存数据库
    #otp_secret=pyotp.random_base32()
    sql="select last_name from auth_user where username='%s'" %(User)
    otp_secret=dbutil.select(sql)
    #OMSCODE='otpauth://totp/OMS:{0}?secret={1}&issuer=OMS' .format(User, 'X7WFEHYESEJ4XFDE')
    OMSCODE='otpauth://totp/OMS:{0}?secret={1}&issuer=OMS' .format(User, otp_secret[0]['last_name'])
    url = pyqrcode.create(OMSCODE)
    stream = StringIO.StringIO()
    
    #图片大小
    url.svg(stream, scale=4)
    image_stream = stream.getvalue()
    response = HttpResponse(image_stream, content_type="image/svg+xml")
    response['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    return response
