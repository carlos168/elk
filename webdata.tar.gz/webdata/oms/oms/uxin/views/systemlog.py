#!/usr/bin/env python
#-*- coding:UTF-8 -*-
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.contrib.auth.decorators import login_required
from django.utils import simplejson
from django.conf import settings


from LogLib import *
import MySQLdb.cursors

from django.core.paginator import Paginator
from django.core.paginator import EmptyPage
from django.core.paginator import PageNotAnInteger

from tool import *
from cmdtosql import *
from config import *
import pymongo
from pymongo import MongoClient
import random
import sys
import re


def mongo1(*args, **kwargs):
    #新版本mongo库  连接方式 
    conn = MongoClient(MONGO['IP'],int(MONGO['PORT']))
    #conn = MongoClient(MONGO['IP'],int(MONGO['PORT']))
    #conn = pymongo.Connec1111tion(MONGO['IP'],int(MONGO['PORT']))
    db = conn.syslog
#    rr=db.systemlog.find().sort("_id",pymongo.DESCENDING).limit(1000)
#    if kwargs['ip']:
#        rr=db.systemlog.find({"FromIP":{"$regex":"%s" %kwargs['ip']}}).sort("_id",pymongo.DESCENDING).limit(1000)
#    else:
#        rr=db.systemlog.find().sort("_id",pymongo.DESCENDING).limit(1000)
    rr=db.systemlog.find().sort("_id",pymongo.DESCENDING).limit(1000)
    a=[]
    for i in rr:
        a.append(i)
    return [ p for p in a ]


def mongoselect(sql):
    conn = MongoClient(MONGO['IP'],int(MONGO['PORT']))
    db = conn.syslog
    #首行以grep开头
#    rr=db.notes.find({"Message":re.compile("^grep.*")}).limit(100)
    #首行不以grep开头
#    rr=db.notes.find({"Message":re.compile("^.*grep.*")}).limit(100)

    #包含grep
#    rr=db.notes.find({"SERVER_IP":{"$regex":"8.8.8.115"},"Message":{"$regex":"grep"}}).limit(1000)
#    rr=select
    sql=eval(sql)
    a=[]
    for i in sql:
        a.append(i)
    return [ p for p in a ]


def top(topics,request):
    limit=50
    paginator = Paginator(topics, limit)  # 实例化一个分页对象
    page = request.GET.get('page')  # 获取页码
    try:
        topics = paginator.page(page)  # 获取某页对应的记录
    except PageNotAnInteger:  # 如果页码不是个整数
        topics = paginator.page(1)  # 取第一页的记录
    except EmptyPage:  # 如果页码太大，没有相应的记录
        topics = paginator.page(paginator.num_pages)  # 取最后一页的记录
    return topics


#替换mongodb中的特殊字符

def multiple_replace(text, adict):
     rx = re.compile('|'.join(map(re.escape, adict)))
     def one_xlat(match):
           return adict[match.group(0)]
     return rx.sub(one_xlat, text)
adict = {
   ")" : "\\\)",
   "(" : "\\\(",
   "}" : "\\\}",
   "{" : "\\\{",
   "[" : "\\\[",
   "]" : "\\\]",
   "$" : "\\\$",
   "^" : "\\\^",
   '"' : '\\\\\\"',
   "'" : "\\\\'",
   "*" : "\\\*",
   "|" : "\\\|",
   "?" : "\\\?",
}

@login_required()
def View(request):
    User=request.user.username
    if permissions_check(User,'audit_log_view') != True:
        return render_to_response('permissions_error.html')
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    
    if request.method == 'POST':
	count=request.REQUEST.get('count')
        INFO = {}
        Tuple = ('SERVER_IP','LOGIN_NAME','EXE_USER','LOGIN_IP','EXE_PATH','LOGIN_TIME','Message')
	find='db.notes.find({'
        for i in Tuple:
            INFO[i] = request.REQUEST.get(i)
	    if INFO[i] and INFO[i] !='':
		text = multiple_replace(INFO[i], adict)
	        find=find+'"%s":{"$regex":"%s"},' %(i,text)
	find=find+'}).sort("_id",pymongo.DESCENDING).limit(%s)' %count
	#log_info(str(find))
	topics=mongoselect(find)
	return render_to_response('log.html',{'topics': topics,'User':User,'count':count})
	    


    sql='db.notes.find({},).sort("_id",pymongo.DESCENDING).limit(50)'
    topics=mongoselect(sql)
    return render_to_response('log.html',{'topics': topics,'User':User})


@login_required()
def Sysview(request):
    User=request.user.username
    if permissions_check(User,'system_log_view') != True:
        return render_to_response('permissions_error.html')
	
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST' or request.GET:
	count=request.REQUEST.get('count')
        INFO = {}
#	out = open('tempfile','a')
        Tuple = ('FromHost','FromIP','DeviceReportedTime','Priority','SysLogTag','Message')
        find='db.systemlog.find({'
        for i in Tuple:
            INFO[i] = request.REQUEST.get(i)
            if INFO[i] and INFO[i] !='' and i != 'Priority':
		text = multiple_replace(INFO[i], adict)
#                print >> out,text
#	        out.flush()
                find=find+'"%s":{"$regex":"%s"},' %(i,text)
	    if INFO[i] and INFO[i] !='' and i == 'Priority':
		find=find+'"%s":%s' %(i,INFO[i])
        find=find+'}).sort("_id",pymongo.DESCENDING).limit(%s)' %count


        topics=mongoselect(find)
        limit = 50 # 每页显示的记录数
#    	topics = mongo()
    	paginator = Paginator(topics, limit)  # 实例化一个分页对象

    	page = request.GET.get('page')  # 获取页码
    	try:
            topics = paginator.page(page)  # 获取某页对应的记录
    	except PageNotAnInteger:  # 如果页码不是个整数
            topics = paginator.page(1)  # 取第一页的记录
    	except EmptyPage:  # 如果页码太大，没有相应的记录
            topics = paginator.page(paginator.num_pages)  # 取最后一页的记录



#	topics=top(mongoselect(find),request)
	return render_to_response('logsys.html',{'topics': topics,'User':User,'count':count})

    sql='db.systemlog.find().sort("_id",pymongo.DESCENDING).limit(50)'
    topics=top(mongoselect(sql),request)
    return render_to_response('logsys.html',{'topics': topics,'User':User})


@login_required()
def Mysqlview(request):
    User=request.user.username

    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST' or request.GET:
        count=request.REQUEST.get('count')
        INFO = {}
        Tuple = ('FromHost','FromIP','DeviceReportedTime','ReceivedAt','SysLogTag','Message','connip','username','port')
        find='db.mysqllog.find({'
        for i in Tuple:
            INFO[i] = request.REQUEST.get(i)
            if INFO[i] and INFO[i] !='':
                text = multiple_replace(INFO[i], adict)
                find=find+'"%s":{"$regex":"%s"},' %(i,text)
        #find=find+'}).sort("_id",pymongo.DESCENDING).limit(%s)' %count
        find=find+'}).sort("_id",pymongo.DESCENDING).limit(500)'


        topics=mongoselect(find)
	log_info(str(topics))
        return render_to_response('mysqllog.html',{'topics': topics,'User':User,'count':count})

    sql='db.mysqllog.find().sort("_id",pymongo.DESCENDING).limit(50)'
    topics=mongoselect(sql)
    return render_to_response('mysqllog.html',{'topics': topics,'User':User})
