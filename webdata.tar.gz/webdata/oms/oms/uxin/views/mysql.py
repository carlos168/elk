#!/usr/bin/env python
#-*- coding:UTF-8 -*-
from django.http import *
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.contrib.auth.decorators import login_required
from django.utils import simplejson
from uxin.models import Mysql
from uxin.models import Device
from django.conf import settings
from django.contrib.auth.models import User

from django.template import loader, RequestContext
from LogLib import *
from tool import *
import dbutil
import tablib
import StringIO
import base64
import re



def base():
    INFO = {}
    Tuple = ('ipaddr','port','username','password','remark','version','pm','mysqlcheck')
    
    for l in Tuple:
        INFO[l] = request.REQUEST.get(l)
    
    return INFO

@login_required()
def Add(request):
    User=request.user.username
#    if permissions_check(User,'domain_add') != True:
#        return render_to_response('permissions_error.html')
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    device_ip = Device.objects.raw('select id,wanip from uxin_device')
    test_conn = request.REQUEST.get('test_conn')
    adddata = request.REQUEST.get('add')
    INFO = {}
    Tuple = ('ipaddr','port','username','password','remark','version','pm','mysqlcheck')
    for l in Tuple:
        INFO[l] = request.REQUEST.get(l)
    if request.method == 'POST' or request.GET:

	#测试连接
        if test_conn == '测试连通' and INFO['ipaddr'] and INFO['username'] and INFO['password'] and INFO['port']:
	    mysqlinfo=mysql_conn(INFO['ipaddr'],INFO['username'],INFO['password'],INFO['port'])
	    #mysqlinfo[0]=mysqlinfo[0].replace('\n','')
	    #mysqlinfo[0]=mysqlinfo[0].replace('Warning: Using a password on the command line interface can be insecure.','')
	    if mysqlinfo:
		try:
	         mysqlinfo = dict(eval(mysqlinfo[0]))
		except:
		 #mysql 5.6 会有密码警告，  替换掉
	 	 log_info("登陆用户:" + str(User) + " 新增MYSQL服务器:" +str(mysqlinfo[0]) + " 成功")
	         mysqlinfo = dict(eval(mysqlinfo[0].replace('Warning: Using a password on the command line interface can be insecure.','')))
		if mysqlinfo['version'] == '':
                    return render_to_response('mysql.html',{'ADD':'add','User':User,'device_ip':device_ip,'version':mysqlinfo['version'],\
                                                  'port':INFO['port'],'ERROR':'连接失败','ipaddr':INFO['ipaddr'],'username':INFO['username'],\
                                                  'password':INFO['password']})
	        return render_to_response('mysql.html',{'ADD':'add','User':User,'device_ip':device_ip,'version':mysqlinfo['version'],\
						  'port':mysqlinfo['port'],'ERROR':'连接成功','ipaddr':INFO['ipaddr'],'username':INFO['username'],\
						  'password':INFO['password']})
	    else:
	        return render_to_response('mysql.html',{'User':User,'ADD':'add','device_ip':device_ip,'ERROR':'请输入正确用户名，密码，端口'})
		                                        

#	elif not test_conn and INFO['port'] != '' and INFO['username']  != '' and INFO['password']  != '' and INFO['ipaddr'] != '':	
	elif adddata and INFO['ipaddr'] and INFO['username'] and INFO['password'] and INFO['port']:
	    try:
	     R = Mysql.objects.get(ipaddr=INFO['ipaddr'],port=INFO['port'])
	    except  Exception:
	     R=1
	    if R != 1:
                return render_to_response('mysql.html',{'ADD':'add','User':User,'device_ip':device_ip,'version':mysqlinfo['version'],\
                                                  'port':mysqlinfo['port'],'ERROR':'请不要重复添加','ipaddr':INFO['ipaddr'],'username':INFO['username'],\
                                                  'password':INFO['password']})

            DBDA = Mysql(ipaddr=INFO['ipaddr'].strip(),port=INFO['port'].strip(),mysql_user=INFO['username'].strip(),\
                        password=base64.encodestring(INFO['password'].strip()),remark=INFO['remark'].strip(),version=INFO['version'].strip(),pm=INFO['pm'].strip())
            DBDA.save()
			
	    log_info("登陆用户:" + str(User) + " 新增MYSQL服务器:" +str(INFO['ipaddr']) + " 成功")
            return render_to_response('mysql.html',{'DBDA':INFO,'ADD':'add','User':User})

	else:
            return render_to_response('mysql.html',{'ADD':'add','User':User,'device_ip':device_ip,\
                                                  'port':mysqlinfo['port'],'ERROR':'参数输入不完整','ipaddr':INFO['ipaddr'],'username':INFO['username'],\
                                                  'password':INFO['password']})



    return render_to_response('mysql.html',{'User':User,'ADD':'add','device_ip':device_ip})


@login_required()
def Change(request):
    User=request.user.username
#    if permissions_check(User,'domain_view') != True:
#        return render_to_response('permissions_error.html')
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})

    if request.method == 'POST' or request.GET:
        ipaddr = request.REQUEST.get('ipaddr')
        register_no = request.REQUEST.get('register_no')
        MDID = request.REQUEST.get('MDID')
        DLID = request.REQUEST.get('DLID')
        Change = request.REQUEST.get('Change')
 	view = request.REQUEST.get('VIEW')
        updateid =  request.REQUEST.get('update')
        audit = request.REQUEST.get('audit')



        if audit and updateid:
           Results = Mysql.objects.get(id=updateid)
#	   password=base64.decodestring(Results.password)
         
	   s=mysql_audit(Results.ipaddr,Results.mysql_user,base64.decodestring(Results.password),Results.port,audit)
	   if re.search('Warning', s):
	       s = s.replace('Warning: Using a password on the command line interface can be insecure.','').replace('\n','')
	   log_info(str(s))
           if s == 'no set':
	       Mysql.objects.filter(id=updateid).update(audit='NULL')
	    
	   elif s == 'set':
	       Mysql.objects.filter(id=updateid).update(audit='yes')
	   elif s == 'audit open':
	       Mysql.objects.filter(id=updateid).update(audit='yes')
	       Results = Mysql.objects.get(id=updateid)
               return render_to_response('mysql.html',{'VIEW':Results,'User':User,'ERROR':'开启成功'},context_instance=RequestContext(request))
	   elif s == 'audit close':
               Mysql.objects.filter(id=updateid).update(audit='NULL')
               Results = Mysql.objects.get(id=updateid)
               return render_to_response('mysql.html',{'VIEW':Results,'User':User,'ERROR':'关闭成功'},context_instance=RequestContext(request))

	   else:
	       return render_to_response('mysql.html',{'VIEW':Results,'User':User},context_instance=RequestContext(request))
	   Results = Mysql.objects.get(id=updateid)
	   return render_to_response('mysql.html',{'VIEW':Results,'User':User},context_instance=RequestContext(request))
	

        if ipaddr and MDID and Change:
            if permissions_check(User,'domain_change') != True:
                return render_to_response('permissions_error.html')
            INFO = {}
	    Tuple = ('ipaddr','port','username','password','remark','version','pm','mysqlcheck')
            for i in Tuple:
                INFO[i] = request.REQUEST.get(i)

	    
            if INFO['password'].strip() != '':
	        Mysql.objects.filter(id=MDID).update(ipaddr=INFO['ipaddr'].strip(),mysql_user=INFO['username'].strip(),port=INFO['port'].strip(),\
				   remark=INFO['remark'].strip(),version=INFO['version'].strip(),pm=INFO['pm'].strip(),\
				   password=base64.encodestring(INFO['password'].strip()))
	    else:
                Mysql.objects.filter(id=MDID).update(ipaddr=INFO['ipaddr'].strip(),mysql_user=INFO['username'].strip(),port=INFO['port'].strip(),\
                                   remark=INFO['remark'].strip(),version=INFO['version'].strip(),pm=INFO['pm'].strip())
#            DBDA = Mysql(id=MDID,ipaddr=INFO['ipaddr'].strip(),port=INFO['port'].strip(),remark=INFO['remark'].strip(),version=INFO['version'].strip(),pm=INFO['pm'].strip())
#            DBDA.update()
	    log_info("登陆用户:" + str(User) + " 修改数据库:" +str(INFO['ipaddr']) + " 成功")
            return render_to_response('mysql.html',{'Change':'OK','User':User},context_instance=RequestContext(request))

        if ipaddr and not MDID:
            Results = Mysql.objects.filter(domain_name__icontains=domain_name.strip())
            return render_to_response('mysql.html',{'results':Results,'User':User},context_instance=RequestContext(request))

        elif MDID:
            Results = Mysql.objects.get(id=MDID)
            return render_to_response('mysql.html',{'MDID':Results,'User':User},context_instance=RequestContext(request))
        elif DLID and not ipaddr:
            if permissions_check(User,'domain_delete') != True:
                return render_to_response('permissions_error.html')
            Results = Mysql.objects.get(id=DLID)
            Results.delete()
            Resultss = Mysql.objects.all()
	    log_info("登陆用户:" + str(User) + " 删除数据库:" +str(Results) + " 成功")
            return render_to_response('mysql.html',{'results':Resultss,'User':User},context_instance=RequestContext(request))
	elif view:
	    Results = Mysql.objects.get(id=view)
	    return render_to_response('mysql.html',{'VIEW': Results,'User':User})
        else:
            sql='select * from uxin_mysql order by ipaddr asc, port'
            Results =  dbutil.select(sql)
            Results = Mysql.objects.all()
            return render_to_response('mysql.html',{'results':Results,'User':User},context_instance=RequestContext(request))


    sql='select * from uxin_mysql order by ipaddr asc, port'
    Results =  dbutil.select(sql)

    return render_to_response('mysql.html',{'results':Results,'User':User},context_instance=RequestContext(request))



@login_required()
def Mysqluser(request):
    User=request.user.username
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})

    if request.GET:
#	mysqlid = request.GET['mysqlid']
        IP = request.GET['IPADDR']
        port = request.GET['port']
        view = request.REQUEST.get('view')
        mysqluser = request.REQUEST.get('sysuser')
        Button = request.REQUEST.get('Button')
	purview = request.REQUEST.get('purview')
	database = request.REQUEST.get('database')
	fromip = request.REQUEST.get('fromip')
	pas = request.REQUEST.get('pas')
	Results = Mysql.objects.get(ipaddr=IP,port=port)
	delser = request.REQUEST.get('deluser')

        if view:
	    s=mysql_user_view(Results.ipaddr,Results.mysql_user,base64.decodestring(Results.password),Results.port)
	    return render_to_response('mysqluser.html',{'User':User,'IP':IP,'resultss':s,'port':port})

	elif Button:
	    if mysqluser and purview and database and fromip and pas:
		if database == '*.*':
		    return render_to_response('mysqluser.html',{'User':User,'IP':IP,'port':port,'error':'不允许数据库为 *.* 的授权'})
		if fromip == '%':
		    return render_to_response('mysqluser.html',{'User':User,'IP':IP,'port':port,'error':'不允许来源IP为 % 的授权'})
	        mysql_user_add(Results.ipaddr,Results.mysql_user,base64.decodestring(Results.password),Results.port,mysqluser,purview,database,fromip,pas)
	        s=mysql_user_view(Results.ipaddr,Results.mysql_user,base64.decodestring(Results.password),Results.port)
	        return render_to_response('mysqluser.html',{'User':User,'IP':IP,'resultss':s,'port':port,'error':'命令执行完成，请核对结果'})
	    else:
		return render_to_response('mysqluser.html',{'User':User,'IP':IP,'port':port,'error':'信息输入不完整'})
	if delser:
	    if mysqluser == 'root':
		if fromip == '127.0.0.1' or fromip == 'localhost' or fromip == '::1':
		    return render_to_response('mysqluser.html',{'User':User,'IP':IP,'port':port,'error':'无权限删除此用户'}) 
	    if mysqluser and fromip:
		mysql_user_del(Results.ipaddr,Results.mysql_user,base64.decodestring(Results.password),Results.port,mysqluser,fromip)
		s=mysql_user_view(Results.ipaddr,Results.mysql_user,base64.decodestring(Results.password),Results.port)
		return render_to_response('mysqluser.html',{'User':User,'IP':IP,'resultss':s,'port':port,'error':'命令执行完成，请核对结果'})
	    else:
		s=mysql_user_view(Results.ipaddr,Results.mysql_user,base64.decodestring(Results.password),Results.port)
		return render_to_response('mysqluser.html',{'User':User,'IP':IP,'resultss':s,'error':'必须输入要删除的用户名 与 来源IP','port':port})

		


    return render_to_response('mysqluser.html',{'User':User,'IP':IP,'port':port})
