#!/usr/bin/env python
#-*- coding:UTF-8 -*-
# encoding=utf8  
import sys  
  
reload(sys)  
sys.setdefaultencoding('utf8')

from django.http import *
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.contrib.auth.decorators import login_required
from django.utils import simplejson
from django.conf import settings
from django.contrib.auth.models import User

from django.template import loader, RequestContext

from LogLib import *
from config import *
from tool import *
import commands


def Split_list(str):
        '''
        @将字符转分割放入列表中
        '''
        list = []
        for element in str.split('\n'):
                list.append(element)
        return list


def lista_custom():
    import commands
    status, output = commands.getstatusoutput('ls %s/oms/software' %(DIRS['OMS_ROOT']))
    if Split_list(output)[0]:

        return Split_list(output)
def list_custom():
    import commands
    status, output = commands.getstatusoutput('du -sh  %s/oms/software/* | sed "s#%s/oms/software/##"' %(DIRS['OMS_ROOT'],DIRS['OMS_ROOT']))
    if Split_list(output):
        a = []
        for i in Split_list(output):
	    b = {}
            c = i.split("	")
            b['size']=c[0]
            b['filename']=c[1]
            a.append(b)
        return a


@login_required()
def Addsoft(request):
    User=request.user.username
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})

    return render_to_response('addsoft.html',{'User':User},context_instance=RequestContext(request))

@login_required()
def Chasoft(request):
    User=request.user.username
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST':
        DLID = request.REQUEST.get('DLID')

        if DLID:
	    commands.getstatusoutput('mv  %s/oms/software/%s /tmp/' %(DIRS['OMS_ROOT'],DLID))
	    Resultss = list_custom()
            return render_to_response('chasoft.html',{'results':Resultss,'User':User},context_instance=RequestContext(request))

    Results = list_custom()
    return render_to_response('chasoft.html',{'results':Results,'User':User},context_instance=RequestContext(request))
