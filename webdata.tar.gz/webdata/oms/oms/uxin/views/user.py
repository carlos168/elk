#!/usr/bin/env python
#-*- coding:UTF-8 -*-
#####################################################
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.contrib.auth.decorators import login_required
#from uxin.models import REG
from django.conf import settings
from django.contrib.auth.models import User

from django.contrib.auth import authenticate
from django.contrib.auth import login

from uxin.models import *
import dbutil

from tool import *
from LogLib import *

@login_required()
def Usermg(request):
    User=request.user.username
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST':
	User=request.user.username
        oldpassword=str(request.REQUEST.get('oldpassword'))
        newpassword=str(request.REQUEST.get('password'))
        repassword=str(request.REQUEST.get('password_r'))
	username = request.user.username 
	user = authenticate(username=username,password=oldpassword) 

	if user:
	    if newpassword == repassword:
                user.set_password(repassword)
                user.save()
	        return render_to_response('usermg.html',{'User':User,'error':'修改密码成功',})
            else:
		return render_to_response('usermg.html',{'User':User,'error':'两次输入口令不一致',})

        else:
	    if newpassword == repassword:
		return render_to_response('usermg.html',{'User':User,'error':'旧口令错误',})
            else:
                return render_to_response('usermg.html',{'User':User,'error':'旧口令错误，并且两次输入口令不一致',})
    return render_to_response('usermg.html',{'User':User,})


@login_required()
def User(request):
    User=request.user.username
    if permissions_check(User,'oms_admin') != True:
        return render_to_response('permissions_error.html')
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST':
        username=request.REQUEST.get('username')
        select=request.REQUEST.get('select')
        save_p=request.REQUEST.get('save_p')
	InGroup = request.REQUEST.getlist('InGroup')

	#所有用户
	userlist=dbutil.select('select username from auth_user')

	#所有权限
	#Results = permissions_list.objects.all()
	Results = dbutil.select('select permissions from uxin_permissions_list')
	#查看用户已有权限
        user_p_sql = 'select permissions from uxin_permissions_user where username="%s"' %username
        user_p = dbutil.select(user_p_sql)

	#对比所有的权限，与已有权限， 计算出剩余权限
	diff=[i for i in Results if i not in user_p]

	#c=set(Results)-set(user_p)
	#c=list[Results[0]['permissions']]
		
	#查询
	if select:
            return render_to_response('user.html',{'results':diff,'User':User,'userlist':userlist,'user_p':user_p,'username_s':username})

	#保存
	if save_p:
		#先清除用户所有权限
	    if username != '':
		del_sql='delete from uxin_permissions_user where username="%s"' %username
		dbutil.device_update(del_sql)
	        for i in InGroup:
		#先查看数据库是否已经有权限
		#e_sql='select * from uxin_permissions_user where username="%s" and permissions="%s"' %(username,i)
		#e_p=dbutil.select(e_sql)
		#先清除用户所有权限
		
		#if not e_p:
		    sql='insert into uxin_permissions_user values(NULL,"%s","%s","admin")' %(username,i) 
                    sql=sql.encode("utf-8")
                    dbutil.device_update(sql)
	    #查看用户已有权限
	    user_p_sql = 'select permissions from uxin_permissions_user where username="%s"' %username
	    user_p = dbutil.select(user_p_sql)

            #对比所有的权限，与已有权限， 计算出剩余权限
            diff=[i for i in Results if i not in user_p]
	    return render_to_response('user.html',{'results':diff,'User':User,'userlist':userlist,'user_p':user_p,'username_s':username})

	return render_to_response('user.html',{'results':diff,'User':User,'userlist':userlist,'user_p':user_p,'username_s':username})

    sql = 'select username from auth_user'
    userlist=dbutil.select(sql)
    Results = permissions_list.objects.all()
    return render_to_response('user.html',{'results':Results,'User':User,'userlist':userlist})
