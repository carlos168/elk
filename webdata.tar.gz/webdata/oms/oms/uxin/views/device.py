#!/usr/bin/env python
#-*- coding:UTF-8 -*-
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.contrib.auth.decorators import login_required
from django.utils import simplejson
from uxin.models import *
from uxin.models import Devbase
from django.conf import settings
#from uxin.uxin import argg

from django.contrib.auth.models import User

from django.template import loader, RequestContext
import os
import csv
import codecs
import time
import dbutil
from dbutil import *
import re
###换行
from django.core.paginator import Paginator
from django.core.paginator import EmptyPage
from django.core.paginator import PageNotAnInteger
#from hello.models import Topic
#import sys_check
import tablib
import StringIO
from LogLib import *
from tool import *
import datetime,time
import Hardware
import ssh
import config

#定义下拉列表
mroom = Idc.objects.raw('select id,mroom from uxin_idc where mroom !=""')
cabinet = Devbase.objects.raw('select id,cabinet from uxin_devbase where cabinet !=""')
project = Devbase.objects.raw('select id,project from uxin_devbase where project !=""')
subprojects = Devbase.objects.raw('select id,subprojects from uxin_devbase where subprojects !=""')
brand = Devbase.objects.raw('select id,brand from uxin_devbase where brand !=""')
cconfig = Devbase.objects.raw('select id,cconfig from uxin_devbase where cconfig !=""')
distributor = Devbase.objects.raw('select id,distributor from uxin_devbase where distributor !=""')
riskowner = Devbase.objects.raw('select id,riskowner from uxin_devbase where riskowner != ""')
srvmodel = Devbase.objects.raw('select id,srvmodel from uxin_devbase where srvmodel != ""')
subprojects = Devbase.objects.raw('select id,subprojects from uxin_devbase where subprojects != ""')



@login_required()

def Devssh(request):
    User=request.user.username
    if permissions_check(User,'ssh_terminal') != True:
        return render_to_response('permissions_error.html')
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    return render_to_response('ssh.html',{'User':User})
@login_required()
def Vnc(request):
    User=request.user.username
    if permissions_check(User,'vnc_terminal') != True:
        return render_to_response('permissions_error.html')
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    vnc=request.REQUEST.get('VNC')
    if request.method == 'POST':
	vnc=request.REQUEST.get('VNC')

    if vnc=='wx':
	return render_to_response('vnc.html',{'User':User,'wx':'wx'})
    elif vnc=='zs':
        return render_to_response('vnc.html',{'User':User,'zs':'zs'})
    else:
        
        return render_to_response('vnc.html',{'User':User})


INFO = {}
Tuple = ('wanip','lanip','mip','mroom','cabinet','project','runsrv','brand',\
                 'srvmodel','cconfig','riskowner','purchased','usedate','distributor',\
                'contractsn','price','servicesn','subprojects','exp','stats','remarks',\
		'machine_type','systemcheck','device_port','bakpath','baklog','bakipaddr')

baseTuple = ('cabinet','project','brand','cconfig','distributor','riskowner','subprojects','srvmodel')

@login_required()
def Adddev(request):
  
    User=request.user.username
    if permissions_check(User,'device_add') != True:
        return render_to_response('permissions_error.html')
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})

    #机器配置自动获取
    initinfo = request.REQUEST.get('autoinfo')
    #新上架机器时间
    nowtime=datetime.date.today()
    nowt = str(nowtime)
    uset=str(nowtime - datetime.timedelta(days=10))
    if request.method == 'POST' or request.GET:




        for l in Tuple:
            INFO[l] = request.REQUEST.get(l)
	    if not INFO['wanip']:
		Results = Device.objects.all()
		return render_to_response('adddev.html',{'Results':Results,'error':"IP为空",'User':User,'mroom':mroom,'cabinet':cabinet,'project':project,'subprojects':subprojects,'brand':brand,\
                              'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,'srvmodel':srvmodel,'subprojects':subprojects,'nowt':nowt,'uset':uset})


        if check_ip(INFO['wanip']) != 'ok':
	    Results = Device.objects.all()
            return render_to_response('adddev.html',{'Results':Results,'error':"IP错误",'User':User,'mroom':mroom,'cabinet':cabinet,'project':project,'subprojects':subprojects,'brand':brand,\
                              'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,'srvmodel':srvmodel,'subprojects':subprojects,'nowt':nowt,'uset':uset})

        if initinfo:
	    if INFO['price'] and INFO['exp']:
		#指定用户名密码
                systeminfo = Hardware.exe_cmd(INFO['wanip'],INFO['device_port'],username=INFO['price'],password=INFO['exp'])
	    else:
		#未指定
		systeminfo = Hardware.exe_cmd(INFO['wanip'],INFO['device_port'])
		
	    log_info("自动获取配置 " + str(INFO['wanip'])  + ' port:' + str(INFO['device_port']) + ' username:' + str(INFO['price']) + ' password:' + str(INFO['exp']))

	    if systeminfo:
	     try:
		systeminfo = dict(eval(systeminfo[0]))
		error = ''
	     except:
                systeminfo = {'System_Ip': ['', ''], 'Device_conf': '', 'Device_Model': '', 'Device_Sn': '', 'Device_brand': '', 'Device_Type': '','IPMI_IP': ''}
                error= str(INFO['wanip']) + '  Authentication Error'
	    else:
		systeminfo = {'System_Ip': ['', ''], 'Device_conf': '', 'Device_Model': '', 'Device_Sn': '', 'Device_brand': '', 'Device_Type': '','IPMI_IP': ''}
		error= str(INFO['wanip']) + '  Authentication Error'


	    if len(systeminfo['System_Ip']) >= 2:
		if systeminfo['System_Ip'][0] == INFO['wanip']:
		    lanip=systeminfo['System_Ip'][1]
		else:
		    lanip=systeminfo['System_Ip'][0] 
	    else:
		lanip=''
		
            return render_to_response('adddev.html',{'nowt':nowt,'uset':uset,'systeminfo':systeminfo,'initip':INFO['wanip'],'srvmodel1':systeminfo['Device_Model'],\
					'brand1':systeminfo['Device_brand'],'Device_conf':systeminfo['Device_conf'],'Device_Sn':systeminfo['Device_Sn'],'IPMI_IP':systeminfo['IPMI_IP'],\
					 'Device_lanip':lanip,'error':error,'User':User,'mroom':mroom,'cabinet':cabinet,'project':project,\
					 'subprojects':subprojects,'brand':brand,'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,\
					 'srvmodel':srvmodel})

            
	cmd="Device.objects.filter(wanip='%s')" %(INFO['wanip'])
        diff=eval(cmd)
            
        for a in diff:
	    
            if a.wanip == INFO['wanip'].strip():
	        Results = Device.objects.all()
                return render_to_response('adddev.html',{'Results':Results,'error':"此IP已经存在,请不要重复添加",'User':User,'mroom':mroom,\
						  'cabinet':cabinet,'project':project,'subprojects':subprojects,'brand':brand,\
						  'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,'srvmodel':srvmodel,'subprojects':subprojects,'nowt':nowt,'uset':uset})


        #检测基础数据表是否有数据，没有插入

	checkbase()
	#保存新增

	DBDA = Device(wanip=INFO['wanip'].strip(),lanip=INFO['lanip'].strip(),mip=INFO['mip'].strip(),mroom=INFO['mroom'].strip(),\
                      cabinet=INFO['cabinet'].strip(),project=INFO['project'].strip(),runsrv=INFO['runsrv'].strip(),brand=INFO['brand'].strip(),\
                      srvmodel=INFO['srvmodel'].strip(),cconfig=INFO['cconfig'].strip(),riskowner=INFO['riskowner'].strip(),purchased=INFO['purchased'].strip(),\
                      usedate=INFO['usedate'].strip(),distributor=INFO['distributor'].strip(),contractsn=INFO['contractsn'].strip(),price=INFO['price'].strip(),\
                      servicesn=INFO['servicesn'].strip(),subprojects=INFO['subprojects'].strip(),exp=INFO['exp'].strip(),stats=INFO['stats'].strip(),\
                      remarks=INFO['remarks'].strip(),machine_type=INFO['machine_type'].strip(),device_port=INFO['device_port'].strip(),bakpath=INFO['bakpath'].strip(),bakipaddr=INFO['bakipaddr'].strip())

        DBDA.save()

	sql="update uxin_systeminit_log set in_device='0' where ip='%s'" %(INFO['wanip'])
	dbutil.device_update(sql)

	log_info("登陆用户:" + str(User) + " 新增设备:" +str(INFO['wanip']) + " 成功")
	
	#新增机器,添加监控
        #判断是否有相同IP 端口
        sql = 'select * from uxin_alarm where Alarm_ip="%s" and Alarm_server="ping"' %(INFO['wanip'].strip())
        diff=dbutil.select(sql)

        sql = 'select * from uxin_alarm where Alarm_ip="%s" and (Alarm_type="progress" or Alarm_type="tcp" or Alarm_type="ping" or Alarm_type="udp") ' %(INFO['wanip'].strip())
        diff_progress=dbutil.select(sql)

	if diff or diff_progress:
	    pass
	else:
	    #从数据库 找出所有运维组人员，添加
	    sql="insert into uxin_alarm values(NULL,'ping','%s','check_alive','check_alive','30','0','0','3','','','','0','','','','运维组短信,运维组邮件','0','0','0','0','汪龙,罗明,佘亚飞,唐杨')" %(INFO['wanip'])
	    dbutil.device_update(sql)


	return render_to_response('adddev.html',{'DBDA':'OK','User':User,'mroom':mroom,'cabinet':cabinet,'project':project,'subprojects':subprojects,'brand':brand,\
                              'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,'srvmodel':srvmodel,'subprojects':subprojects,'nowt':nowt,'uset':uset})

	

            
    Results = Device.objects.all()
    return render_to_response('adddev.html',{'Results':Results,'User':User,'mroom':mroom,'cabinet':cabinet,'project':project,'subprojects':subprojects,'brand':brand,\
			      'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,'srvmodel':srvmodel,'subprojects':subprojects,'nowt':nowt,'uset':uset})

@login_required()
def Deldev(request):
    User=request.user.username
    if permissions_check(User,'device_delete') != True:
        return render_to_response('permissions_error.html')
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST':
        ip = request.REQUEST.get('IP')
        DLID = request.REQUEST.get('DLID')
        if DLID and not ip:
            Results = Device.objects.get(id=DLID)
	    if permissions_user_check(User,Results.wanip) != True:
		return render_to_response('permissions_error.html')
	    log_info("登陆用户:" + str(User) + " 删除设备:" +str(Results) + " 成功")
            Results.delete()
            Resultss = Device.objects.all()
            return render_to_response('deldev.html',{'results':Resultss,'User':User,})
        if ip :
            Results = Device.objects.filter(wanip__icontains=ip)
            return render_to_response('deldev.html',{'results':Results,'User':User,})
        Results = Device.objects.all()
        return render_to_response('deldev.html',{'results':Results,'User':User,})

    if 'view' in request.GET and request.GET['view']:
        view = request.GET['view']
        Results = Device.objects.filter(id__icontains=view)
        return render_to_response('search_from.html',{'results': Results,'User':User,'mroom':mroom,'cabinet':cabinet,'project':project,\
                              'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,'srvmodel':srvmodel,'subprojects':subprojects})
    return render_to_response('deldev.html',{'User':User,})

def checkbase():
    diffinfo={}
    for base in baseTuple:
        cmd="select %s from uxin_devbase where %s = '%s' limit 1" %(base,base,INFO[base])
        diff=dbutil.select(cmd)
        if not diff:
	    #初始化所有值
	    for zero in baseTuple:
	        diffinfo[zero]=" "
	    #给不同的项赋值
            diffinfo[base]=INFO[base]
	    #只要数据不同，就新增
            sql='insert into uxin_devbase (%s,%s,%s,%s,%s,%s,%s,%s) values("%s","%s","%s","%s","%s","%s","%s","%s");' \
        	%('cabinet','project','brand','cconfig','distributor','riskowner','subprojects','srvmodel',\
	        diffinfo['cabinet'],diffinfo['project'],diffinfo['brand'],diffinfo['cconfig'],\
        	diffinfo['distributor'],diffinfo['riskowner'],diffinfo['subprojects'],diffinfo['srvmodel'])


	    sql=sql.encode("utf-8")
	    device_update(sql)

def export_csv_data():
    ISOTIMEFORMAT='%Y%m%d%H%M%S'    #设置显示的时间格式
    timestr =  time.strftime( ISOTIMEFORMAT, time.localtime())
    filename ="uxin_{0}.xls" .format(timestr)
    dataset = tablib.Dataset()
    dataset.headers = [u'快速服务编号'.encode('utf8'),u'机房'.encode('utf8'),u'机柜'.encode('utf8'),u'机器类型'.encode('utf8'),u'服务器品牌'.encode('utf8'),u'服务器型号'.encode('utf8'),\
                   u'服务器配置'.encode('utf8'),u'外网IP'.encode('utf8'),u'内网IP'.encode('utf8'),u'远程IP'.encode('utf8'),u'所属项目'.encode('utf8'),\
                   u'子项目'.encode('utf8'),u'责任人'.encode('utf8'),u'设备供应商'.encode('utf8'),u'购买日期'.encode('utf8'),\
                   u'上架日期'.encode('utf8'),u'合同编号'.encode('utf8'),u'价格'.encode('utf8'),u'保修期限'.encode('utf8'),u'使用状态'.encode('utf8'),\
                   u'备注'.encode('utf8'),u'业务用途'.encode('utf8')]
    for i in dbutil.select(sql="select * from uxin_device"):

        dataset.append((i['servicesn'],i['mroom'],i['cabinet'],i['machine_type'],i['brand'],i['srvmodel'],i['cconfig'],\
           i['wanip'],i['lanip'],i['mip'],i['project'],i['subprojects'],i['riskowner'],\
           i['distributor'],i['purchased'],i['usedate'],i['contractsn'],i['price'],i['exp'],i['stats'],i['remarks'],i['runsrv']))

#    data = export(date_from,date_to)#返回从数据库中查询出的数据，headers是数据库中的表字段
#    dataset = tablib.Dataset(*data, headers=headers) #*data是与headers相对应的列的内容
#    data2 = [('1', 'Rooney', 20),('2', 'John', 30)]
#    dataset2 = tablib.Dataset(*data2, headers=('area', 'user', 'recharge'))
#    databook = tablib.Databook([dataset,dataset2])
    output=StringIO.StringIO()
    output.write(dataset.xls)
#    response = make_response(output.getvalue())
    response = HttpResponse(mimetype='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename=uxin.xls'
    return response


@login_required()
def Chadev(request):
    User=request.user.username
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    for i in Tuple:
        INFO[i] = request.REQUEST.get(i)

    #未加check_alivd监控 device首页加红显示
    isnullsql="select a.*,b.Alarm_name from (select * from uxin_device where stats != '下架') a left join (select Alarm_ip,group_concat(Alarm_name) as Alarm_name from uxin_alarm group by Alarm_ip) b on  a.wanip=b.Alarm_ip where Alarm_name IS NULL OR Alarm_name not like '%heck_aliv%'"
    isnull=dbutil.select(isnullsql)


    #未加设备管理监控 device首页加红显示
    progressisnullsql="select a.*,b.Alarm_name from (select wanip,lanip from uxin_device where stats != '下架') a left join (select Alarm_ip,group_concat(Alarm_name) as Alarm_name from uxin_alarm group by Alarm_ip) b on  a.wanip=b.Alarm_ip where Alarm_name IS NULL OR Alarm_name not like '%进程%'"
    progressisnull=dbutil.select(progressisnullsql)

    
    if permissions_check(User,'device_view') != True:
        return render_to_response('permissions_error.html')

    #机器检测结果自动刷新
    initinfo = request.REQUEST.get('autoinfo')
    if 'view' in request.GET and request.GET['view']:
        view = request.GET['view']
        if 'IP' in  request.GET and  request.GET['IP']:
            ip= request.GET['IP']
	    cmd="python %s/oms/lib/sys_check.py %s" %(DIRS['OMS_ROOT'],ip)
	    os.system(cmd)
	sql='select * from uxin_device where ID="%s"' %view
        Results = select(sql)
        return render_to_response('search_from.html',{'results': Results,'User':User})


    if 'ipaddr' in request.GET and request.GET['ipaddr']:
        ipaddr = request.GET['ipaddr']
        sql='select * from uxin_device where wanip="%s" or lanip="%s"' %(ipaddr,ipaddr)
        Results = select(sql)
        return render_to_response('search_from.html',{'results': Results,'User':User})

       #导出CSV
    if 'excel' in request.GET and request.GET['excel'] == '1':
        dataset = tablib.Dataset()
        dataset.headers = [u'快速服务编号'.encode('utf8'),u'机房'.encode('utf8'),u'机柜'.encode('utf8'),u'机器类型'.encode('utf8'),u'服务器品牌'.encode('utf8'),u'服务器型号'.encode('utf8'),\
        		  u'服务器配置'.encode('utf8'),u'外网IP'.encode('utf8'),u'内网IP'.encode('utf8'),u'远程IP'.encode('utf8'),u'所属项目'.encode('utf8'),\
		          u'子项目'.encode('utf8'),u'责任人'.encode('utf8'),u'设备供应商'.encode('utf8'),u'购买日期'.encode('utf8'),\
		          u'上架日期'.encode('utf8'),u'合同编号'.encode('utf8'),u'价格'.encode('utf8'),u'保修期限'.encode('utf8'),u'使用状态'.encode('utf8'),\
		          u'备注'.encode('utf8'),u'业务用途'.encode('utf8')]
	for i in dbutil.select(sql="select * from uxin_device"):

    	    dataset.append((i['servicesn'],i['mroom'],i['cabinet'],i['machine_type'],i['brand'],i['srvmodel'],i['cconfig'],\
                 i['wanip'],i['lanip'],i['mip'],i['project'],i['subprojects'],i['riskowner'],\
                 i['distributor'],i['purchased'],i['usedate'],i['contractsn'],i['price'],i['exp'],i['stats'],i['remarks'],i['runsrv']))


	open('/data/webdata/oms/oms/csv/device.xls','wb').write(dataset.xls)

        f =open('/data/webdata/oms/oms/csv/device.xls')
	data = f.read()
	f.close()

        response = HttpResponse(data,mimetype='application/octet-stream')
        response['Content-Disposition'] = 'attachment; filename=device.xls'
        return response


    if request.method == 'POST' or request.GET:
        wanip = request.REQUEST.get('Type')
        MDID = request.REQUEST.get('MDID')
        Change = request.REQUEST.get('Change')
        COPY = request.REQUEST.get('COPY')
        isnull = request.REQUEST.get('addmonitor')
        progressisnull = request.REQUEST.get('addmonitorprogress')
        nullabc = request.REQUEST.get('nullabc')





        if isnull:
            #查询监控表是否有Ping监控
            selectping_sql='select Alarm_ip,Alarm_type from uxin_alarm where Alarm_ip="%s" and Alarm_type="ping"' %(isnull)
            selectping=dbutil.device_update(selectping_sql)
            if not selectping:
                sql="insert into uxin_alarm values(NULL,'ping','%s','check_alive','check_alive','30','0','0','3','','','','0','','','','运维组短信,运维组邮件','0','0','0','0','','')" %(isnull)
                dbutil.device_update(sql)

            #更新结果
            sql='select a.*,b.Alarm_name from (select * from uxin_device) a left join (select Alarm_ip,group_concat(Alarm_name) as Alarm_name from uxin_alarm group by Alarm_ip) b on a.wanip=b.Alarm_ip'
            Results = dbutil.select(sql)

            #获取最新未加入监控的数据
            isnullsql="select a.*,b.Alarm_name from (select * from uxin_device) a left join (select Alarm_ip,group_concat(Alarm_name) as Alarm_name from uxin_alarm group by Alarm_ip) b on  a.wanip=b.Alarm_ip where Alarm_name  IS NULL;"
            isnull=dbutil.select(isnullsql)

            #返回页面
            return render_to_response('seadev.html',{'results':Results,'User':User,'mroom':mroom,'cabinet':cabinet,'project':project,'subprojects':subprojects,'brand':brand,\
                                      'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,'srvmodel':srvmodel,'isnull':isnull,'Change1':'Change1'})


	if progressisnull:
            #查询监控表是否原来有进程监控
            select_sql='select Alarm_ip,Alarm_type from uxin_alarm where Alarm_ip="%s" and Alarm_type="progress"' %(progressisnull)
            select_progress=dbutil.device_update(select_sql)
            if not select_progress:
                sql="insert into uxin_alarm values(NULL,'progress','%s','进程监控','ssh','120','0','0','3','','','','0','','','','运维组邮件','0','0','1','0','','')" %(progressisnull)
                dbutil.device_update(sql)

            #更新结果
            sql='select a.*,b.Alarm_name from (select * from uxin_device) a left join (select Alarm_ip,group_concat(Alarm_name) as Alarm_name from uxin_alarm group by Alarm_ip) b on a.wanip=b.Alarm_ip'
            Results = dbutil.select(sql)

            #获取最新ping数据
            isnullsql="select a.*,b.Alarm_name from (select * from uxin_device) a left join (select Alarm_ip,group_concat(Alarm_name) as Alarm_name from uxin_alarm group by Alarm_ip) b on  a.wanip=b.Alarm_ip where Alarm_name  IS NULL;"
            isnull=dbutil.select(isnullsql)
            #获取最新进程监控
	    progressisnullsql="select a.*,b.Alarm_name from (select * from uxin_device) a left join (select Alarm_ip,group_concat(Alarm_name) as Alarm_name from uxin_alarm group by Alarm_ip) b on  a.wanip=b.Alarm_ip where Alarm_name IS NULL"
    	    progressisnull=dbutil.select(progressisnullsql)


            #返回页面
            return render_to_response('seadev.html',{'results':Results,'User':User,'mroom':mroom,'cabinet':cabinet,'project':project,'subprojects':subprojects,'brand':brand,\
                                      'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,'srvmodel':srvmodel,'isnull':isnull,'progressisnull':progressisnull,'Change1':'Change1'})



	    
        if wanip and MDID and Change:
            if permissions_check(User,'device_change') != True:
        	return render_to_response('permissions_error.html')


	    if permissions_user_check(User,INFO['wanip']) != True:
        	return render_to_response('permissions_error.html')

            for i in Tuple:
                INFO[i] = request.REQUEST.get(i)

            #检测基础数据表是否有数据，没有插入
	    checkbase()
	    sql='select baklog from uxin_device where ID="%s"' %(MDID)
            Results = select(sql)
	    #if check_ip(INFO['Alarm_ip']) != 'ok':
	    if INFO['bakipaddr'].strip() and INFO['bakipaddr'].strip() != '':
		for i in INFO['bakipaddr'].replace("\n"," ").split(" "):
	            if check_ip(i) != 'ok':
                        return render_to_response('chadev.html',{'Results':Results,'Change':i + ' 备份IP格式错误，请检查输入' ,'User':User,'mroom':mroom,\
                                                  'cabinet':cabinet,'project':project,'subprojects':subprojects,'brand':brand,\
                                                  'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,'srvmodel':srvmodel})


	    if check_ip(INFO['wanip'].strip()) != 'ok':
		return render_to_response('chadev.html',{'Results':Results,'Change':INFO['wanip'].strip() + ' 外网IP错误，请检查输入' ,'User':User,'mroom':mroom,\
                                                  'cabinet':cabinet,'project':project,'subprojects':subprojects,'brand':brand,\
                                                  'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,'srvmodel':srvmodel})
			
		
	    #修改需要加上id, 复制并新增不需要加上ID
            DBDA = Device(id=MDID,wanip=INFO['wanip'].strip(),lanip=INFO['lanip'].strip(),mip=INFO['mip'].strip(),mroom=INFO['mroom'].strip(),\
                      cabinet=INFO['cabinet'].strip(),project=INFO['project'].strip(),runsrv=INFO['runsrv'].strip(),brand=INFO['brand'].strip(),\
                      srvmodel=INFO['srvmodel'].strip(),cconfig=INFO['cconfig'].strip(),riskowner=INFO['riskowner'].strip(),purchased=INFO['purchased'].strip(),\
                      usedate=INFO['usedate'].strip(),distributor=INFO['distributor'].strip(),contractsn=INFO['contractsn'].strip(),price=INFO['price'].strip(),\
                      servicesn=INFO['servicesn'].strip(),subprojects=INFO['subprojects'].strip(),exp=INFO['exp'].strip(),stats=INFO['stats'].strip(),\
		      remarks=INFO['remarks'].strip(),machine_type=INFO['machine_type'].strip(),device_port=INFO['device_port'].strip(),\
		      bakpath=INFO['bakpath'].strip(),baklog=Results[0]['baklog'],bakipaddr=INFO['bakipaddr'].strip())
            DBDA.save()
	    log_info("登陆用户:" + str(User) + " 修改设备:" +str(INFO['wanip']) + " 成功")
            return render_to_response('chadev.html',{'Change':'OK','User':User,'mroom':mroom,'cabinet':cabinet,'project':project,'subprojects':subprojects,'brand':brand,\
                                      'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,'srvmodel':srvmodel})

        if wanip and COPY and Change:
            if permissions_check(User,'device_change') != True:
                return render_to_response('permissions_error.html')
            if permissions_user_check(User,INFO['wanip']) != True:
                return render_to_response('permissions_error.html')
            for i in Tuple:
                INFO[i] = request.REQUEST.get(i)
	   

	    #检测IP是否重复
            cmd="Device.objects.filter(wanip='%s')" %(INFO['wanip'])
            diff=eval(cmd)
            for a in diff:

                if a.wanip == INFO['wanip']:
                    Results = '1'
                    return render_to_response('chadev.html',{'Results':Results,'Change':"此IP已经存在,请不要重复添加",'User':User,'mroom':mroom,\
                                                  'cabinet':cabinet,'project':project,'subprojects':subprojects,'brand':brand,\
                                                  'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,'srvmodel':srvmodel})
            #检测基础数据表 是否有数据，没有插入
	    checkbase()
	    #复制写入device表
            DBDA = Device(wanip=INFO['wanip'].strip(),lanip=INFO['lanip'].strip(),mip=INFO['mip'].strip(),mroom=INFO['mroom'].strip(),\
                      cabinet=INFO['cabinet'].strip(),project=INFO['project'].strip(),runsrv=INFO['runsrv'].strip(),brand=INFO['brand'].strip(),\
                      srvmodel=INFO['srvmodel'].strip(),cconfig=INFO['cconfig'].strip(),riskowner=INFO['riskowner'].strip(),purchased=INFO['purchased'].strip(),\
                      usedate=INFO['usedate'].strip(),distributor=INFO['distributor'].strip(),contractsn=INFO['contractsn'].strip(),price=INFO['price'].strip(),\
                      servicesn=INFO['servicesn'].strip(),subprojects=INFO['subprojects'].strip(),exp=INFO['exp'].strip(),stats=INFO['stats'].strip(),\
                      remarks=INFO['remarks'].strip(),machine_type=INFO['machine_type'].strip(),device_port=INFO['device_port'].strip(),bakpath=INFO['bakpath'].strip(),\
		      bakip=INFO['bakip'].strip())

            DBDA.save()
	    log_info("登陆用户:" + str(User) + " 复制设备:" +str(INFO['wanip']) + " 成功")


        #新增机器,添加监控
            #查询监控表是否有Ping监控
            selectping_sql='select Alarm_ip,Alarm_type from uxin_alarm where Alarm_ip="%s" and Alarm_type="ping"' %(isnull)
            selectping=dbutil.device_update(selectping_sql)
            if not selectping:
                sql="insert into uxin_alarm values(NULL,'ping','%s','check_alive','check_alive','30','0','0','3','','','','0','','','','运维组短信,运维组邮件','0','0','0','0','')" %(INFO['wanip'])
                dbutil.device_update(sql)
            return render_to_response('chadev.html',{'Change':'OK','User':User,'mroom':mroom,'cabinet':cabinet,'project':project,'subprojects':subprojects,'brand':brand,\
                                      'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,'srvmodel':srvmodel})

	#设备查询 【多条件关连】

        if wanip and not MDID and not COPY:

	    #分各业务权限查询
	
	    #定义默认的查询语句
#	    find="select * from uxin_device where 0=0 "
            find="select a.*,b.Alarm_name from (select * from uxin_device) a left join (select Alarm_ip,group_concat(Alarm_name) as Alarm_name from uxin_alarm group by Alarm_ip) b on a.wanip=b.Alarm_ip where 0=0 "
	    

		#使用django原生 查询1
		#find='Device.objects.all()'

       	    #获取每个参数的值
            for i in Tuple:
                INFO[i] = request.REQUEST.get(i)
                #根据得到的参数,生成相应的SQL
                if INFO[i]:

		    #使用django原生 查询2
                    #find=find+".filter(%s__icontains='%s')" %(i,INFO[i].strip())
		    find = find + ' and %s like "%%%s%%" ' %(i,INFO[i].strip())



	    #find = "select * from uxin_device"

	    log_info("登陆用户:" + str(User) + " SQL语句:" +str(find) + " 成功")
	    #使用django原生 查询3
            #Results=eval(find)
	    Results=dbutil.select(find)
            return render_to_response('seadev.html',{'results':Results,'User':User,'mroom':mroom,'cabinet':cabinet,'project':project,\
                                 'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,'srvmodel':srvmodel,'subprojects':subprojects,'isnull':isnull})


        if MDID:
            if permissions_check(User,'device_change') != True:
                return render_to_response('permissions_error.html')
	    Results = Device.objects.get(id=MDID)
            if permissions_user_check(User,Results.wanip) != True:
                return render_to_response('permissions_error.html')





            if initinfo:
                systeminfo = Hardware.exe_cmd(INFO['wanip'],INFO['device_port'])

                if systeminfo:
                 try:
                    systeminfo = dict(eval(systeminfo[0]))
                    error = ''
                 except:
                    systeminfo = {'System_Ip': ['', ''], 'Device_conf': '', 'Device_Model': '', 'Device_Sn': '', 'Device_brand': '', 'Device_Type': '','IPMI_IP': ''}
                    error= str(INFO['wanip']) + '  Authentication Error'
                else:
                    systeminfo = {'System_Ip': ['', ''], 'Device_conf': '', 'Device_Model': '', 'Device_Sn': '', 'Device_brand': '', 'Device_Type': '','IPMI_IP': ''}
                    error= str(INFO['wanip']) + '  Authentication Error'


                if len(systeminfo['System_Ip']) >= 2:
                    if systeminfo['System_Ip'][0] == INFO['wanip']:
                        lanip=systeminfo['System_Ip'][1]
                    else:
                        lanip=systeminfo['System_Ip'][0]
                else:
                    lanip=''


                return render_to_response('chadev.html',{'syteiminfo':'1','MDID':Results,'User':User,'mroom':mroom,'cabinet':cabinet,'project':project,'subprojects':subprojects,'brand':brand,\
                                                         'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,'srvmodel':srvmodel,'error':error,\
							 'Device_brand':systeminfo['Device_brand'],'Device_conf':systeminfo['Device_conf'],'Device_Model':systeminfo['Device_Model'],\
							 'Device_Sn':systeminfo['Device_Sn'],'Device_lanip':lanip,'IPMI_IP':systeminfo['IPMI_IP']})








	    #不自动获取配置返回默认

            return render_to_response('chadev.html',{'MDID':Results,'User':User,'mroom':mroom,'cabinet':cabinet,'project':project,'subprojects':subprojects,'brand':brand,\
                                      'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,'srvmodel':srvmodel})
        if COPY:
            if permissions_check(User,'device_change') != True:
                return render_to_response('permissions_error.html')
            Results = Device.objects.get(id=COPY)
	    

            wanip=Results.wanip
            if permissions_user_check(User,wanip) != True:
                return render_to_response('permissions_error.html')




            if initinfo:
                systeminfo = Hardware.exe_cmd(INFO['wanip'],INFO['device_port'])

                if systeminfo:
                 try:
                    systeminfo = dict(eval(systeminfo[0]))
                    error = ''
                 except:
                    systeminfo = {'System_Ip': ['', ''], 'Device_conf': '', 'Device_Model': '', 'Device_Sn': '', 'Device_brand': '', 'Device_Type': '','IPMI_IP': ''}
                    error= str(INFO['wanip']) + '  Authentication Error'
                else:
                    systeminfo = {'System_Ip': ['', ''], 'Device_conf': '', 'Device_Model': '', 'Device_Sn': '', 'Device_brand': '', 'Device_Type': '','IPMI_IP': ''}
                    error= str(INFO['wanip']) + '  Authentication Error'


            	if len(systeminfo['System_Ip']) >= 2:
                    if systeminfo['System_Ip'][0] == INFO['wanip']:
                        lanip=systeminfo['System_Ip'][1]
                    else:
                        lanip=systeminfo['System_Ip'][0]
                else:
                    lanip=''


                return render_to_response('chadev.html',{'syteiminfo':'1','COPY':Results,'User':User,'mroom':mroom,'cabinet':cabinet,'project':project,'subprojects':subprojects,'brand':brand,\
                                                         'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,'srvmodel':srvmodel,'error':error,\
                                                         'Device_brand':systeminfo['Device_brand'],'Device_conf':systeminfo['Device_conf'],'Device_Model':systeminfo['Device_Model'],\
                                                         'Device_Sn':systeminfo['Device_Sn'],'Device_lanip':lanip,'IPMI_IP':systeminfo['IPMI_IP'],'initip':INFO['wanip']})






            return render_to_response('chadev.html',{'COPY':Results,'User':User,'mroom':mroom,'cabinet':cabinet,'project':project,'subprojects':subprojects,'brand':brand,\
                                      'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,'srvmodel':srvmodel})
        else:
#            Results = Device.objects.all()
	    sql='select a.*,b.Alarm_name from (select * from uxin_device) a left join (select Alarm_ip,group_concat(Alarm_name) as Alarm_name from uxin_alarm group by Alarm_ip) b on a.wanip=b.Alarm_ip'
	    Results = dbutil.select(sql)
            return render_to_response('seadev.html',{'results':Results,'User':User,'mroom':mroom,'cabinet':cabinet,'project':project,'subprojects':subprojects,'brand':brand,\
                                      'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,'srvmodel':srvmodel,'isnull':isnull})
#    return render_to_response('chadev.html',{'mroom':mroom,'cabinet':cabinet,'project':project,'subprojects':subprojects,'brand':brand,\
#                                      'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,'srvmodel':srvmodel,'subprojects':subprojects})






#   sql='select * from uxin_device'
    sql='select a.*,b.Alarm_name from (select * from uxin_device) a left join (select Alarm_ip,group_concat(Alarm_name) as Alarm_name from uxin_alarm group by Alarm_ip) b on a.wanip=b.Alarm_ip'
    Results = dbutil.select(sql)
#    Results = Device.objects.all()
    return render_to_response('seadev.html',{'results':Results,'User':User,'mroom':mroom,'cabinet':cabinet,'project':project,'subprojects':subprojects,'brand':brand,\
                                      'cconfig':cconfig,'distributor':distributor,'riskowner':riskowner,'srvmodel':srvmodel,'isnull':isnull,'progressisnull':progressisnull})




@login_required()
def Initdev(request):
    User=request.user.username
    if permissions_check(User,'device_init_view') != True:
        return render_to_response('permissions_error.html')
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    checkinit=config.checkinit
    if request.GET or request.method == 'POST':
        check_init= request.REQUEST.get('check_init')
	IP = request.REQUEST.get('IPADDR')
	mroom = request.REQUEST.get('mroom')
	init = request.REQUEST.get('init')
	initport = request.REQUEST.get('initport')
	view = request.REQUEST.get('view')
	flush = request.REQUEST.get('flush')
#	user = request.GET['user']
	initpassword = request.REQUEST.get('password')


        if view:
            log = Systeminit_log.objects.all()
	    if flush:
	        #更新与设备管理器的对比结果，保存到is_device字段
	        cmd="Device.objects.filter(wanip='%s')" %(flush)
		diff=eval(cmd)
		log_info(str(diff))
		if diff and diff !='':
		    for a in diff:
		        if a.wanip == flush:
		            s=0
		else:
		    s=11
		sql="update uxin_systeminit_log set in_device='%s' where ip='%s'" %(s,flush)
		log_error(str(sql))
		dbutil.device_update(sql)


		sql='select * from uxin_systeminit_log'
	        log = dbutil.select(sql)
		return render_to_response('initdev.html',{'log':log,'User':User})
            return render_to_response('initdev.html',{'log':log,'User':User})

	if mroom and mroom != '':
	    pass
	else:
	    mroom='oms'
	
	if init and IP:
	    if permissions_check(User,'device_init') != True:
        	return render_to_response('permissions_error.html')
	    nowtime=(time.strftime("%Y-%m-%d %H:%M:%S"))
	    s = 'echo ' + mroom  + ' > /var/tmp/hostname' + ';echo ' + IP  + ' > /var/tmp/ipaddr'
	    cmd = s + ';' + config.SYSINIT
	    exe=ssh.exe_cmd(IP,cmd +  ' > /dev/null 2>&1 &',port=initport,password=initpassword,username='root')
	    if exe:
   	        sql="delete from uxin_systeminit_log where ip='%s' and  text='1'" %(IP)
		dbutil.device_update(sql)
		results='请等待初始化完成,日志 /var/log/system-init.log'
		DBDA = Systeminit_log(ip=IP,date=nowtime,text='1',user=User)
		DBDA.save()
	    else:
		results=IP + '\n' +  ' 连接失败'
	    
	    log_info("登陆用户:" + str(User) + " 初始化设备:" + str(IP))
	    return render_to_response('initdev.html',{'results':results,'User':User,'IPADDR':IP})
	    


	if IP and check_init:
            if permissions_check(User,'device_init') != True:
                return render_to_response('permissions_error.html')
	    Results=ssh.exe_cmd(IP,checkinit,port=initport,password=initpassword,username='root')
	    if  Results:
		diff=re.search('------',Results)
		if diff:
		    initinfo=''
		else:
		    initinfo='ok'
		Results = IP + '\n' + Results
	    else:
		Results= IP + '    Connection refused'
		initinfo=''
	    return render_to_response('initdev.html',{'results':Results,'User':User,'IPADDR':IP,'initinfo':initinfo,'initpass':initpassword,'initport':initport,'initip':IP,'mroom':mroom})

	else:
	    return render_to_response('initdev.html',{'error':'IP不存在','User':User})


    return render_to_response('initdev.html',{'User':User,})


@login_required() 
def User(request):
    User=request.user.username
    if permissions_check(User,'system_user_add') != True:
        return render_to_response('permissions_error.html')
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})

    #获取3个月后的时间
    nowt=datetime.date.today()
    exptime=str(nowt + datetime.timedelta(days=180))

    if request.GET:
        IP = request.GET['IPADDR']
	view = request.REQUEST.get('view')
	sysuser = request.REQUEST.get('sysuser')
	Button = request.REQUEST.get('Button')
	sudo = request.REQUEST.get('sudo')
	exp = request.REQUEST.get('exp')
	delete = request.REQUEST.get('deluser')
	chauser = request.REQUEST.get('chauser')


	if permissions_user_check(User,IP) != True:
	   return render_to_response('permissions_error.html')

        if delete:
	    if permissions_check(User,'system_user_add') != True:
	    	return render_to_response('permissions_error.html')
            if sysuser == 'root' or sysuser == 'maintain'  or sysuser == 'dev':
		log_info("登陆用户:" + str(User) + " IP: " + str(IP) + " 无权限删除此用户:" + str(sysuser))
                return render_to_response('adduser.html',{'User':User,'IP':IP,'error':'无权限删除此用户','exptime':exptime})

            elif sysuser:
                cmd='userdel -f %s;echo "%s 删除成功"' %(sysuser,sysuser)
		log_info("登陆用户:" + str(User)  + " IP: " + str(IP) + " 删除用户成功:" + str(sysuser))
                Results=ssh.exe_cmd(IP,cmd)
                return render_to_response('adduser.html',{'User':User,'IP':IP,'results':Results,'exptime':exptime})

            else:
                return render_to_response('adduser.html',{'User':User,'IP':IP,'error':'用户为空','exptime':exptime})


        elif chauser:
            if sysuser == 'root' or sysuser == 'maintain' or sysuser == 'dev':
		log_info("登陆用户:" + str(User) +  " IP: " + str(IP) + " 无权限修改此用户:" + str(sysuser))
                return render_to_response('adduser.html',{'User':User,'IP':IP,'error':'无权限修改此用户','exptime':exptime})

            elif sysuser:
		if sudo == 'dev' and exp:
		    log_info("登陆用户:" + str(User) + " IP: " + str(IP) + " 增加DEV权限成功:" + str(sysuser))
		    cmd='usermod -e "%s" %s ; usermod -G %s %s ; echo "%s" 修改成功' %(exp,sysuser,'dev',sysuser,sysuser)
		elif sudo == '0' and exp:
		    log_info("登陆用户:" + str(User) + " IP: " + str(IP) + " 修改为普通权限成功:" + str(sysuser))
		    cmd='usermod -e "%s" %s ; usermod -G "" %s ; echo "%s" 修改成功' %(exp,sysuser,sysuser,sysuser)

		Results=ssh.exe_cmd(IP,cmd)

                return render_to_response('adduser.html',{'User':User,'IP':IP,'results':Results,'exptime':exptime})

            else:
                return render_to_response('adduser.html',{'User':User,'IP':IP,'error':'用户为空','exptime':exptime})


        elif Button:
            if exp and sudo and sysuser:
		se=ssh.exe_cmd(IP,"grep -w '%s' /etc/passwd |awk -F':' '{print $1}'" %sysuser)
		diff=re.search(sysuser,se)
		if diff:
		    return render_to_response('adduser.html',{'error':'帐户已经存在,请不要重复新增','User':User,'IP':IP,'exptime':exptime})
		
		if sudo == 'dev':
		    log_info("登陆用户:" + str(User) +  " IP: " + str(IP) +  " 新增用户+DEV权限成功:" + str(sysuser))
		    cmd='user="%s";useradd -G dev $user; echo passwd | passwd --stdin $user; chage -d 0 $user;usermod -e "%s" $user ;chown $user.$user /home/$user -R; echo "%s" 新增成功' %(sysuser,exp,sysuser)
		else:
		    log_info("登陆用户:" + str(User) + " IP: " + str(IP) +  " 新增普通用户成功:" + str(sysuser))
		    cmd='user="%s";useradd $user; echo passwd | passwd --stdin $user; chage -d 0 $user;usermod -e "%s" $user ;chown $user.$user /home/$user -R; echo "%s" 新增成功' %(sysuser,exp,sysuser)
		Results=ssh.exe_cmd(IP,cmd)
                return render_to_response('adduser.html',{'User':User,'IP':IP,'results':Results,'exptime':exptime})
		
            else: 
                return render_to_response('adduser.html',{'error':'数据为空,请检查','User':User,'IP':IP,'exptime':exptime})


	elif view == '1':
	    cmd='''awk -F':' '$NF  !~  /sbin\/nologin|sbin\/halt|bin\/sync|sbin\/shutdown/{print $1"------------"$7"------------"$6 }' /etc/passwd | grep -Ev '^root--|^maintain--'> /var/tmp/u.log ;cd /var/tmp/;for i in `awk -F'------------' '{print $1}' /var/tmp/u.log`;do p=`id $i`;e=`chage -l  $i | awk '/Account expires/ {print $1,$2,$3,$4,$5,$6,$7}'`;sed -i "s/${i}----.*$/& ------------${e} /g" /var/tmp/u.log;sed -i "s/${i}----.*$/& ------------${p} /g" /var/tmp/u.log ; done;  awk -F'------------' '{printf "%-15s %-15s %-25s %-35s %-0s\\n",$1,$2,$3,$4,$5}'   /var/tmp/u.log  > /var/tmp/uu.log ; cat /var/tmp/uu.log;rm -rf /var/tmp/uu.log
'''
	    Results=ssh.exe_cmd(IP,cmd)
#            out = open('adduser.log','a')
#            print >> out,Results
#	    out.flush()
	    
	    return render_to_response('adduser.html',{'User':User,'IP':IP,'results':Results,'exptime':exptime})
        elif IP:
            return render_to_response('adduser.html',{'User':User,'IP':IP,'exptime':exptime})

    return render_to_response('adduser.html',{'User':User,'IP':IP,'exptime':exptime})
