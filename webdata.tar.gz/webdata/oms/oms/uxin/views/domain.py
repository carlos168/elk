#!/usr/bin/env python
#-*- coding:UTF-8 -*-
from django.http import *
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.contrib.auth.decorators import login_required
from django.utils import simplejson
from uxin.models import Domain
from django.conf import settings
from django.contrib.auth.models import User

from django.template import loader, RequestContext
from LogLib import *
from tool import *
import dbutil
import tablib
import StringIO

@login_required()
def Adddomain(request):
    User=request.user.username
    if permissions_check(User,'domain_add') != True:
        return render_to_response('permissions_error.html')
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST':
        domain_name= request.REQUEST.get('domain_name')
        INFO = {}
        Tuple = ('domain_name','domain_use','valid_date','reg','parsing','register_no','record_type','remark','username','passwd','company')
        if domain_name:
            for i in Tuple:
                INFO[i] = request.REQUEST.get(i)

            DBDA = Domain(domain_name=INFO['domain_name'].strip(),domain_use=INFO['domain_use'].strip(),valid_date=INFO['valid_date'].strip(),reg=INFO['reg'].strip(),\
                       parsing=INFO['parsing'].strip(),register_no=INFO['register_no'].strip(),record_type=INFO['record_type'].strip(),\
                        remark=INFO['remark'].strip(),username=INFO['username'].strip(),passwd=INFO['passwd'].strip(),company=INFO['company'].strip())
            DBDA.save()
	    log_info("登陆用户:" + str(User) + " 新增域名:" +str(INFO['domain_name']) + " 成功")
            return render_to_response('adddomain.html',{'DBDA':INFO,'User':User,'error':'输入错误',})
        else:
            return render_to_response('adddomain.html',{'ERROR':'输入错误','User':User})
    return render_to_response('adddomain.html',{'User':User,'error':'输入错误',})


@login_required()
def Chadomain(request):
    User=request.user.username
    if permissions_check(User,'domain_view') != True:
        return render_to_response('permissions_error.html')
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if 'excel' in request.GET and request.GET['excel'] == '1':
        dataset = tablib.Dataset()
        dataset.headers = [u'域名名称'.encode('utf8'),u'所属公司'.encode('utf8'),u'域名用途'.encode('utf8'),\
			  u'备案类型'.encode('utf8'),u'备案号'.encode('utf8'),u'注册服务商'.encode('utf8'),u'有效期'.encode('utf8')]
                          
        for i in dbutil.select(sql="select * from uxin_domain"):

            dataset.append((i['domain_name'],i['company'],i['domain_use'],i['record_type'],i['register_no'],i['reg'],i['valid_date']))

        open('/data/webdata/oms/oms/csv/domain.xls','wb').write(dataset.xls)

        f =open('/data/webdata/oms/oms/csv/domain.xls')
        data = f.read()
        f.close()

        response = HttpResponse(data,mimetype='application/octet-stream')
        response['Content-Disposition'] = 'attachment; filename=domain.xls'
        return response


    if request.method == 'POST' or request.GET:
        domain_name = request.REQUEST.get('domain_name')
        register_no = request.REQUEST.get('register_no')
        MDID = request.REQUEST.get('MDID')
        DLID = request.REQUEST.get('DLID')
        Change = request.REQUEST.get('Change')
 	view = request.REQUEST.get('VIEW')
        update_stats =  request.REQUEST.get('update')



        if update_stats:
           import tool
           tool.domain_check(update_stats)
           Results = Domain.objects.get(domain_name=update_stats)
           return render_to_response('domain.html',{'VIEW':Results,'User':User},context_instance=RequestContext(request))
	

        if domain_name and MDID and Change:
            if permissions_check(User,'domain_change') != True:
                return render_to_response('permissions_error.html')
            INFO = {}
            Tuple = ('domain_name','domain_use','valid_date','reg','parsing','register_no','record_type','remark','username','passwd','company')
            for i in Tuple:
                INFO[i] = request.REQUEST.get(i)

            DBDA = Domain(id=MDID,domain_name=INFO['domain_name'].strip(),domain_use=INFO['domain_use'].strip(),valid_date=INFO['valid_date'].strip(),reg=INFO['reg'].strip(),\
                       parsing=INFO['parsing'].strip(),register_no=INFO['register_no'].strip(),record_type=INFO['record_type'].strip(),\
			remark=INFO['remark'].strip(),username=INFO['username'].strip(),passwd=INFO['passwd'].strip(),company=INFO['company'].strip())
            DBDA.save()
	    log_info("登陆用户:" + str(User) + " 修改域名:" +str(INFO['domain_name']) + " 成功")
            return render_to_response('domain.html',{'Change':'OK','User':User},context_instance=RequestContext(request)) 
        if domain_name and not MDID:
            Results = Domain.objects.filter(domain_name__icontains=domain_name.strip())
            return render_to_response('domain.html',{'results':Results,'User':User},context_instance=RequestContext(request))
        elif register_no and not MDID:
            Results = Domain.objects.filter(register_no__icontains=register_no.strip())
            return render_to_response('domain.html',{'results':Results,'User':User},context_instance=RequestContext(request))

        elif MDID:
            if permissions_check(User,'domain_change') != True:
                return render_to_response('permissions_error.html')
            Results = Domain.objects.get(id=MDID)
            return render_to_response('domain.html',{'MDID':Results,'User':User},context_instance=RequestContext(request))
        elif DLID and not domain_name:
            if permissions_check(User,'domain_delete') != True:
                return render_to_response('permissions_error.html')
            Results = Domain.objects.get(id=DLID)
            Results.delete()
            Resultss = Domain.objects.all()
	    log_info("登陆用户:" + str(User) + " 删除域名:" +str(Results) + " 成功")
            return render_to_response('domain.html',{'results':Resultss,'User':User},context_instance=RequestContext(request))
	elif view:
	    Results = Domain.objects.get(id=view)
	    return render_to_response('domain.html',{'VIEW': Results,'User':User})
        else:
            sql='select * from uxin_domain ORDER BY delete_time+0 ASC'
            Results =  dbutil.select(sql)
            Results = Domain.objects.all()
            return render_to_response('domain.html',{'results':Results,'User':User},context_instance=RequestContext(request))

        if update_stats:
           import tool
           tool.domain_check(update_stats)
           Results = Domain.objects.get(domain_name=update_stats)
           return render_to_response('domain.html',{'VIEW':Results,'User':User},context_instance=RequestContext(request))


#    if 'VIEW' in request.GET and request.GET['VIEW']:
#        view = request.GET['VIEW']
#        Results = Domain.objects.filter(id__icontains=view)
#        Results = Domain.objects.get(id=view)
#        return render_to_response('domain.html',{'VIEW': Results,'User':User})


#    Results = Domain.objects.all().order_by('-delete_time')
    sql='select * from uxin_domain ORDER BY delete_time+0 ASC'
    Results =  dbutil.select(sql)

    return render_to_response('domain.html',{'results':Results,'User':User},context_instance=RequestContext(request))
