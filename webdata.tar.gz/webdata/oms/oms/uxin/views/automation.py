#!/usr/bin/env python
#-*- coding:UTF-8 -*-
from django.http import *
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.contrib.auth.decorators import login_required
from django.utils import simplejson
from uxin.models import Automation
from uxin.models import Automation_version
from uxin.models import Automatic_deployment
from uxin.models import Auto_cluster_device
from uxin.models import Auto_cluster
from uxin.models import Automation_log
from uxin.models import Automation_device_set
from uxin.models import Automation_device_type
from django.conf import settings
from django.contrib.auth.models import User

from django.template import loader, RequestContext
from LogLib import *
from tool import *
import dbutil
from dbutil import *
import time
import re
import ssh
import commands
import cmdtosql
import base64



@login_required()
def Automation_set(request):
    User=request.user.username
    Results=Automation_device_set.objects.all()
    #Results=Automation_log.objects.all()
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST' or request.GET:
        ipaddr=request.REQUEST.get('ipaddr')
        port=request.REQUEST.get('port')
        username=request.REQUEST.get('username')
        passwd=request.REQUEST.get('passwd')

        if ipaddr and port and username and passwd:
	    try:
	     test_conn=ssh.exe_cmd(ipaddr,'uname',port=int(port),password=passwd,username=username)
	     log_info(test_conn)
	     if str(test_conn) == "\nLinux\n\n":
		DBDA = Automation_device_set(id='1',ipaddr=ipaddr.strip(),port=port.strip(),username=username.strip(),passwd=base64.encodestring(passwd.strip()))
		DBDA.save()
		return render_to_response('automation_set.html',{'User':User,'error':'保存成功','results':Results})
	     else:
		return render_to_response('automation_set.html',{'User':User,'error':'连接机器失败,未保存','results':Results})
	    except Exception, e:
             log_info(e)
	     

    return render_to_response('automation_set.html',{'User':User,'results':Results})


@login_required()
def Automation_type(request):
    User=request.user.username
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST' or request.GET:
        typename=request.REQUEST.get('typename')
        typepath=request.REQUEST.get('typepath')
	DLID = request.REQUEST.get('DLID')
	type = request.REQUEST.get('Type')


	if DLID and not typename:

            delete_r = Automation_device_type.objects.get(id=DLID)
            delete_r.delete()

	    Results = Automation_device_type.objects.all()

            log_info("登陆用户:" + str(User) + " 删除部署类型:" +str(Results) + " 成功")
            return render_to_response('automation_type.html',{'results':Results,'User':User,'DELETE':'DELETE'},context_instance=RequestContext(request))
	    


        if typename and typepath and type:
            try:
	     Automation_device=dbutil.select('select * from uxin_automation_device_set limit 1')[0]

             test_conn=ssh.exe_cmd(Automation_device['ipaddr'],'test -f %s && echo "ok"' %typepath,port=Automation_device['port'],username=Automation_device['username'],password=base64.decodestring(Automation_device['passwd']))

             if test_conn == '\nok\n\n':
                 DBDA = Automation_device_type(typename=typename.strip(),typepath=typepath.strip())
                 DBDA.save()
		 Results = Automation_device_type.objects.all()
                 return render_to_response('automation_type.html',{'User':User,'ERROR':'保存成功','results':Results})
             else:
		 Results = Automation_device_type.objects.all()
                 return render_to_response('automation_type.html',{'User':User,'ERROR':'保存失败，请确保机器上有 "%s" YAML文件' %typepath,'results':Results})
            except Exception, e:
             log_info(e)

    Results = Automation_device_type.objects.all()
    return render_to_response('automation_type.html',{'User':User,'results':Results})





s=Automation_log.objects.all().order_by("-lastdate")
@login_required()
def Log(request):
    User=request.user.username
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    s=Automation_log.objects.all().order_by("-lastdate")
    if request.method == 'POST' or request.GET:
        return render_to_response('automationlog.html',{'User':User,'log':s})
    return render_to_response('automationlog.html',{'User':User,'log':s})


@login_required()
def Add(request):
    User=request.user.username
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST' or request.GET:
        appname = request.REQUEST.get('appname')
        remark = request.REQUEST.get('remark')
	if appname and remark:
            DBDA = Automation(appname=appname.strip(),remark=remark.strip(),adddate=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),\
				role='',updatever='',updatestatus='')
	    try:
             DBDA.save()
	     return render_to_response('automation.html',{'ADDOK':'OK','User':User},context_instance=RequestContext(request))
	    except:
	     return render_to_response('automation.html',{'ADDOK':'OK','User':User,'ERROR':'新增失败'},context_instance=RequestContext(request))

	    
    return render_to_response('automation.html',{'User':User,'ADD':'add'})


@login_required()
def Change(request):
    User=request.user.username
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})

    if request.method == 'POST' or request.GET:
        appname = request.REQUEST.get('appname')
        oldappname = request.REQUEST.get('oldappname')
        remark = request.REQUEST.get('remark')
	MDID = request.REQUEST.get('MDID')
	Change = request.REQUEST.get('Change')
	DLID = request.REQUEST.get('DLID')

        if appname and MDID and Change:
	    Automation.objects.filter(id=MDID).update(appname=appname.strip(),remark=remark.strip())
	    Automation_version.objects.filter(appname=oldappname).update(appname=appname.strip())
	    Automatic_deployment.objects.filter(appname=oldappname).update(appname=appname.strip())
            log_info("登陆用户:" + str(User) + " 修改应用:" +str(appname) + " 成功")
            return render_to_response('automation.html',{'Change':'OK','User':User},context_instance=RequestContext(request))
        if appname and not MDID:
            #Results = Automation.objects.filter(appname__icontains=appname.strip())

	    sql='select a.*,b.appversion from (select * from uxin_automation where appname  like "%%%s%%") a left join (select appname,count(appversion) as appversion from uxin_automation_version group by appname) b on a.appname=b.appname' %(appname.strip())
	    Results=select(sql)
            return render_to_response('automation.html',{'results':Results,'User':User},context_instance=RequestContext(request))

        elif MDID and not Change:
            Results = Automation.objects.get(id=MDID)
            return render_to_response('automation.html',{'MDID':Results,'User':User},context_instance=RequestContext(request))

        elif DLID and not appname:
	    #删除APPNAME
            Results = Automation.objects.get(id=DLID)
	    #删除版本 [不能加 __icontains 因为会模糊匹配]
	    Automation_version.objects.filter(appname=Results).delete()
	    #删除部署信息
	    Automatic_deployment.objects.filter(appname=Results).delete()
	    
            Results.delete()

            Resultss = Automation.objects.all()
            log_info("登陆用户:" + str(User) + " 删除应用:" +str(Results) + " 成功")
            return render_to_response('automation.html',{'results':Resultss,'User':User,'DELETE':'DELETE'},context_instance=RequestContext(request))
        elif appname:
            #Results = Automation.objects.filter(appname__icontains=appname.strip())
	    sql="select a.*,b.appversion from (select * from uxin_automation where appname='%s') a left join (select appname,count(appversion) as appversion from uxin_automation_version group by appname) b on a.appname=b.appname" %(appname.strip())
	    Results=select(sql)
            return render_to_response('automation.html',{'results':Results,'User':User},context_instance=RequestContext(request))
        else:
	    sql="select a.*,b.appversion from (select * from uxin_automation) a left join (select appname,count(appversion) as appversion from uxin_automation_version group by appname) b on a.appname=b.appname"
	    Results=select(sql)
            return render_to_response('automation.html',{'results':Results,'User':User},context_instance=RequestContext(request))
	    
    sql="select a.*,b.appversion from (select * from uxin_automation) a left join (select appname,count(appversion) as appversion from uxin_automation_version group by appname) b on a.appname=b.appname"
    Results=select(sql)
    return render_to_response('automation.html',{'results':Results,'User':User},context_instance=RequestContext(request))



@login_required()
def Addversion(request):
    User=request.user.username
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST' or request.GET:
        appname = request.REQUEST.get('appname')
	appversion = request.REQUEST.get('appversion')
        data_type = request.REQUEST.get('data_type')

        svn_addr = request.REQUEST.get('svn_addr')
        svn_user = request.REQUEST.get('svn_user')
        svn_pass = request.REQUEST.get('svn_pass')
        git_addr = request.REQUEST.get('git_addr')
        git_user = request.REQUEST.get('git_user')
        git_pass = request.REQUEST.get('git_pass')
        git_filename = request.REQUEST.get('git_filename')
        http_addr = request.REQUEST.get('http_addr')
        local_file = request.REQUEST.get('local_filename')
            

        remark = request.REQUEST.get('remark')

	loadlist = request.REQUEST.get('loadlist')
        if appname and appversion and data_type and not loadlist:
	    if data_type == '1' and svn_addr and svn_user and svn_pass:
                DBDA = Automation_version(appname=appname.strip(),appversion=appversion.strip(),data_type='SVN',download_addr=svn_addr.strip(),\
					  username=svn_user.strip(),password=svn_pass.strip(),remark=remark.strip(),adddate=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
		DBDA.save()

	    elif data_type == '2' and git_addr and git_user and git_pass:
                DBDA = Automation_version(appname=appname.strip(),appversion=appversion.strip(),data_type='GIT',download_addr=git_addr.strip(),\
                                          username=git_user.strip(),password=git_pass.strip(),remark=remark.strip(),adddate=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
                DBDA.save()

            elif data_type == '3' and http_addr:
                DBDA = Automation_version(appname=appname.strip(),appversion=appversion.strip(),data_type='HTTP',download_addr=http_addr.strip(),\
                                          remark=remark.strip(),adddate=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
                DBDA.save()

	    else:
		return render_to_response('automationversion.html',{'User':User,'app_name':appname,'ERROR':'输入错误，请检查'},context_instance=RequestContext(request))

	elif appname and appversion and data_type and  loadlist:
            if data_type == '1' and svn_addr and svn_user and svn_pass:
                #查看是否有相应版本,以及目录
		#1. 提取SVN路径目录
		  #1) 获得除http地址的路径，  因为要把整个SVN目录写入规定的目录， 不能直接下到当前目录
                  #    比如： http://172.16.0.90:8188/svn/test/sysadmin/test/12.txt
                  #    要把文件下载到   svn/test/sysadmin/test/ 下， 而不是 ./test/
	
                #a = 'http://172.16.0.90:8188/svn/test/sysadmin/test/'
                #import re
                #strinfo = re.compile(r"http://.*?/")
                #b = strinfo.sub('',a)
                #print b
                #结果 svn/test/sysadmin/test/
		  

		  #2) 获得最终文件名  12.txt
		  #a = 'svn/test/sysadmin/test/'
		  #import re
		  #strinfo = re.compile(r".*/")
		  #b = strinfo.sub('',a)
		  #print b
		  #结果   12.txt
  
	        #2.下载整个目录至 /data/webdata/oms/oms/data/svn/

		#svn status -u ./svn/test/sysadmin/test/    后面是目录， 如果有目录， 直接返回需要更新的文件

		#svnview=subprocess.Popen('ifconfig', shell=True,stdout=subprocess.PIPE)
	        #print svnview.communicate()[0] 
		strinfo = re.compile(r"http://.*?/")
		strinfo1 = re.compile(r".*/")
		#取得SVN本地下载目录路径
		svn_local_path1=strinfo.sub('',svn_addr)
		svn_local_path=re.findall(".*/",svn_local_path1) 
                http_path=re.findall(".*/",svn_addr)
		
		#取得文件名
		svn_file=strinfo1.sub('',svn_local_path1)
		#SVN文件不存在，返回错误， 让用户输入完整路径
		localpath=DIRS['OMS_ROOT']+'/oms/data/svn/'
		if svn_file == '':
		    return render_to_response('automationversion.html',{'User':User,'app_name':appname,'appname':appname,'ADD':'add','ERROR':'请输入文件完整路径'},context_instance=RequestContext(request))
		else:
		    #SVN本地目录是否存在， 不存在建立
#		    status1, output1 = commands.getstatusoutput('test -d %s' %(localpath+svn_local_path[0])))
#		    if status1 != '0':
#		        #拉取SVN版本, 建立一个SVN版本目录， 此过程不下载任何文件  http 要去掉文件名， 本地目录要加好
#		        #status, output = commands.getstatusoutput('/usr/bin/svn --username=%s --password=%s co --depth=empty %s %s' %(svn_user,svn_pass,http_path[0],localpath+svn_local_path[0]))
#			status, output = commands.getstatusoutput('/usr/bin/svn --username=%s --password=%s co %s %s' %(svn_user,svn_pass,http_path[0],localpath+svn_local_path[0]))
#			return render_to_response('automationversion.html',{'User':User,'app_name':appname,'ADD':'add','file_list':output},context_instance=RequestContext(request))
#		    else:

		    #前期先拉所有文件，  对比写入的文件名，是否拉成功，即可
		    svnstatus, svnoutput = commands.getstatusoutput('/usr/bin/svn --username=%s --password=%s checkout %s %s' %(svn_user,svn_pass,http_path[0],localpath+svn_local_path[0]))
		    fp=localpath+svn_local_path[0]+svn_file
		    diffstatus, diffoutput = commands.getstatusoutput('test -f %s' %(fp))
		    
		    if diffstatus == 0:

                	DBDA = Automation_version(appname=appname.strip(),appversion=appversion.strip(),filename=svn_file,filepath=fp,data_type='SVN',download_addr=svn_addr.strip(),\
                                          username=svn_user.strip(),password=svn_pass.strip(),remark=remark.strip(),adddate=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
			try:
	                 DBDA.save()
			except:
			 pass
                        return render_to_response('automationversion.html',{'User':User,'app_name':appname,'appname':appname,'ADD':'add','load_list':svnoutput,\
                                                                            'appversion':appversion,'filename':svn_file},context_instance=RequestContext(request))

	    if data_type == '3' and http_addr:
		localpath=DIRS['OMS_ROOT']+'/oms/data/http/'
                strinfo = re.compile(r".*/")
		http_file = strinfo.sub('',http_addr)
		if http_file == '':
		    return render_to_response('automationversion.html',{'User':User,'app_name':appname,'appname':appname,'ADD':'add','ERROR':'请输入文件完整路径'},context_instance=RequestContext(request))
		else:
		    svnstatus, svnoutput = commands.getstatusoutput('cd %s;curl -C - -O  %s' %(localpath,http_addr))
	 	    diffstatus, diffoutput = commands.getstatusoutput('test -f %s' %(localpath+http_file))
		    if diffstatus == 0:


                        DBDA = Automation_version(appname=appname.strip(),appversion=appversion.strip(),filename=http_file,data_type='HTTP',filepath=localpath+http_file,download_addr=http_addr.strip(),\
                                          remark=remark.strip(),adddate=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
                        try:
                         DBDA.save()
                        except:
                         pass
                        return render_to_response('automationversion.html',{'User':User,'app_name':appname,'appname':appname,'ADD':'add','load_list':' ',\
                                                                            'appversion':appversion,'filename':http_file},context_instance=RequestContext(request))



            if data_type == '4' and local_file:
		localpath=DIRS['OMS_ROOT']+'/oms/data/local_upload/'
		try:
                 DBDA = Automation_version(appname=appname.strip(),appversion=appversion.strip(),filename=local_file,data_type='本地上传',filepath=localpath+local_file,remark=remark.strip(),\
						adddate=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
		 DBDA.save()
		except:
		 pass
                return render_to_response('automationversion.html',{'User':User,'app_name':appname,'appname':appname,'ADD':'add','load_list':' ',\
                                                                            'appversion':appversion,'filename':local_file},context_instance=RequestContext(request))


            if data_type == '2' and git_addr and git_user and git_pass and git_filename:
                localpath=DIRS['OMS_ROOT']+'/oms/data/git/'
		
		#去掉http://  https://
		strinfo = re.compile(r"http://|https://")
		git_addr1 = strinfo.sub('',git_addr)

		#取得目录
                s1 = re.compile(r"http://.*?/|https://.*?/")
		gitpath1=s1.sub('',git_addr)

                s2 = re.compile(r".git")
		gitpath = s2.sub('',gitpath1)
		gitp = localpath+gitpath
	        
		s3 = re.compile(r"^.*/")
		gitp_e = s3.sub('',gitp)

		gitp_a=re.findall(".*/",gitp)[0]


		#git clone  下载远程库
		#进入库目录，  进行 git pull 拉取
                #git fetch
		#git checkout 下载单个文件

		status, output = commands.getstatusoutput('mkdir %s -p;cd %s;git clone http://%s:%s@%s;cd %s;git pull;git fetch;git checkout origin/master -- %s' %(gitp_a,gitp_a,git_user,git_pass,git_addr1,gitp_a+gitp_e,git_filename))
                if status == 0:
                    DBDA = Automation_version(appname=appname.strip(),appversion=appversion.strip(),filename=git_filename,data_type='GIT',filepath=gitp_a+gitp_e+'/'+git_filename,download_addr=git_addr.strip(),\
                             username=git_user.strip(),password=git_pass.strip(),remark=remark.strip(),adddate=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
                    try:
                     DBDA.save()
                    except:
                     pass
                    return render_to_response('automationversion.html',{'User':User,'app_name':appname,'appname':appname,'ADD':'add','load_list':' ',\
                                                                           'appversion':appversion,'filename':git_filename},context_instance=RequestContext(request))


            return render_to_response('automationversion.html',{'User':User,'app_name':appname},context_instance=RequestContext(request))

    return render_to_response('automationversion.html',{'User':User,'ADD':'add','app_name':appname,'appname':appname})


@login_required()
def Changeversion(request):
    User=request.user.username
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})

    if request.method == 'POST' or request.GET:
        appname = request.REQUEST.get('appname')
        appversion = request.REQUEST.get('appversion')
        data_type = request.REQUEST.get('data_type')
        download_addr = request.REQUEST.get('download_addr')
        remark = request.REQUEST.get('remark')
	view = request.REQUEST.get('view')
        MDID = request.REQUEST.get('MDID')
        Change = request.REQUEST.get('Change')
        DLID = request.REQUEST.get('DLID')
        DELNAME = request.REQUEST.get('DELNAME')
        DELVER = request.REQUEST.get('DELVER')

        if appname and MDID and Change:
            Automation_version.objects.filter(id=MDID).update(appversion=appversion.strip(),data_type=data_type.strip(),download_addr=download_addr.strip(),remark=remark.strip())
            log_info("登陆用户:" + str(User) + " 修改版本:" +str(appname) + " 成功")
            return render_to_response('automationversion.html',{'Change':'OK','User':User,'app_name':appname,'viewid':view},context_instance=RequestContext(request))
        if appname and view and not MDID and not DLID:
            Results = Automation_version.objects.filter(appname=appname.strip())
            return render_to_response('automationversion.html',{'results':Results,'User':User,'app_name':appname,'viewid':view},context_instance=RequestContext(request))

        elif MDID and not Change:
            Results = Automation_version.objects.get(id=MDID)
            return render_to_response('automationversion.html',{'MDID':Results,'User':User,'app_name':appname,'viewid':view},context_instance=RequestContext(request))

        elif DLID and DELNAME and DELVER and not appname:
	
	    #版本删除
            Results = Automation_version.objects.get(id=DLID)
            Results.delete()

	    #本次版本部署记录删除
	    auto_Results = Automatic_deployment.objects.filter(appname=DELNAME.strip()).filter(appversion=DELVER.strip())
	    auto_Results.delete()

            Resultss = Automation_version.objects.filter(appname=DELNAME.strip())
            log_info("登陆用户:" + str(User) + " 删除版本:" +str(Results) + " 成功")
            return render_to_response('automationversion.html',{'results':Resultss,'User':User,'app_name':DELNAME,'viewid':view},context_instance=RequestContext(request))
        elif appname:
            Results = Automation_version.objects.filter(appname=appname.strip())
            return render_to_response('automationversion.html',{'results':Results,'User':User,'app_name':appname},context_instance=RequestContext(request))
        else:
            Results = Automation_version.objects.all()
            return render_to_response('automationversion.html',{'results':Results,'User':User,'app_name':name},context_instance=RequestContext(request))
#    Results = Automation_version.objects.all()
#    return render_to_response('automationversion.html',{'results':Results,'User':User},context_instance=RequestContext(request))



@login_required()
def Automaticdeployment(request):
    User=request.user.username
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})

    #集群名
    cluster_name = Auto_cluster.objects.all()
    #部署模式
    Auto_Mode = Automation_device_type.objects.all()

    if request.method == 'POST' or request.GET:
        appname = request.REQUEST.get('appname')
        appversion = request.REQUEST.get('appversion')
        auto_type = request.REQUEST.get('auto_type')
	auto_device = request.REQUEST.get('auto_device')
	remark = request.REQUEST.get('remark')
	parameters = request.REQUEST.get('parameters')
	auto_mode = request.REQUEST.get('auto_mode')
	acc = request.REQUEST.get('acc')
	view = request.REQUEST.get('view')
	cluster_view = request.REQUEST.get('cluster_view')
	cluster_conn = request.REQUEST.get('cluster_conn')
	#文件是否存在
	fe = request.REQUEST.get('file_exist')

        #版本文件名
	sql='select filename,filepath from uxin_automation_version where appname="%s" and appversion="%s"' %(appname,appversion)
        filename1=dbutil.select(sql)
        diffstatus, diffoutput = commands.getstatusoutput('test -f %s' %(filename1[0]['filepath']))
        if diffstatus == 0  and filename1[0]['filename'] != '' :
            file_exist='yes'
        else:
            file_exist='no'


        if appname and not acc and not cluster_view and not cluster_conn:
	    Results = Automatic_deployment.objects.filter(appname=appname.strip()).filter(appversion=appversion.strip())
	    if Results: 
		Results = Automatic_deployment.objects.filter(appname=appname.strip()).filter(appversion=appversion.strip())
                return render_to_response('automaticdeployment.html',{'User':User,'results':Results[0],'cluster_name':cluster_name,'Auto_Mode':Auto_Mode,\
                                                'filename':filename1[0]['filename'],'file_exist':file_exist},context_instance=RequestContext(request))
	    else:
                return render_to_response('automaticdeployment.html',{'User':User,'appname':appname,'appversion':appversion,'view':view,'cluster_name':cluster_name,'Auto_Mode':Auto_Mode,\
                                                'filename':filename1[0]['filename'],'file_exist':file_exist})


	elif cluster_view:
	    Results = Automatic_deployment.objects.filter(appname=appname.strip()).filter(appversion=appversion.strip())
	    if Results:
                Results = Automatic_deployment.objects.filter(appname=appname.strip()).filter(appversion=appversion.strip())
		cluster_ip = Auto_cluster_device.objects.filter(cluster_name=auto_device)
                return render_to_response('automaticdeployment.html',{'User':User,'results':Results[0],'cluster_name':cluster_name,'Auto_Mode':Auto_Mode,\
									'deviceip':cluster_ip,'file_exist':file_exist,'filename':filename1[0]['filename']},context_instance=RequestContext(request))
            else:
		cluster_ip = Auto_cluster_device.objects.filter(cluster_name=auto_device)
                return render_to_response('automaticdeployment.html',{'User':User,'appname':appname,'appversion':appversion,'view':'1','cluster_name':cluster_name,'Auto_Mode':Auto_Mode,\
								       'auto_device':auto_device,'deviceip':cluster_ip,'file_exist':file_exist,'filename':filename1[0]['filename']})

	elif acc and not cluster_view and not cluster_conn and not fe:
	    #查看是否已经部署过
	    ss = Automatic_deployment.objects.filter(appname=appname.strip()).filter(appversion=appversion.strip())
	    sql='select filename,filepath,data_type from uxin_automation_version where appname="%s" and appversion="%s"' %(appname,appversion)
	    #文件路径
            filename1=dbutil.select(sql)
            diffstatus, diffoutput = commands.getstatusoutput('test -f %s' %(filename1[0]['filepath']))



            #本次部署模式
            The_Auto_Mode = dbutil.select("select typepath from uxin_automation_device_type where typename = '%s'" %auto_mode)[0]['typepath']

	    #部署机信息
	    Automation_device=dbutil.select('select * from uxin_automation_device_set limit 1')[0]
	    #部署开始时间
	    autotime = time.strftime("%Y-%m-%d_%H_%M_%S", time.localtime())
	    #上传部署机目录定义
	    uppath='/tmp/oms_auto/' + appname.strip() + '/' + appversion.strip() + '/' + time.strftime("%Y-%m-%d_%H_%M_%S", time.localtime()) + '/'
	    uppathcmd = 'mkdir -p %s' %uppath
	    
	        
		
            if diffstatus == 0 and filename1[0]['filename'] != '':
		file_exist='yes'
	    else:
		file_exist='no'
		

            #部署IP显示
            i=dbutil.select('select wanip from uxin_auto_cluster_device where cluster_name="%s"' %auto_device)
            c=' '
	      #ip计数
	    device_sum=0
	    auto_ip = []
            for a in i:
		device_sum = device_sum + 1
                c = a['wanip'] + ' ' + c
		auto_ip.append(str(a['wanip']))

	    
	    #部署固定参数设置
	    AUTOFILE = "AUTOFILE='%s%s'" %(uppath,filename1[0]['filename'])
	    AUTOFILENAME = "AUTOFILENAME='%s'" %(filename1[0]['filename'])
	
	    AUTOPARAMETER = "AUTOPARAMETER='%s%s'" %(uppath,'parameter')
	    AUTOIPADDR = '''AUTOIPADDR="%s"''' %auto_ip
	    AUTOIPADDR1 = '''host=%s''' %str(auto_ip).replace(", ", ',')
	    auip = """ sed -i -e "s#\\[#\\"\[\\'#" -e "s#, #','#g" -e "s#\\]#'\\]\\"#" """
	    AUTONAME = "AUTONAME='%s'" %appname.strip()
	    AUTOVER = "AUTOVER='%s'" %appversion.strip()
	    if auto_type == '单台依次部署':
		AUTOOPTION="AUTOOPTION=1"
		AUTOOPTION1 = 1
	    elif auto_type == '半数分批部署':
		AUTOOPTION="AUTOOPTION=%s" %(device_sum/2)
		AUTOOPTION1 = device_sum/2
	    elif auto_type == '全数同时部署':
		AUTOOPTION="AUTOOPTION=%s" %device_sum
		AUTOOPTION1 = device_sum
	    else:
		AUTOOPTION="AUTOOPTION=1"
		AUTOOPTION1 = 1

	    
	    if ss:
		#已经部署过,返回之前部署参数
	        Automatic_deployment.objects.filter(appname=appname.strip()).filter(appversion=appversion.strip()).update(auto_type=auto_type,auto_device=auto_device,remark=remark,parameters=parameters,auto_mode=auto_mode,\
						    lastdate=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
		Results = Automatic_deployment.objects.filter(appname=appname.strip()).filter(appversion=appversion.strip())
	    else:
		#初次部署
                try:
                 #部署参数保存
                 DBDA = Automatic_deployment(appname=appname,appversion=appversion,auto_type=auto_type,auto_device=auto_device,remark=remark,parameters=parameters,auto_mode=auto_mode,\
                                                autodate=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),lastdate=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
                 DBDA.save()
		 Results = Automatic_deployment.objects.filter(appname=appname.strip()).filter(appversion=appversion.strip())
		except:
		 pass



	    #更新项目名，状态	
            Automation.objects.filter(appname=appname.strip()).update(lastdate=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),updatever=appversion.strip(),role=User)
		
	    #部署日志 【名称、版本、存放类型、文件名、部署方式、部署日期、部署人、部署IP、部署结果、部署备注、部署详细日志】
	    try:

		try:



		 #直接写ansible动态参数   不用写文件
                 p1 = parameters.replace("\r\n", ' ')
                 para = "%s %s %s %s %s %s %s %s" %(p1,AUTOFILE,AUTOFILENAME,AUTOPARAMETER,AUTOIPADDR1,AUTONAME,AUTOVER,AUTOOPTION)



		 #开始部署动作：
		 #逐步写日志
                 DBADD=Automation_log(appname=appname,appversion=appversion,data_type=filename1[0]['data_type'],filename=filename1[0]['filename'],auto_type=auto_type,\
                                lastdate=autotime,role=User,ip=auto_device+':'+c,status='',remark=remark,result='#---------------------' + appname + ' ' + appversion +' 开始部署 ---------------------#')
                 DBADD.save()


		 #执行部署， 动态参数写临时文件  配置文件部署【暂停】
		 #timename='test_' + time.strftime("%Y-%m-%d_%H_%M_%S", time.localtime())

		 #a,b = commands.getstatusoutput('''echo "%s  %s  %s %s  %s  %s  %s" > /tmp/%s ; %s /tmp/%s ''' %(parameters,AUTOFILE,AUTOPARAMETER,AUTOIPADDR,AUTONAME,AUTOVER,AUTOOPTION,timename,auip,timename))

		 #dbutil.device_update("update uxin_automation_log SET result = CONCAT(result,'\n %s 参数写入本地成功') where appname='%s' and appversion = '%s' and lastdate='%s'\
		 #				" %(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),appname.strip(),appversion.strip(),autotime))


		 #删除所有文件中 .svn .git 目录 防止泄露代码路径
		 #1.获取当前需要部署的文件目录， 而按时间，新建临时目录

		  

		 try:
		  #status1, output1 = commands.getstatusoutput('mkdir %s_%s && cp -a %s %s' %(filename1[0]['filepath'],autotime+'_tmp',filename1[0]['filepath'],filename1[0]['filepath']+'_'+autotime+'_tmp/'))
		  status1, output1 = commands.getstatusoutput('mkdir %s_%s' %(filename1[0]['filepath'],autotime+'_tmp'))
		  #2.解压文件
		  status2, output2 = commands.getstatusoutput('file %s | grep -q "gzip compressed data" && echo zip'  %(filename1[0]['filepath']))
		  

		  if output2 == 'zip':
		      status3, output3 = commands.getstatusoutput('tar zxvf %s -C %s' %(filename1[0]['filepath'],filename1[0]['filepath']+'_'+autotime+'_tmp/'))
		      if status3 != 0:
                          dbutil.device_update("update uxin_automation_log SET result = CONCAT(result,'\n %s 源文件解压失败，部署停止 ') where appname='%s' and appversion = '%s' and lastdate='%s'\
                                           " %(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),appname.strip(),appversion.strip(),autotime))
			  return render_to_response('automationlog.html',{'User':User,'log':s})
		  else:
                      dbutil.device_update("update uxin_automation_log SET result = CONCAT(result,'\n %s 部署源文件不是压缩包，部署停止 ') where appname='%s' and appversion = '%s' and lastdate='%s'\
                                           " %(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),appname.strip(),appversion.strip(),autotime))
		      return render_to_response('automationlog.html',{'User':User,'log':s})

		  #4.得到文件的用户权限, 并加上权限
		  #status3, owner = commands.getstatusoutput("ls -l %s/* | awk -vOFS='.' '{print $3,$4}' |  sed '/^.$/d'  |tail -1" %(filename1[0]['filepath']+'_'+autotime+'_tmp/'))
		  #status4, output4 = commands.getstatusoutput('chown %s %s -R' %(owner,filename1[0]['filepath']+'_'+autotime+'_tmp/'))

		  #5.按时间备份 压缩文件， 且排除.svn   .git 目录
		  
		  status5, output5 = commands.getstatusoutput('mv %s %s_%s_src;cd %s;tar -zcf %s . --exclude=.svn --exclude=.git' %(filename1[0]['filepath'],filename1[0]['filepath'],autotime,\
								filename1[0]['filepath']+'_'+autotime+'_tmp/',\
								filename1[0]['filepath']))

                  dbutil.device_update("update uxin_automation_log SET result = CONCAT(result,'\n %s 过滤压缩包敏感文件完成') where appname='%s' and appversion = '%s' and lastdate='%s'\
                                       " %(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),appname.strip(),appversion.strip(),autotime))
		 except Exception, e:
                  dbutil.device_update("update uxin_automation_log SET result = CONCAT(result,'\n %s 过滤压缩包敏感文件失败') where appname='%s' and appversion = '%s' and lastdate='%s'\
                                   " %(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),appname.strip(),appversion.strip(),autotime))
		 
		 
			
		 
		
		 #建立远程相应目录
		 ssh.exe_cmd(Automation_device['ipaddr'],uppathcmd,port=Automation_device['port'],username=Automation_device['username'],password=base64.decodestring(Automation_device['passwd']))
		 dbutil.device_update("update uxin_automation_log SET result = CONCAT(result,'\n %s 远程目录建立完成') where appname='%s' and appversion = '%s' and lastdate='%s'\
					" %(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),appname.strip(),appversion.strip(),autotime))
		 
		 #上传部署文件至远程部署机
		 upfile=ssh.update_file(Automation_device['ipaddr'],filename1[0]['filepath'],uppath+filename1[0]['filename'],\
					port=Automation_device['port'],username=Automation_device['username'],password=base64.decodestring(Automation_device['passwd']))
		 dbutil.device_update("update uxin_automation_log SET result = CONCAT(result,'\n %s 部署文件上传成功') where appname='%s' and appversion = '%s' and lastdate='%s'\
					" %(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),appname.strip(),appversion.strip(),autotime))


		  
		 #上传参数文件至远程部署机 配置文件部署【暂停】  ansible使用--extra-vars指定主机后， 不会显示错误， 需要自己做对比
		 #ssh.update_file(Automation_device['ipaddr'],'/tmp/'+timename,uppath+'parameter',port=Automation_device['port'],username=Automation_device['username'],password=base64.decodestring(Automation_device['passwd']))
		 #dbutil.device_update("update uxin_automation_log SET result = CONCAT(result,'\n %s 部署参数上传成功') where appname='%s' and appversion = '%s' and lastdate='%s'\
		 #			" %(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),appname.strip(),appversion.strip(),autotime))
		 
		 testoutput=''

		 #写配置文件部署【暂停】
#		 testoutput = ssh.exe_cmd(Automation_device['ipaddr'],'''export `cat %s%s` ; /usr/bin/ansible-playbook  %s --extra-vars "host=$AUTOIPADDR" -f $AUTOOPTION\
#					''' %(uppath,'parameter',The_Auto_Mode),port=Automation_device['port'],username=Automation_device['username'],password=base64.decodestring(Automation_device['passwd']))


		 testoutput = ssh.exe_cmd(Automation_device['ipaddr'],'''/usr/bin/ansible-playbook  %s --extra-vars "%s" -f %s\
					''' %(The_Auto_Mode,para,AUTOOPTION1),port=Automation_device['port'],username=Automation_device['username'],password=base64.decodestring(Automation_device['passwd']))
		 
                 #写入远程输出内容
		 #替换所有的双引号
		 testoutput =  testoutput.replace('"', '')
		 sql11='''update uxin_automation_log SET result = CONCAT(result,"\n %s 远程部署开始 %s")  where appname="%s" and appversion = "%s" and lastdate="%s"''' %(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),testoutput,appname.strip(),appversion.strip(),autotime)
		 cmdtosql.update(sql11)
#                 dbutil.device_update("update uxin_automation_log SET result = '%s' where appname='%s' and appversion = '%s' and lastdate='%s'\
#					" %(testoutput,appname.strip(),appversion.strip(),autotime))
		 

                 dbutil.device_update("update uxin_automation_log SET result = CONCAT(result,'\n #--------------------- %s 远程部署结束 ---------------------#') where appname='%s' and appversion = '%s' and lastdate='%s'\
                                        " %(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),appname.strip(),appversion.strip(),autotime))

		 #判断ansible执行是否成功
		 auto_s=''
		 if testoutput.count("unreachable=0") == testoutput.count("failed=0") == int(device_sum):
		     auto_s='OK'
		 elif testoutput.count("unreachable=0") == 0 or testoutput.count("failed=0") == 0:
		     auto_s='ERROR'
		 else:
		     auto_s='ERROR'
  	         dbutil.device_update("update uxin_automation_log SET status = '%s' where appname='%s' and appversion = '%s' and lastdate='%s'\
					   " %(auto_s,appname.strip(),appversion.strip(),autotime))

	         
		except Exception, e:
		 dbutil.device_update("update uxin_automation_log SET status = 'ERROR' where appname='%s' and appversion = '%s' and lastdate='%s'\
					" %(appname.strip(),appversion.strip(),autotime))
		 return render_to_response('automaticdeployment.html',{'User':User,'results':Results[0],'ERROR':e,'Auto_Mode':Auto_Mode})
	        return render_to_response('automaticdeployment.html',{'User':User,'results':Results[0],'ERROR':'部署结果:'+auto_s,'s':testoutput,'cluster_name':cluster_name,'Auto_Mode':Auto_Mode,'filename':filename1[0]['filename'],\
									'file_exist':file_exist,'Auto_Mode':Auto_Mode},context_instance=RequestContext(request))
	    except:
		return render_to_response('automaticdeployment.html',{'User':User,'appname':appname,'appversion':appversion,'cluster_name':cluster_name,'Auto_Mode':Auto_Mode})
	    
		
	return render_to_response('automaticdeployment.html',{'User':User,'appname':appname,'appversion':appversion,'cluster_name':cluster_name,'Auto_Mode':Auto_Mode})
    return render_to_response('automaticdeployment.html',{'User':User,'cluster_name':cluster_name,'Auto_Mode':Auto_Mode})

@login_required()
def Cluster(request):
    User=request.user.username
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST' or request.GET:
	cluster_acct = request.REQUEST.get('cluster_acct')
	cluster_name = request.REQUEST.get('cluster_name')
        select=request.REQUEST.get('select')
        save_p=request.REQUEST.get('save_p')
        InGroup = request.REQUEST.getlist('InGroup')
	
	if cluster_acct == 'add' and cluster_name:
	    DBDA = Auto_cluster(cluster_name=cluster_name)
	    try:
	     DBDA.save()
	     Results = Auto_cluster.objects.all()
	     return render_to_response('autocluster.html',{'User':User,'results':Results,'DBDA':'添加成功','cluster_name':cluster_name})
	    except:
	     Results = Auto_cluster.objects.all()
	     return render_to_response('autocluster.html',{'User':User,'results':Results,'DBDA':'添加失败'})

        elif cluster_acct == 'del' and cluster_name:
	    
            #Results = Auto_cluster.objects.filter(cluster_name__icontains=cluster_name.strip())
            Results = Auto_cluster.objects.get(id=cluster_name)
            Results.delete()
            log_info("登陆用户:" + str(User) + " 删除集群名:" +str(cluster_name) + " 成功")
	    Results = Auto_cluster.objects.all()
            return render_to_response('autocluster.html',{'User':User,'results':Results})

	elif select or save_p and cluster_name:
	    #所有有权限设备
	    namechange_sql='select first_name from auth_user where username="%s"' %(User)
	    namechange=dbutil.select(namechange_sql)
	    if User == 'wanglong':
	        sql='select wanip from uxin_device'
	    else:
	        sql='select wanip from uxin_device where riskowner="%s"' %(namechange[0]['first_name'])
	    device=dbutil.select(sql)

	    #所有集群名
	    Results = Auto_cluster.objects.all()
	
            #查看集群已有设备
            already_device_sql = 'select wanip from uxin_auto_cluster_device where cluster_name="%s"' %cluster_name
            already_device = dbutil.select(already_device_sql)

            #对比所有的权限，与已有权限， 计算出剩余权限
            diff=[i for i in device if i not in already_device]

            #查询
            if select:
	        return render_to_response('autocluster.html',{'User':User,'device':diff,'results':Results,'already_device':already_device,'cluster_name':cluster_name})

	    #保存
	    if save_p:
	        if cluster_name != '':
		    #先清除集群已有设备
		    del_sql='delete from uxin_auto_cluster_device where cluster_name="%s"' %cluster_name
		    dbutil.device_update(del_sql)
		    for i in InGroup:
                        sql='insert into uxin_auto_cluster_device values(NULL,"%s","%s")' %(cluster_name,i)
                        sql=sql.encode("utf-8")
			try:
                         dbutil.device_update(sql)
			except:
			 pass


	            #查看集群已有设备
        	    already_device_sql = 'select wanip from uxin_auto_cluster_device where cluster_name="%s"' %cluster_name
	            already_device = dbutil.select(already_device_sql)
        	    #对比所有的权限，与已有权限， 计算出剩余权限
		    diff=[i for i in device if i not in already_device]

		    return render_to_response('autocluster.html',{'User':User,'device':diff,'results':Results,'already_device':already_device,'cluster_name':cluster_name})
	
	Results = Auto_cluster.objects.all()    
        return render_to_response('autocluster.html',{'User':User,'results':Results})
    Results = Auto_cluster.objects.all()
    return render_to_response('autocluster.html',{'User':User,'results':Results})


