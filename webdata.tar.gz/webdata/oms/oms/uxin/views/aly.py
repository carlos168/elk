#!/usr/bin/env python
#-*- coding:UTF-8 -*-
from django.http import *
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.contrib.auth.decorators import login_required
from django.utils import simplejson
from uxin.models import *
from django.conf import settings
from django.contrib.auth.models import User
from django.http import HttpResponseRedirect

from django.template import loader, RequestContext
import MySQLdb.cursors
import commands
from LogLib import *
import dbutil
import time
import re
import json
import urllib2,urllib
from config import *

import get_userlist
import os
import ssh
import send_alarm
from tool import *



mroom = Idc.objects.raw('select id,mroom from uxin_idc where mroom !=""')
cabinet = Devbase.objects.raw('select id,cabinet from uxin_devbase where cabinet !=""')
project = Devbase.objects.raw('select id,project from uxin_devbase where project !=""')
subprojects = Devbase.objects.raw('select id,subprojects from uxin_devbase where subprojects !=""')
brand = Devbase.objects.raw('select id,brand from uxin_devbase where brand !=""')
cconfig = Devbase.objects.raw('select id,cconfig from uxin_devbase where cconfig !=""')
distributor = Devbase.objects.raw('select id,distributor from uxin_devbase where distributor !=""')
riskowner = Devbase.objects.raw('select id,riskowner from uxin_devbase where riskowner != ""')
srvmodel = Devbase.objects.raw('select id,srvmodel from uxin_devbase where srvmodel != ""')
subprojects = Devbase.objects.raw('select id,subprojects from uxin_devbase where subprojects != ""')

Alarm_type = Alarm.objects.raw('select id,Alarm_type, count(distinct Alarm_type) from uxin_alarm group by Alarm_type')




def select(sql):
    conn=MySQLdb.connect(host=CACTICF['SQLIP'],user=CACTICF['SQLUSER'],passwd=CACTICF['SQLPASS'],db=CACTICF['SQLDB'],port=CACTICF['SQLPORT'],cursorclass=MySQLdb.cursors.DictCursor)
    cursor = conn.cursor()
#    cursor.execute('set names utf8')
    cursor.execute(sql)
    row=cursor.fetchall()
    cursor.close()
    conn.close()
    return row


def delete(sql):
    conn=MySQLdb.connect(host=CACTICF['SQLIP'],user=CACTICF['SQLUSER'],passwd=CACTICF['SQLPASS'],db=CACTICF['SQLDB'],port=CACTICF['SQLPORT'],cursorclass=MySQLdb.cursors.DictCursor)
    cursor = conn.cursor()
    cursor.execute(sql) 
    cursor.close()
    conn.close()




@login_required()
def Cacti(request):
    User=request.user.username
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    selecthost='select id,hostname,availability,cur_time,avg_time from host GROUP BY hostname;'
    if request.method == 'POST':
        name = request.REQUEST.get('IPADDR')
        DLID = request.REQUEST.get('DLID')

        if name and not DLID:
            s = 'select id,hostname,availability,cur_time,avg_time from host where hostname like "%%%s%%";' %name
            Results = select(s)
            return render_to_response('cacti.html',{'results':Results,'User':User},context_instance=RequestContext(request))


        elif DLID and not name:
            if permissions_check(User,'cacti_deleteaaaaa') != True:
                return render_to_response('permissions_error.html')
            d1="delete from poller_item where host_id='%s'" %DLID
            d2="delete from host where id='%s'" %DLID
            d3="delete from poller_reindex where host_id='%s'" %DLID
            d4="delete from graph_tree_items where host_id='%s'" %DLID
            delete(d1)
            delete(d2)
            delete(d3)
            delete(d4)
            Resultss=select(selecthost)
            return render_to_response('cacti.html',{'results':Resultss,'User':User},context_instance=RequestContext(request))

        else:
            Results=select(selecthost)
            return render_to_response('cacti.html',{'results':Results,'User':User},context_instance=RequestContext(request))

    Results=select(selecthost)
    return render_to_response('cacti.html',{'results':Results,'User':User,'nowip':'nowip'},context_instance=RequestContext(request))


groups=select('select id,name from graph_tree ;')
group=select("select id,graph_tree_id,title from graph_tree_items where host_id='0' and local_graph_id='0' and rra_id='0';")
@login_required()
def Addcacti(request):

    groups=select('select id,name from graph_tree')
    group=select("select id,graph_tree_id,title from graph_tree_items where host_id='0' and local_graph_id='0' and rra_id='0';")

    User=request.user.username
    if permissions_check(User,'cacti_add') != True:
        return render_to_response('permissions_error.html')
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST' or request.GET:
        Ipaddr = request.REQUEST.get('ipaddr')
        Groups = request.REQUEST.get('groups')
        Group = request.REQUEST.get('group')
        diff='select hostname from host where hostname="%s";' %Ipaddr

        if Ipaddr:
            if check_ip(Ipaddr) != 'ok':
                return render_to_response('addcacti.html',{'User':User,'error':'IP地址格式错误','groups':groups,'group':group})

            if len(select(diff)) == 1:
                return render_to_response('addcacti.html',{'User':User,'error':'此IP已经存在','groups':groups,'group':group})

            check_snmp="snmpwalk -v 2c -c %s %s system" %(CACTICF['SNMPPASSWD'],Ipaddr)
            if commands.getstatusoutput(check_snmp)[0] != 0:
                return render_to_response('addcacti.html',{'User':User,'error':'此IP SNMP连接错误，请检查','groups':groups,'group':group})

            cmd="cd %s; sh auto_cacti.sh %s %s %s" %(CACTICF['CACTIPATH'],Ipaddr,Groups,Group)
            log_error(str(cmd))
            ssh.exe_cmd(CACTICF['CACTIIP'],cmd + ' > /dev/null 2>&1 &')
            return render_to_response('addcacti.html',{'User':User,'addok':'新增IP成功','groups':groups,'group':group})
    return render_to_response('addcacti.html',{'User':User,'groups':groups,'group':group})




@login_required()

def Alarm_center(request):
    User=request.user.username
    Results=Alarm_email.objects.all()
    if permissions_check(User,'mail_server_config') != True:
        return render_to_response('permissions_error.html')
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST' or request.GET:
	smtp_server=request.REQUEST.get('smtp_server')
	smtp_user=request.REQUEST.get('smtp_user')
	smtp_pass=request.REQUEST.get('smtp_pass')
        test_send=request.REQUEST.get('test_send')
        test_title=request.REQUEST.get('test_title')
        test_text=request.REQUEST.get('test_text')
	email_save=request.REQUEST.get('save')
	email_send=request.REQUEST.get('send')

	if smtp_server and smtp_user and smtp_pass and test_send and test_title and test_text:
	
	    if email_save and not email_send:

		DBDA = Alarm_email(id='1',smtp_server=smtp_server.strip(),smtp_user=smtp_user.strip(),smtp_pass=smtp_pass.strip(),\
		                   test_send=test_send.strip(),test_title=test_title.strip(),test_text=test_text.strip())
	        DBDA.save()
		return render_to_response('alarm_email.html',{'User':User,'error':'保存成功','results':Results})

	    elif not email_save and email_send:
		Results=send_alarm.send_mail(smtp_server,smtp_user,smtp_pass,test_send,test_title,test_text)
		if Results==True:
		    Results='发送成功，请查收'
		else:
		    Results='发送失败'

		return render_to_response('alarm_email.html',{'User':User,'error':Results,'r':'r'})

	else:
	    
	    return render_to_response('alarm_email.html',{'User':User,'error':'参数输入不完整','results':Results})
		
	return render_to_response('alarm_email.html',{'User':User,'results':Results})
    return render_to_response('alarm_email.html',{'User':User,'results':Results})



@login_required()
def Alarm_sms_config(request):
    User=request.user.username
    Results=Alarm_sms.objects.all()
    if permissions_check(User,'sms_config') != True:
        return render_to_response('permissions_error.html')
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST' or request.GET:
        sms_server=request.REQUEST.get('sms_server')
        sms_user=request.REQUEST.get('sms_user')
        sms_pass=request.REQUEST.get('sms_pass')
        test_text=request.REQUEST.get('test_text')
        test_send=request.REQUEST.get('test_send')
        sms_save=request.REQUEST.get('save')
        sms_send=request.REQUEST.get('send')

        if sms_server and sms_user and sms_pass and test_send and test_text:

            if sms_save and not sms_send:

                DBDA = Alarm_sms(id='1',sms_server=sms_server.strip(),sms_user=sms_user.strip(),sms_pass=sms_pass.strip(),\
                                   test_send=test_send.strip(),test_text=test_text.strip())
                DBDA.save()
                return render_to_response('alarm_sms.html',{'User':User,'error':'保存成功','results':Results})

            elif not sms_save and sms_send:
                Results=send_alarm.send_SMS(test_text,test_send,sms_server,sms_user,sms_pass)
                if Results==0:
                    Results='发送成功，请查收'
                else:
                    Results='发送失败'

                return render_to_response('alarm_sms.html',{'User':User,'error':Results,'r':'r'})

        else:

            return render_to_response('alarm_sms.html',{'User':User,'error':'参数输入不完整','results':Results})

        return render_to_response('alarm_sms.html',{'User':User,'results':Results})
    return render_to_response('alarm_sms.html',{'User':User,'results':Results})


def Alarm_group(request):
    User=request.user.username
    #返回state 表示显示顶部搜索新增行

    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST' or request.GET:
	ADD=request.REQUEST.get('ADD')
	DLID=request.REQUEST.get('DLID')
	MDID = request.REQUEST.get('MDID')
	Change = request.REQUEST.get('Change')
	search=request.REQUEST.get('search')
	alarm_type=request.REQUEST.get('alarm_type')
	alarm_name=request.REQUEST.get('alarm_name')
	alarm_member=request.REQUEST.get('alarm_member')

        if alarm_name and MDID and Change:
	    if permissions_check(User,'alarm_group_change') != True:
        	return render_to_response('permissions_error.html')
            DBDA = Alarm_grp(id=MDID,alarm_type=alarm_type.strip(),alarm_name=alarm_name.strip(''),alarm_count=alarm_member.strip(''))
            DBDA.save()
	    Results = Alarm_grp.objects.all()
	    log_info("登陆用户:" + str(User) + " 修改监控:" +str(alarm_name) + " 成功")
            return render_to_response('alarm_group.html',{'User':User,'error':'修改成功','state':'y','results':Results})
	if ADD:
            if permissions_check(User,'alarm_group_add') != True:
                return render_to_response('permissions_error.html')
	    if alarm_type and alarm_name and alarm_member:
                DBDA = Alarm_grp(alarm_type=alarm_type.strip(),alarm_name=alarm_name.strip(),alarm_count=alarm_member.strip())
                DBDA.save()
		log_info("登陆用户:" + str(User) + " 新增监控:" +str(alarm_name) + " 成功")
	        return render_to_response('alarm_group.html',{'User':User,'error':'新增成功','ADD':'a1'})
	    return render_to_response('alarm_group.html',{'User':User,'ADD':'a1'})

        if DLID:
            if permissions_check(User,'alarm_group_delete') != True:
                return render_to_response('permissions_error.html')
            Results = Alarm_grp.objects.get(id=DLID)
            Results.delete()
	    log_info("登陆用户:" + str(User) + " 删除监控:" +str(Results) + " 成功")
            Resultss = Alarm_grp.objects.all()
            return render_to_response('alarm_group.html',{'results':Resultss,'User':User})

        if MDID:
            if permissions_check(User,'alarm_group_change') != True:
                return render_to_response('permissions_error.html')
	    MDID=Alarm_grp.objects.filter(id=MDID)
            return render_to_response('alarm_group.html',{'User':User,'MDID':MDID})
	if search and alarm_type:
	    Results=Alarm_grp.objects.filter(alarm_type=alarm_type.strip())
	    return render_to_response('alarm_group.html',{'User':User,'results':Results,'state':'y','type':alarm_type})

    Results=Alarm_grp.objects.all()	    
    return render_to_response('alarm_group.html',{'User':User,'results':Results,'state':'y'})


def Split_list(str):
        '''
        @将字符转分割放入列表中
        '''
        list = []
        for element in str.split('\n'):
                list.append(element)
        return list

def list_custom():
    import commands
    status, output = commands.getstatusoutput('ls %s/oms/lib/custom' %(DIRS['OMS_ROOT']))
    return Split_list(output)




def Qiuchong(u):
    for x in u:
        while u.count(x)>1:
            del u[u.index(x)]
    return u



def Alarm_main(request):
    User=request.user.username
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if permissions_check(User,'alarm_view') != True:
        return render_to_response('permissions_error.html')
    status_ok=Alarm.objects.filter(fail_count=0).count()
    status_down=Alarm.objects.exclude(fail_count=0).count()

    monitor_ok=Alarm.objects.filter(status=0).count()
    monitor_down=Alarm.objects.filter(status=1).count()


     #使用数据库直接查询
#    m_ok=dbutil.select('select id,count(*) from uxin_alarm where status = "0"')
#    m_down=dbutil.select('select id,count(*) from uxin_alarm where status != "0"')
#    monitor_ok=m_ok[0]['count(*)']
#    monitor_down=m_down[0]['count(*)']
    if request.method == 'POST' or request.GET:
        baseweb=request.REQUEST.get('baseweb')
        web=request.REQUEST.get('web')
        tcp=request.REQUEST.get('tcp')
        Add=request.REQUEST.get('Add')
	DEL=request.REQUEST.get('DLID')
	MDID=request.REQUEST.get('MDID')
	ck=request.REQUEST.get('ck')
	Change=request.REQUEST.get('Change')
        search=request.REQUEST.get('search')
        s=request.REQUEST.get('s')
        status_info=request.REQUEST.get('status_info')
        monitor_info=request.REQUEST.get('monitor_info')
        viewlog=request.REQUEST.get('viewlog')

	status = request.REQUEST.get('status')
	use = request.REQUEST.get('use')
	alarm_list=Alarm_grp.objects.all()
	import weixin
	weixin_list=weixin.userlist()
	
	
	#获取列表值,转换为str 并且去重
	notify_object = request.REQUEST.getlist('notify_object')
	notify_object = Qiuchong(notify_object)
	notify_object = ','.join(notify_object)
	no= notify_object.split(',')
	notify_object=Qiuchong(no)
        notify_object = ','.join(notify_object)



	
	notify_object_weixin = request.REQUEST.getlist('notify_object_weixin')
        notify_object_weixin = Qiuchong(notify_object_weixin)
        notify_object_weixin = ','.join(notify_object_weixin)
        no1= notify_object_weixin.split(',')
        notify_object_weixin=Qiuchong(no1)
        notify_object_weixin = ','.join(notify_object_weixin)



	Results=Alarm.objects.all().order_by('Alarm_ip')

	
	INFO = {}
	#定义所有参数名
	Tuple = ('Alarm_type','Alarm_ip','Alarm_name','Alarm_server','Alarm_email_num','Alarm_num','Alarm_frequency','Alarm_retry',\
                'diff_web','remarks','subprojects','mroom','cabinet','riskowner','project','fail_count','status','alarm_phone','base_check')
	

	#循环获取
        for i in Tuple:
            INFO[i] = request.REQUEST.get(i)


        if viewlog:
	    view = Alarm_log.objects.all().order_by('-id')[:500]
            return render_to_response('alarm.html',{'User':User,'viewlog':view,'project':project,'subprojects':subprojects,'Alarm_type':Alarm_type,\
                                        'status_ok':status_ok,'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
					'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})

	#修改监控状态
	if status and use:
            if permissions_check(User,'alarm_change') != True:
                return render_to_response('permissions_error.html')
	    sql='update uxin_alarm set status="%s",lock_status="",next_time="" where id="%s"' %(use.strip(),status.strip())
	    dbutil.device_update(sql)
	    log_info("登陆用户:" + str(User) + " 修改监控状态:" +str(use) + " 成功")
	    m_ok=dbutil.select('select id,count(*) from uxin_alarm where status = "0"')
	    m_down=dbutil.select('select id,count(*) from uxin_alarm where status != "0"')
	    monitor_ok=m_ok[0]['count(*)']
	    monitor_down=m_down[0]['count(*)']
	    if status_info == 'ok':
		sql='select * from uxin_alarm where fail_count = "0" ORDER BY Alarm_ip ASC'
            elif status_info == 'error':
		sql='select * from uxin_alarm where fail_count != "0" ORDER BY Alarm_ip ASC'
	    elif monitor_info == 'ok':
		sql='select * from uxin_alarm where status = "0" ORDER BY Alarm_ip ASC'
	    elif monitor_info == 'error':
		sql='select * from uxin_alarm where status = "1" ORDER BY Alarm_ip ASC'
	    #else:
#		sql='select * from uxin_alarm where fail_count != "0" ORDER BY Alarm_ip ASC'
		
	    #sql='select * from uxin_alarm where fail_count != "0" ORDER BY Alarm_ip ASC'
            Results = dbutil.select(sql)
            return render_to_response('alarm.html',{'User':User,'state':'y','results':Results,'project':project,'subprojects':subprojects,'Alarm_type':Alarm_type,\
                                                        'status_ok':status_ok,'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
                                                        'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})


        #删除数据
	if DEL:
            if permissions_check(User,'alarm_delete') != True:
                return render_to_response('permissions_error.html')
            Results = Alarm.objects.get(id=DEL)

	    if permissions_user_check(User,Results.Alarm_ip) != True:
        	return render_to_response('permissions_error.html')
            Results.delete()
	    log_info("登陆用户:" + str(User) + " 删除监控:" +str(Results.Alarm_ip) + " " + str(Results.Alarm_type) + " " + str(Results.Alarm_name) + " 成功")
            Resultss = Alarm.objects.all().order_by('Alarm_ip')
            return render_to_response('alarm.html',{'results':Resultss,'User':User,'project':project,'subprojects':subprojects,\
					'Alarm_type':Alarm_type,'status_ok':status_ok,'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
					'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})
	
    

        if MDID and Change:
            if permissions_check(User,'alarm_change') != True:
                return render_to_response('permissions_error.html')

	    if check_ip(INFO['Alarm_ip']) != 'ok':
                return render_to_response('alarm.html',{'User':User,'error':'修改失败 IP不正确','state':'y','results':Results,\
		'project':project,'subprojects':subprojects,'Alarm_type':Alarm_type,'status_ok':status_ok,'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
		'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})

	    #对比关键字里如果有双引号，去掉

            if INFO['diff_web']:
                INFO['diff_web']=INFO['diff_web'].replace('"','\\\"')
	    
            if permissions_user_check(User,INFO['Alarm_ip']) != True:
                return render_to_response('permissions_error.html')

	    sql='update uxin_alarm set Alarm_type="%s",Alarm_ip="%s",Alarm_name="%s",Alarm_server="%s",Alarm_email_num="%s",\
		 Alarm_num="%s",Alarm_frequency="%s",Alarm_retry="%s",diff_web="%s",remarks="%s",notify_object="%s",alarm_phone="%s",base_check="%s",notify_object_weixin="%s" where id="%s"'\
                 %(INFO['Alarm_type'].strip(),INFO['Alarm_ip'].strip(),INFO['Alarm_name'].strip(),INFO['Alarm_server'].strip(),INFO['Alarm_email_num'].strip(),INFO['Alarm_num'].strip(),\
		   INFO['Alarm_frequency'].strip(),INFO['Alarm_retry'].strip(),INFO['diff_web'].strip(),INFO['remarks'].strip(),notify_object.strip(','),INFO['alarm_phone'],INFO['base_check'],notify_object_weixin.strip(','),MDID)

	    sql=sql.encode("utf-8")
	    dbutil.device_update(sql)
            log_info("登陆用户:" + str(User) + " 修改监控:" +str(INFO['Alarm_ip']) + " " + str(INFO['Alarm_type']) + " " + str(INFO['Alarm_name']) + " " +\
                              str(INFO['Alarm_server']) + " 成功")
	    Results = dbutil.select('select * from uxin_alarm ORDER BY Alarm_ip ASC')
            return render_to_response('alarm.html',{'User':User,'error':'修改成功','state':'y','results':Results,'project':project,\
		'subprojects':subprojects,'Alarm_type':Alarm_type,'status_ok':status_ok,'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
		'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})

        if MDID and ck:
            if permissions_check(User,'alarm_change') != True:
                return render_to_response('permissions_error.html')
            MDID=Alarm.objects.get(id=MDID)
            if permissions_user_check(User,MDID.Alarm_ip) != True:
                return render_to_response('permissions_error.html')
 	    ck_s=data_interface(ck)
            return render_to_response('alarm.html',{'User':User,'MDID':MDID,'alarm_list':alarm_list,'weixin_list':weixin_list,'project':project,'subprojects':subprojects,\
                                      'Alarm_type':Alarm_type,'status_ok':status_ok,'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
                                        'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner,'cks':ck_s})


        if MDID:
            if permissions_check(User,'alarm_change') != True:
                return render_to_response('permissions_error.html')
	    #使用get 发给前台html后，  不需要使用for 遍列即可得到值
            MDID=Alarm.objects.get(id=MDID)
            return render_to_response('alarm.html',{'User':User,'MDID':MDID,'alarm_list':alarm_list,'weixin_list':weixin_list,'project':project,'subprojects':subprojects,\
				      'Alarm_type':Alarm_type,'status_ok':status_ok,'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
					'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})



	
	if Add:
            if permissions_check(User,'alarm_add') != True:
                return render_to_response('permissions_error.html')
	    if INFO['Alarm_type'] and INFO['Alarm_ip'] and INFO['Alarm_name'] and INFO['Alarm_server'] and INFO['Alarm_email_num']\
		 and INFO['Alarm_num'] and INFO['Alarm_frequency'] and INFO['Alarm_retry']:

		#判断IP是否正确，不正确返回
		if check_ip(INFO['Alarm_ip']) != 'ok':
		    return render_to_response('alarm.html',{'User':User,'tcp':'1','error':'IP地址不正确','alarm_list':alarm_list,'weixin_list':weixin_list,'project':project,\
		                               'subprojects':subprojects,'Alarm_type':Alarm_type,'list_custom':list_custom(),'status_ok':status_ok,\
						'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
						'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})

                #是否存在于设备管理中
		sql = 'select wanip from uxin_device where wanip="%s" or lanip="%s"' %(INFO['Alarm_ip'].strip(),INFO['Alarm_ip'].strip())
		device=dbutil.select(sql)
		if not device:
                    return render_to_response('alarm.html',{'User':User,'tcp':'1','error':'此IP未在设备管理中登记','alarm_list':alarm_list,'weixin_list':weixin_list,'project':project,\
                                               'subprojects':subprojects,'Alarm_type':Alarm_type,'list_custom':list_custom(),'status_ok':status_ok,\
                                                'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
                                                'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})
		#判断是否有相同IP端口
		sql = 'select * from uxin_alarm where Alarm_ip="%s" and Alarm_server="%s"' %(INFO['Alarm_ip'].strip(),INFO['Alarm_server'].strip())
		diff=dbutil.select(sql)

                sql = 'select * from uxin_alarm where Alarm_ip="%s" and  Alarm_type != "web" and Alarm_type != "custom" and Alarm_type="%s"' %(INFO['Alarm_ip'].strip(),INFO['Alarm_type'].strip())
                diff_progress=dbutil.select(sql)

		
		if diff or diff_progress:
		    return render_to_response('alarm.html',{'User':User,'tcp':'1','error':'已经存在相同项','alarm_list':alarm_list,'weixin_list':weixin_list,'project':project,\
						'subprojects':subprojects,'Alarm_type':Alarm_type,'list_custom':list_custom(),'status_ok':status_ok,\
						'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
						 'Alarm_ip':INFO['Alarm_ip'].strip(),'Alarm_name':INFO['Alarm_name'].strip(),'Alarm_server':INFO['Alarm_server'].strip(),\
						 'Alarm_type':INFO['Alarm_type'].strip(),\
						'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})
		else:
	            if permissions_user_check(User,INFO['Alarm_ip']) != True:
        	        return render_to_response('permissions_error.html')

                    DBDA = Alarm(Alarm_type=INFO['Alarm_type'].strip(),Alarm_ip=INFO['Alarm_ip'].strip(),Alarm_name=INFO['Alarm_name'].strip(),Alarm_server=INFO['Alarm_server'].strip(),\
                      Alarm_email_num=INFO['Alarm_email_num'].strip(),Alarm_num=INFO['Alarm_num'].strip(),Alarm_frequency=INFO['Alarm_frequency'].strip(),Alarm_retry=INFO['Alarm_retry'].strip(),\
		      fail_count='0',diff_web=INFO['diff_web'].strip(),\
		      remarks=INFO['remarks'].strip(),notify_object=notify_object.strip(),status='0',alarm_phone=INFO['alarm_phone'],base_check=INFO['base_check'],lock_status='',notify_object_weixin=notify_object_weixin.strip())

                    DBDA.save()
		    log_info("登陆用户:" + str(User) + " 新增监控:" +str(INFO['Alarm_ip']) + " " + str(INFO['Alarm_type']) + " " + str(INFO['Alarm_name']) + " " +\
			      str(INFO['Alarm_server']) + " 成功")
	
	            return render_to_response('alarm.html',{'User':User,'tcp':'1','error':'新增成功','alarm_list':alarm_list,'weixin_list':weixin_list,'project':project,'subprojects':subprojects,\
						'Alarm_type':Alarm_type,'status_ok':status_ok,'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
						'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})

	    else:
		return render_to_response('alarm.html',{'User':User,'tcp':'1','error':'必备项，不能为空','alarm_list':alarm_list,'weixin_list':weixin_list,'project':project,'subprojects':subprojects,\
				'Alarm_type':Alarm_type,'list_custom':list_custom(),'status_ok':status_ok,'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
				'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})

        if baseweb:
	    return render_to_response('alarm.html',{'User':User,'baseweb':'1','status_ok':status_ok,'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
					'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})
	
	if web:
            return render_to_response('alarm.html',{'User':User,'web':'1','status_ok':status_ok,'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
					'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})


        if tcp:
            if permissions_check(User,'alarm_add') != True:
                return render_to_response('permissions_error.html')
            return render_to_response('alarm.html',{'User':User,'tcp':'1','alarm_list':alarm_list,'weixin_list':weixin_list,'list_custom':list_custom(),'status_ok':status_ok,\
					'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
					'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})


        #查找

        if search :
             #查询数据,关连表查询
	    find="select a.* from uxin_alarm a  join (select * from uxin_device where 0=0 "
	    cmd=") b on a.Alarm_ip=b.wanip"
	    cmd1=" ORDER BY Alarm_ip ASC"

            #获取每个参数的值
            for i in Tuple:
                INFO[i] = request.REQUEST.get(i)
                #根据得到的参数,生成相应的SQL
                if INFO[i]:
		    if INFO[i] == INFO['project'] or INFO[i] == INFO['subprojects'] \
			or INFO[i] == INFO['mroom'] or INFO[i] ==  INFO['cabinet'] or INFO[i] == INFO['riskowner']:
			find=find + ' and ' + i + '="%s"' %(INFO[i])
		    else:
			cmd = cmd + ' and ' + i + ' like "%%%s%%" ' %(INFO[i])
	    find = find + cmd + cmd1
	    results=dbutil.select(find)
            return render_to_response('alarm.html',{'User':User,'results':results,'project':project,'subprojects':subprojects,'Alarm_type':Alarm_type,\
                                       'status_ok':status_ok,'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
                                       'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})
			

        #暂停或者开启全部监控
        if s == 'start':
            if permissions_check(User,'alarm_change') != True:
                return render_to_response('permissions_error.html')
            sql="update uxin_alarm set status='0',lock_status='',next_time=''"
            dbutil.device_update(sql)

 	    m_ok=dbutil.select('select id,count(*) from uxin_alarm where status = "0"')
	    m_down=dbutil.select('select id,count(*) from uxin_alarm where status != "0"')
	    monitor_ok=m_ok[0]['count(*)']
	    monitor_down=m_down[0]['count(*)']
            log_info("登陆用户:" + str(User) +  " 开启全部监控:"  + " 成功")
            Results = dbutil.select('select * from uxin_alarm ORDER BY Alarm_ip ASC')
            return render_to_response('alarm.html',{'User':User,'state':'y','results':Results,'project':project,'subprojects':subprojects,'Alarm_type':Alarm_type,\
					'status_ok':status_ok,'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
					'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})
        if s == 'stop':
            if permissions_check(User,'alarm_change') != True:
                return render_to_response('permissions_error.html')
            sql='update uxin_alarm set status="1",lock_status="",next_time=""'
            dbutil.device_update(sql)
            m_ok=dbutil.select('select id,count(*) from uxin_alarm where status = "0"')
            m_down=dbutil.select('select id,count(*) from uxin_alarm where status != "0"')
            monitor_ok=m_ok[0]['count(*)']
            monitor_down=m_down[0]['count(*)']
            Results = dbutil.select('select * from uxin_alarm')
	    log_info("登陆用户:" + str(User) +  " 停止全部监控:"  + " 成功")
            return render_to_response('alarm.html',{'User':User,'state':'y','results':Results,'project':project,'subprojects':subprojects,'Alarm_type':Alarm_type,\
					'status_ok':status_ok,'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
					'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})


	if status_info == 'ok':
	    sql='select * from uxin_alarm where fail_count = "0" ORDER BY Alarm_ip ASC'
	    Results =  dbutil.select(sql)
	    return render_to_response('alarm.html',{'User':User,'state':'y','results':Results,'project':project,'subprojects':subprojects,'Alarm_type':Alarm_type,\
					'status_ok':status_ok,'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
					'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})

	if status_info == 'error':
	    sql='select * from uxin_alarm where fail_count != "0" ORDER BY Alarm_ip ASC'
	    Results = dbutil.select(sql)
	    return render_to_response('alarm.html',{'User':User,'state':'y','results':Results,'project':project,'subprojects':subprojects,'Alarm_type':Alarm_type,\
							'status_ok':status_ok,'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
							'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})



        if monitor_info == 'ok':
            sql='select * from uxin_alarm where status = "0" ORDER BY Alarm_ip ASC'
            Results =  dbutil.select(sql)
            return render_to_response('alarm.html',{'User':User,'state':'y','results':Results,'project':project,'subprojects':subprojects,'Alarm_type':Alarm_type,\
						'status_ok':status_ok,'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
						'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})

        if monitor_info == 'error':
            sql='select * from uxin_alarm where status = "1" ORDER BY Alarm_ip ASC'
            Results = dbutil.select(sql)
            return render_to_response('alarm.html',{'User':User,'state':'y','results':Results,'project':project,'subprojects':subprojects,'Alarm_type':Alarm_type,\
							'status_ok':status_ok,'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
							'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})

    Results=Alarm.objects.all().order_by('Alarm_ip')
    return render_to_response('alarm.html',{'User':User,'results':Results,'project':project,'subprojects':subprojects,'Alarm_type':Alarm_type,\
				'status_ok':status_ok,'status_down':status_down,'monitor_ok':monitor_ok,'monitor_down':monitor_down,\
				'mroom':mroom,'cabinet':cabinet,'riskowner':riskowner})

#####################################alarm_api############################
def email_alarm_title(ip,server,Reason,status):
        monitorTime = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())



        content = "告警类型: "+str(status)+" \n\n"
        content1 = "告警来源IP: "+str(ip)+" \n"
        content2 = "告警服务: "+str(server)+" \n"
        content3 = "发送时间:"+str(monitorTime)+" \n\n"
        content4 = "故障信息: \n "+str(Reason)+" \n"
        topTemp = "OMS告警API:  IP:"+str(ip)+" 服务:"+str(server)+" 状态:"+str(status)+""

        if status=='PROBLEM':
            subject = "【故障】"+str(topTemp) + " " + monitorTime
            template = content  + content1 + content2 + content3 + content4
        elif status=='RECOVERY':
            subject = "【恢复】"+str(topTemp) + " " + monitorTime
            template = content  + content1 + content2 + content3

        return subject,template

def send_messages(ip,server,alarm_list,reason,status):

        send_list= get_userlist.get_sendto_users(alarm_list)
        print send_list
        subject ,mailContent= email_alarm_title(ip,server,reason,status)

        if send_list['smslist'] and send_list['smslist'] != '':
            for i in send_list['smslist']:
                send_alarm.send_SMS(subject,i)
                log_info(str(ip) + str(status) + ",发送短信至" + str(i) + "成功.")

        sql='select * from uxin_alarm_email limit 1'
        mailset=dbutil.select(sql)
        if send_list['emaillist']:
            for i in send_list['emaillist']:
                print mailset[0]['smtp_server'],mailset[0]['smtp_user'],mailset[0]['smtp_pass']
                send_alarm.send_mail(mailset[0]['smtp_server'],mailset[0]['smtp_user'],mailset[0]['smtp_pass'],i,subject,mailContent)
		log_info(str(ip) + str(status) + ",发送邮件至" + str(i) + "成功.")

def Alarm_api(request):
    act=request.REQUEST.get('act')
    if request.GET:
	Tuple = ('alarm_list','content','ip','server','status')
	INFO = {}

	if act=='view':
	    Results=Alarm_grp.objects.all()
	    return render_to_response('alarm_api.html',{'results':Results})
	elif act=='send':

            for i in Tuple:
                INFO[i] = request.REQUEST.get(i)
                if not INFO[i]:
                    return render_to_response('alarm_api.html',{'count':i+"不存在"})
            if INFO['ip'] != request.META['REMOTE_ADDR']:
                return render_to_response('alarm_api.html',{'count':"你本次请求IP为: " \
		 			  + request.META['REMOTE_ADDR'] + "     与告警来源IP: " + INFO['ip'] + " 不一致"})
	    if INFO['status'] == "PROBLEM":
		status='PROBLEM'
	    elif INFO['status'] == "RECOVERY":
		status='RECOVERY'
	    else:
	        return render_to_response('alarm_api.html',{'count':"status 参数错误 (RECOVERY or PROBLEM)"})

	    
	    send_messages(INFO['ip'],INFO['server'],INFO['alarm_list'],INFO['content'],INFO['status'])
	    log_info("发送 告警IP:"+ str(INFO['ip']) + "  告警服务:" + str(INFO['server']) + "   告警列表:" + str(INFO['alarm_list']) + "   告警内容" + str(INFO['content'])  +  "   状态" + str(INFO['status']) + "   成功")
	    return render_to_response('alarm_api.html',{'count':"OK"})
		
	else:
	    return render_to_response('alarm_api.html',{'count':'-1'})
    	
    return render_to_response('alarm_api.html',{'count':'-2'})

#############################################  alarm_api end ########################################################

def email_alarm_title_new(title,content):
        monitorTime = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
        content3 = "\n\n发送时间:"+monitorTime+" \n\n"
        content4 = "故障信息: \n "+str(content)+" \n"
        topTemp = "OMS告警API:  "+title+""

        subject = topTemp
	
        template = content3 + "%s" %content4

        return subject,template

def send_messages_new(INFO):
	#分隔多个符号
	try:
	 phone=re.split(' |，|,|;',INFO['alarm_phone'])
	except:
	 return render_to_response('alarm_api.html',{'count':'手机列表错误'})
        try:
         email=re.split(' |，|,|;',INFO['alarm_mail'])
        except:
         return render_to_response('alarm_api.html',{'count':'邮件列表错误'})

        subject ,mailContent= email_alarm_title_new(INFO['alarm_ip'],INFO['server'],INFO['content'],INFO['status'])

        if phone != '':
	    
            for i in phone:
		log_info(str(subject)+str(i))
                send_alarm.send_SMS(subject,i)
                log_info(str(INFO['alarm_ip']) + str(INFO['status']) + ",发送短信至" + str(i) + "成功.")


        sql='select * from uxin_alarm_email limit 1'
        mailset=dbutil.select(sql)
	if email != '':
            for i in email:
                send_alarm.send_mail(mailset[0]['smtp_server'],mailset[0]['smtp_user'],mailset[0]['smtp_pass'],i,subject,mailContent)
                log_info(str(INFO['alarm_ip']) + str(INFO['status']) + ",发送邮件至" + str(i) + "成功.")
from django.utils import simplejson
def Alarm_api_new(request):
    act=request.REQUEST.get('act')
    title=request.REQUEST.get('title')
    
    if request.GET:
        Tuple = ('alarm_list','content','ip','type')
        INFO = {}

        for i in Tuple:
            INFO[i] = request.REQUEST.get(i)
            if not INFO[i]:
                return render_to_response('alarm_api.html',{'count':i+"不存在"})
        if INFO['ip'] != request.META['REMOTE_ADDR']:
            return render_to_response('alarm_api.html',{'count':"你本次请求IP为: " \
                                          + request.META['REMOTE_ADDR'] + "     与告警来源IP: " + INFO['ip'] + " 不一致"})

        if act=='send':


            for i in Tuple:
                INFO[i] = request.REQUEST.get(i)
                if not INFO[i]:
		    return HttpResponse(simplejson.dumps({'ret':i+' error'}, ensure_ascii=False))

	    if INFO['type'] == 'MAIL' and title:
		content = str(INFO['content'].replace('\\n','\n'))
		log_info(type(content))
		subject ,mailContent= email_alarm_title_new(title,content)
		sql='select * from uxin_alarm_email limit 1'
                mailset=dbutil.select(sql)
		email=re.split(' |，|,|;',INFO['alarm_list'])
		for i in email:
                    send_alarm.send_mail(mailset[0]['smtp_server'],mailset[0]['smtp_user'],mailset[0]['smtp_pass'],i,subject,subject+mailContent)
		    log_info(str(title) + str(INFO['content']) + "发送邮件至" + str(i) + "成功.")
		  
		return HttpResponse(simplejson.dumps({'ret':0,'description':'邮件发送成功'}, ensure_ascii=False))

            if INFO['type'] == 'WEIXIN':
		title='WEIXIN'
                subject, mailContent= email_alarm_title_new(title,INFO['content'])
		subject = subject + mailContent
		#subject=INFO['content']
                #合并所有微信帐号，一次发送
                wx=''
		phone=re.split(' |，|,|;',INFO['alarm_list'])
                for i in phone:
                    wx = wx + '|' + str(i)

               #如果告警内容大于2000个字节,拆分发送
                if len(subject) >= 2000:
                    c = 1000
                    s = subject.decode('utf-8')
                    try:
                     d = [s[i:i+c] for i in xrange(0,len(s),c)]
                    except Exception, e:
                     log_info(e)
                    sum=0
                    for i in d:
                        sum = sum + 1
                        i = "【长消息 第" + str(sum) + "条】"  + str(i)
                        if sum >= 2:
                            i = "[接上条]" + str(i)
                        url = WEIXIN_ADDR+"/SendWeixinMsg?alarm_list=%s&alarm_content=%s" %(wx,i.encode('utf-8'))
                        ss=urllib.urlopen(url).read()
                        log_info(str(iteminfo[2]) +  str(status)  + ",发送微信至" + str(wx) + "结果" + str(ss))
                else:
                    url = WEIXIN_ADDR+"/SendWeixinMsg?alarm_list=%s&alarm_content=%s" %(wx,subject)
                    log_info(str(url))
                    try:
                     s=urllib.urlopen(url.encode('utf-8')).read()
                    except Exception, e:
                     log_info(e)

                return HttpResponse(simplejson.dumps({'ret':0,'description':'微信发送成功'}, ensure_ascii=False))


            if INFO['type'] == 'SMS':
		#title='SMS'
                #subject ,mailContent= email_alarm_title_new(title,INFO['content'])
                #phone=re.split(' |，|,|;',INFO['alarm_list'])
                #for i in phone:
		#    send_alarm.send_SMS(i,INFO['content'])
                #    log_info(str(title) + str(INFO['content']) + "发送短信" + str(i) + "成功.")

                #return HttpResponse(simplejson.dumps({'ret':0,'description':'send sms ok'}, ensure_ascii=False))

	    #else:
                #return HttpResponse(simplejson.dumps({'ret':-1,'description':''}, ensure_ascii=False))

		return HttpResponse(simplejson.dumps({'ret':-1,'description':'短信服务已经关闭,请使用微信代替'}, ensure_ascii=False))

    return HttpResponse(simplejson.dumps({'ret':-2}, ensure_ascii=False))
		
#	    elif type == 'SMS':
#	    elif type == 'WEIXIN':
#	    else:
#		return HttpResponse(simplejson.dumps({'ret':'type error'}, ensure_ascii=False))

	         
#            if INFO['source_ip'] != request.META['REMOTE_ADDR']:
#                return render_to_response('alarm_api.html',{'count':"你本次请求IP为: " \
#                                          + request.META['REMOTE_ADDR'] + "     与告警来源IP: " + INFO['ip'] + " 不一致"})
#
#            send_messages_new(INFO)
#            return render_to_response('alarm_api.html',{'count':"OK"})
#
#        else:
#            return render_to_response('alarm_api.html',{'count':'-1'})
#
#    return render_to_response('alarm_api.html',{'count':'-2'})
