#!/usr/bin/env python
#-*- coding:UTF-8 -*-
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.contrib.auth.decorators import login_required
from django.utils import simplejson
from uxin.models import *
from django.conf import settings
#from uxin.uxin import argg

from django.contrib.auth.models import User

from django.template import loader, RequestContext
import os
import csv
import codecs
import time
import dbutil
from dbutil import *
import re
###换行
from django.core.paginator import Paginator
from django.core.paginator import EmptyPage
from django.core.paginator import PageNotAnInteger
import tablib
import StringIO
from LogLib import *
from tool import *
import datetime,time
import config
from LogLib import *

#定义下拉列表
mroom = Idc.objects.raw('select id,mroom from uxin_idc where mroom !=""')
cabinet = Devbase.objects.raw('select id,cabinet from uxin_devbase where cabinet !=""')
#project = Devbase.objects.raw('select id,project from uxin_devbase where project !=""')
#subprojects = Devbase.objects.raw('select id,subprojects from uxin_devbase where subprojects !=""')
brand = Switch.objects.raw('select id,brand from uxin_switch where (id IN ( select max(id) from uxin_switch  GROUP BY brand )) ORDER BY id')
cconfig = Switch.objects.raw('select id,cconfig from uxin_switch where (id IN ( select max(id) from uxin_switch  GROUP BY cconfig )) ORDER BY id')
# select id,brand from uxin_switch where (id IN ( select max(id) from uxin_switch  GROUP BY brand )) ORDER BY id;
#distributor = Devbase.objects.raw('select id,distributor from uxin_devbase where distributor !=""')
riskowner = Devbase.objects.raw('select id,riskowner from uxin_devbase where riskowner != ""')
srvmodel = Devbase.objects.raw('select id,srvmodel from uxin_switch where (id IN ( select max(id) from uxin_switch  GROUP BY srvmodel )) ORDER BY id')
#password = Devbase.objects.raw('select id,password from uxin_devbase where srvmodel != ""')
#subprojects = Devbase.objects.raw('select id,subprojects from uxin_devbase where subprojects != ""')


INFO = {}
Tuple = ('mip','mroom','cabinet','runsrv','brand','srvmodel','cconfig','riskowner','purchased','usedate','price','servicesn','exp','stats','remarks','password')

@login_required()
def Chadev(request):
    User=request.user.username
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if 'view' in request.GET and request.GET['view']:
            view = request.GET['view']
            sql='select * from uxin_switch where ID="%s"' %view
            Results = select(sql)
            return render_to_response('search_switch.html',{'results': Results,'User':User})

    if request.method == 'POST' or request.GET:
        mip = request.REQUEST.get('Type')
        MDID = request.REQUEST.get('MDID')
        Change = request.REQUEST.get('Change')
        COPY = request.REQUEST.get('COPY')



        if mip and MDID and Change:

            for i in Tuple:
                INFO[i] = request.REQUEST.get(i)

            #修改需要加上id, 复制并新增不需要加上ID
            DBDA = Switch(id=MDID,mip=INFO['mip'].strip(),mroom=INFO['mroom'].strip(),\
                      cabinet=INFO['cabinet'].strip(),runsrv=INFO['runsrv'].strip(),brand=INFO['brand'].strip(),\
                      srvmodel=INFO['srvmodel'].strip(),cconfig=INFO['cconfig'].strip(),riskowner=INFO['riskowner'].strip(),purchased=INFO['purchased'].strip(),\
                      usedate=INFO['usedate'],price=INFO['price'],\
                      servicesn=INFO['servicesn'].strip(),exp=INFO['exp'],stats=INFO['stats'].strip(),remarks=INFO['remarks'].strip(),password=INFO['password'].strip())
            DBDA.save()
            log_info("登陆用户:" + str(User) + " 修改设备:" +str(INFO['mip']) + " 成功")
            return render_to_response('chaswitch.html',{'Change':'OK','User':User,'mroom':mroom,'cabinet':cabinet,'brand':brand,\
                                      'cconfig':cconfig,'riskowner':riskowner,'srvmodel':srvmodel})

        if mip and COPY and Change:
            for i in Tuple:
                INFO[i] = request.REQUEST.get(i)




            DBDA = Switch(mip=INFO['mip'].strip(),mroom=INFO['mroom'].strip(),\
                   cabinet=INFO['cabinet'].strip(),runsrv=INFO['runsrv'].strip(),brand=INFO['brand'].strip(),srvmodel=INFO['srvmodel'].strip(),\
   	           cconfig=INFO['cconfig'].strip(),riskowner=INFO['riskowner'].strip(),purchased=INFO['purchased'].strip(),usedate=INFO['usedate'].strip(),price=INFO['price'].strip(),\
                   servicesn=INFO['servicesn'].strip(),exp=INFO['exp'].strip(),stats=INFO['stats'].strip(),remarks=INFO['remarks'].strip(),password=INFO['password'].strip())

            DBDA.save()
            log_info("登陆用户:" + str(User) + " 复制设备:" +str(INFO['mip']) + " 成功")

            return render_to_response('chaswitch.html',{'Change':'OK','User':User,'mroom':mroom,'cabinet':cabinet,'brand':brand,\
                                      'cconfig':cconfig,'riskowner':riskowner,'srvmodel':srvmodel})


        if MDID:
            Results = Switch.objects.get(id=MDID)
            return render_to_response('chaswitch.html',{'MDID':Results,'User':User,'mroom':mroom,'cabinet':cabinet,'brand':brand,\
                                      'cconfig':cconfig,'riskowner':riskowner,'srvmodel':srvmodel})

        if COPY:
            Results = Switch.objects.get(id=COPY)
            return render_to_response('chaswitch.html',{'COPY':Results,'User':User,'mroom':mroom,'cabinet':cabinet,'brand':brand,\
                                     'cconfig':cconfig,'riskowner':riskowner,'srvmodel':srvmodel})


    find="select * from uxin_switch where 0=0 "
    for i in Tuple:
               INFO[i] = request.REQUEST.get(i)
		
               if INFO[i]:

        	  find = find + ' and %s like "%%%s%%" ' %(i,INFO[i].strip())
    log_info("登陆用户:" + str(User) + " SQL语句:" +str(find) + " 成功")
    Results=dbutil.select(find)
    return render_to_response('seadswitch.html',{'results':Results,'User':User,'mroom':mroom,'cabinet':cabinet,'brand':brand,\
                                      'cconfig':cconfig,'riskowner':riskowner,'srvmodel':srvmodel})


@login_required()
def Adddev(request):
    User=request.user.username

    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    nowtime=datetime.date.today()
    nowt = str(nowtime)
    uset=str(nowtime - datetime.timedelta(days=10))

    if request.method == 'POST' or request.GET:

    	for l in Tuple:
            INFO[l] = request.REQUEST.get(l)
            if not INFO['mip']:
                Results = Device.objects.all()
                return render_to_response('addswitch.html',{'Results':Results,'error':"IP为空",'User':User,'mroom':mroom,'cabinet':cabinet,'brand':brand,\
                              'cconfig':cconfig,'riskowner':riskowner,'srvmodel':srvmodel,'nowt':nowt,'uset':uset})

#    	cmd="Switch.objects.filter(mip='%s')" %(INFO['mip'])
#    	diff=eval(cmd)
#
#    	for a in diff:
#
#            if a.mip == INFO['mip'].strip():
#                	Results = Switch.objects.all()
#                	return render_to_response('addswitch.html',{'Results':Results,'error':"此IP已经存在,请不要重复添加",'User':User,'mroom':mroom,\
#                                                  'cabinet':cabinet,'brand':brand,\
#                                                  'cconfig':cconfig,'riskowner':riskowner,'srvmodel':srvmodel,'nowt':nowt,'uset':uset})
	DBDA = Switch(mip=INFO['mip'].strip(),mroom=INFO['mroom'].strip(),\
                      cabinet=INFO['cabinet'].strip(),runsrv=INFO['runsrv'].strip(),brand=INFO['brand'].strip(),\
                      srvmodel=INFO['srvmodel'].strip(),cconfig=INFO['cconfig'].strip(),riskowner=INFO['riskowner'].strip(),purchased=INFO['purchased'].strip(),\
                      usedate=INFO['usedate'].strip(),price=INFO['price'].strip(),\
                      servicesn=INFO['servicesn'].strip(),exp=INFO['exp'].strip(),stats=INFO['stats'].strip(),\
                      remarks=INFO['remarks'].strip(),password=INFO['password'.strip()])

    	DBDA.save()

    	sql="update uxin_systeminit_log set in_device='0' where ip='%s'" %(INFO['mip'])
	dbutil.device_update(sql)

    	log_info("登陆用户:" + str(User) + " 新增设备:" +str(INFO['mip']) + " 成功")

    Results = Switch.objects.all()
    return render_to_response('addswitch.html',{'Results':Results,'User':User,'mroom':mroom,'cabinet':cabinet,'brand':brand,\
                              'cconfig':cconfig,'riskowner':riskowner,'srvmodel':srvmodel,'nowt':nowt,'uset':uset})
@login_required()
def Deldev(request):
    User=request.user.username
    if permissions_check(User,'device_delete') != True:
        return render_to_response('permissions_error.html')
    if secure_check(User) != True:
        return render_to_response('Secure2.html',{'User':User,'nosecret':'ok','secretcode':secure_code(User)})
    if request.method == 'POST':
        ip = request.REQUEST.get('IP')
        DLID = request.REQUEST.get('DLID')
        if DLID and not ip:
            Results = Switch.objects.get(id=DLID)
            log_info("登陆用户:" + str(User) + " 删除设备:" +str(Results) + " 成功")
            Results.delete()
            Resultss = Switch.objects.all()
            return render_to_response('delswitch.html',{'results':Resultss,'User':User,})
        if ip :
            Results = Switch.objects.filter(mip__icontains=ip)
            return render_to_response('delswitch.html',{'results':Results,'User':User,})
        Results = Switch.objects.all()
        return render_to_response('delswitch.html',{'results':Results,'User':User,})

    if 'view' in request.GET and request.GET['view']:
        view = request.GET['view']
        Results = Switch.objects.filter(id__icontains=view)
        return render_to_response('search_switch.html',{'results': Results,'User':User,'mroom':mroom,'cabinet':cabinet,\
                              'cconfig':cconfig,'riskowner':riskowner,'srvmodel':srvmodel})
    return render_to_response('delswitch.html',{'User':User,})
