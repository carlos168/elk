# Django settings for oms project.
import os,sys
from django.core.urlresolvers import reverse_lazy
#DEBUG = False
DEBUG = True
TEMPLATE_DEBUG = DEBUG
#TEMPLATE_DEBUG = False
LOGIN_URL = '/login/'
LOGIN_REDIRECT_URL='/'

BASEROOT = '/data/webdata/oms/oms/'

APPNAME = 'oms'

sys.path.insert(0, os.path.join(BASEROOT, 'lib'))

ADMINS = (
    ('Wayland', '7618565@qq.com'),
)

MANAGERS = ADMINS

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql', # Add 'postgresql_psycopg2', 'mysql', 'sqlite3' or 'oracle'.
        'NAME': 'oms',                      # Or path to database file if using sqlite3.
        'USER': 'oms_monitor',
        'PASSWORD': 'oms_db_monitor',
        'HOST': 'localhost',                      # Empty for localhost through domain sockets or '127.0.0.1' for localhost through TCP.
        'PORT': '3307',                      # Set to empty string for default.
    }

}



ALLOWED_HOSTS = ['*']

TIME_ZONE = 'Asia/Shanghai'

LANGUAGE_CODE = 'zh-cn'

SITE_ID = 1

USE_I18N = True

USE_L10N = True

USE_TZ = True

MEDIA_ROOT = ''
MEDIA_URL = ''
#STATIC_ROOT = os.path.join(os.path.dirname(__file__), '../static').replace('\\','/')
STATIC_ROOT = ''
STATIC_URL = '/static/'

# Additional locations of static files

STATICFILES_DIRS = (
#    BASEROOT + '/static/',
#    '/data/webdata/oms/oms/static/css/',
#    ("css", os.path.join(STATIC_ROOT,'css')),
#    ("js", os.path.join(STATIC_ROOT,'js')),
#    ("images", os.path.join(STATIC_ROOT,'images')),

)

# List of finder classes that know how to find static files in
# various locations.
STATICFILES_FINDERS = (
    'django.contrib.staticfiles.finders.FileSystemFinder',
    'django.contrib.staticfiles.finders.AppDirectoriesFinder',
#    'django.contrib.staticfiles.finders.DefaultStorageFinder',
)

# Make this unique, and don't share it with anybody.
SECRET_KEY = 'c+x95xqf^tp^9+6)kc#(@9vs!xfge13%+51pd#*^po54sg3joy'

# List of callables that know how to import templates from various sources.
TEMPLATE_LOADERS = (
    'django.template.loaders.filesystem.Loader',
    'django.template.loaders.app_directories.Loader',
#     'django.template.loaders.eggs.Loader',
)

MIDDLEWARE_CLASSES = (
    'django.middleware.common.CommonMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',

    # Uncomment the next line for simple clickjacking protection:
#    'django.middleware.clickjacking.XFrameOptionsMiddleware',
)

ROOT_URLCONF = 'oms.urls'

# Python dotted path to the WSGI application used by Django's runserver.
WSGI_APPLICATION = 'oms.wsgi.application'

TEMPLATE_DIRS = (
    BASEROOT + '/templates',
    '/data/webdata/oms/oms/templates',
)

INSTALLED_APPS = (
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.sites',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    APPNAME + '.uxin',
    # Uncomment the next line to enable the admin:
    # 'django.contrib.admin',
    # Uncomment the next line to enable admin documentation:
    # 'django.contrib.admindocs',
)

TEMPLATE_CONTEXT_PROCESSORS = (  
#        'django.core.context_processors.auth',
#        'django.core.context_processors.debug',
        'django.core.context_processors.i18n',
        'django.core.context_processors.request',
)  

SESSION_SERIALIZER = 'django.contrib.sessions.serializers.JSONSerializer'

CACHE_BACKEND = "locmem://"

#LOGGING = {
#    'version': 1,
#    'disable_existing_loggers': False,
#    'handlers': {
#        'console': {
#            'level': 'INFO',
#            'class': 'logging.StreamHandler'
#        }
#    },
#    'loggers': {
#        'django.db.backends': {
#            'handlers': ['console'],
#            'level': 'INFO',
#            'propagate': True,
#        },
#    }
#}


