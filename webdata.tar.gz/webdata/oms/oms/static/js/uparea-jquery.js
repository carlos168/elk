function getReturn()
{
  var url = '/system/status';
  var urlget = url + '?SID=' + SID;
  $.ajaxSetup({
      cache: false
    });
  $("#Txtarea").load(urlget);
}

function GETINNERHTML()
{
  var INNER = $("#Command").val();
  var Hosts = $("#Hosts").val();
  //alert(Hosts);
  var url = '/system/batch/';
  var PostData = {"Exec":INNER, "Hosts":Hosts, "SID":SID}
  if (Hosts) {
     $("#Hosts").attr("value","");
  }
  var MyAjax = jQuery.ajax({
      type: "POST",
      data: PostData,
      url: url,
      });
}

function MyShow()
{ 
  timer = window.setInterval("getReturn();",1000);
  GETINNERHTML();
}

function Stop()
{
  if ( timer != null) { window.clearInterval(timer) };
}

function init()
{
  SID = ""+Math.round(Math.random()*1000000000);
}

init(); 
