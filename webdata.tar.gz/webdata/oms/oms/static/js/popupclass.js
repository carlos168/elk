﻿function ShowIframe(a,b,c,d)
{
  var pop=new Popup({ contentType:1,scrollType:'yes',isReloadOnClose:false,width:c,height:d});
  pop.setContent("contentUrl",b);
  pop.setContent("title",a);
  pop.build();
  pop.show();
}
function ShowHtmlString(a,b,c,d)
{
  var strHtml = "<table border=1 style='width:90%; text-align:center;'><tr style='height:40px'><td>ds</td><td>dads</td></tr><tr style='height:40px'><td>dadas</td><td>dasd</td></tr><tr style='height:40px'><td>dadasd</td><td>dsadads</td></tr></table>";
  var pop=new Popup({ contentType:2,isReloadOnClose:false,width:c,height:d});
  pop.setContent("contentHtml",b);
  pop.setContent("title",a);
  pop.build();
  pop.show();
}
function ShowConfirm(a,b,c,d)
{
  var pop=new Popup({ contentType:3,isReloadOnClose:true,width:c,height:d});
  pop.setContent("title",a);
  pop.setContent("confirmCon",b);
  pop.setContent("callBack",ShowCallBack);
  pop.setContent("parameter",{id:"divCall",str:"点击确定后显示的字符串",obj:pop});
  pop.build();
  pop.show();
}
function ShowAlert(a,b,c,d)
{
  var pop=new Popup({ contentType:4,isReloadOnClose:false,width:c,height:d});
  pop.setContent("title",a);
  pop.setContent("alertCon",b);
  pop.build();
  pop.show();
}
function ShowCallBack(para)
{
  var o_pop = para["obj"]
  var obj = document.getElementById(para["id"]);
  o_pop.close();
  obj.innerHTML = para["str"];
}

