function check_email(email){
	if(!/^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test(email)){
		return false;
	}else{
		return true;
	}
}
function getNameVal(name){
	
	var nameval = $("input[name='"+name+"']:checked").val();
	if(nameval==undefined || nameval==''){
		return '';
	}
	return nameval;
}
function getSelectTxt(name)
{
	var text = $("select[name='"+name+"']").find("option:selected").text();
	return text
}
function getNowTime(){
	var now= new Date();   
	var year=now.getYear();   
	var month=now.getMonth()+1;   
	var day=now.getDate();   
	var hour=now.getHours();   
	var minute=now.getMinutes();   
	var second=now.getSeconds();   
	var nowdate=year+""+month+""+day+""+hour+""+minute+""+second;   
	return nowdate;
}
$('.checkall').click(function(){
    $('.checkitem').attr('checked', this.checked);
});

function checkAllBox(e){
	if($(e).attr('checked')==true){
	
		$('.checkitem').attr('checked','checked');
	}else{
		$('.checkitem').attr('checked','');
	}
}
function checkAll(){
	$('.checkitem').attr('checked','checked');
	
}
function unCheckAll(){
	$('.checkitem').attr('checked','');
}
function getCheckItems(){
	if($('.checkitem:checked').length == 0){    //娌℃湁閫夋嫨
        return false;
    }
	var items = '';
    $('.checkitem:checked').each(function(){
        items += this.value + ',';
    });
    items = items.substr(0, (items.length - 1));
    return items;
}
function getHtml(url,id){
	$("#error").html('鍔犺浇涓�...');
	$.get(url+'/ts/'+getNowTime(),function(rs){			
		$("#"+id).html(rs);		
		$("#error").html('');		
	});
}
function getUrl(url,reload,cf,confirmMsg){
	if(cf==1){
		if(confirmMsg==undefined || confirmMsg==''){
			confirmMsg = '纭鍒犻櫎锛�';
		}
		if(!confirm(confirmMsg))
		{
			return false;
		}
	}
	$.get(url,function(rs){
		if(rs!=''){
			alert(rs);
		}
		if(reload==1){
			
				window.location.reload();
			
		}
		
	});
}
function errAlert(msg){
	$("body").append('<div id="displayss" style="display:none;width:100%;height:100px;left:0;right:0;top:30%;z-index:999999;position:fixed;" ></div>');
	var disinfo='<div id = "displayss_con" style="width:470px;height:200px;background:#ffffff;border:solid 3px #eeeeee;margin-left:auto;margin-right:auto;padding:10px"></div>';
	$("#displayss").html(disinfo);
	$("#displayss").show();
		
	$("#displayss_con").append('<a onclick="'+"hide('displayss');"+'" style="float:right;cursor: pointer">[鍏抽棴]</a><br>'+msg);
	
	
	
}
function hide(id){
	$("#"+id).hide();
}

function showAlert(title,type,msg){
	$("body").append('<div id="displays" style="display:none;z-index: 99999;" ></div>');
	var disinfo='<div id = "displays_con"><div id="displays_rs"><div id="displays_img"></div></div><div id="displays_msg"><span id="displays_msg_title"></span><br><span id="displays_msg_info"></span></div></div>';
	$("#displays").html(disinfo);
	$("#displays").slideUp(300).fadeIn("slow");
	$("#displays_img").addClass("displays_img_"+type);
	$("#displays_msg_title").addClass("displays_msg_title_"+type);	
	if(title!=undefined){
		$("#displays_msg_title").html(title);
	}
	if(msg!=undefined){
		$("#displays_msg_info").html(msg);
	}	
	
	$("#displays").delay(1500).fadeOut("slow");	
	
}
function showUrlInId(url,id,width,height){
	getHtml(url,id);	
	showWin(id,width,height);
}
function closeWin(){
	$.modal.close(); // must call this!	
}
function showWin(id,width,height){
	
	if(width==undefined || width==''){
		var width=400;
	}
	if(height==undefined || height==''){
		var height=200;
	}
	
	$("#"+id).modal({
		opacity:30,
		maxHeight:height,
		maxWidth: width,
		overlayClose:true,
		containerCss:{
		backgroundColor:"#ffffff",
		borderColor:"#bbbbbb"},		
		//overlayCss: {backgroundColor:"#fff"}
		
		onClose: function (dialog) {
			dialog.data.fadeOut('fast', function () {
				dialog.container.slideUp('fast', function () {
					dialog.overlay.fadeOut('fast', function () {
						$.modal.close(); // must call this!
						
					});
				});
			});
		}
		
	
		
	});
	
}
function showFrame(url,width,height){
	var src = url;
	$.modal('<iframe src="' + src + '" height="'+height+'" width="'+width+'" style="border:0">', {
		closeHTML:"",
		containerCss:{
			backgroundColor:"#fff",
			borderColor:"#fff",
			height:height,
			padding:0,
			width:width
		},
		overlayClose:true
	});

}
function del(e){
	
	var type=$(e).attr('del_type');
	if(type=='one'){
		var id =$(e).attr('delete_id');
			
	}else{
		var id = getCheckItems();
	}
	var back = $(e).attr('back');
	var back_id = $(e).attr('back_id');
	if(id!='' && id !=false){
		if(confirm('鎮ㄧ‘璁よ鍒犻櫎鍚�?'))
		{
			$(e).attr("disabled","disabled");
			$("#error").html('璇风◢鍊�...');
			var url = $(e).attr("url");
			$.post(url,{'id':id},function(rs){
				if(rs=='1'){
					showAlert('鍒犻櫎鎴愬姛','1');
					getHtml(back,back_id);
					
				}else{
					showAlert('鍒犻櫎澶辫触','0');
				}
				$(e).attr("disabled","");
				return false;
			})
		}else{
			return false;
		}
    }else{
    	return false;
    }
}
//鑾峰彇html鏂囦欢URL鍙傛暟
function getParameter(name,cancelBubble){
    var r = new RegExp("(\\?|#|&)"+name+"=([^&#]*)(&|#|$)");
    var m = location.href.match(r);
    //if ((!m || m=="") && !cancelBubble) m = top.location.href.match(r);
    return (!m?"":m[2]);
}
//鑾峰彇瀛楃闀垮害
function getLen( str) {
	var totallength=0;
	for (var i=0;i<str.length;i++)
	{
	//charCodeAt 杩斿洖涓€涓暣鏁帮紝鑾峰緱瀛楃鐨剈nicode缂栫爜
	var intCode=str.charCodeAt(i);
	if (intCode>=0&&intCode<=128) {//涓哄瓧绗︾殑缂栫爜鑼冨洿
	totallength=totallength+1;//闈炰腑鏂囧崟涓瓧绗﹂暱搴﹀姞1
	}
	else {
	totallength=totallength+2;//涓枃瀛楃闀垮害鍒欏姞2
	}
	}
	return totallength;
}
function tourl(url){
	window.location = url;
	
}
if(location.search!=''){
	var edit_url  = location.href+'&do=edit&ajax=1';
}else{
	var edit_url  = location.href+'?do=edit&ajax=1';
}
edit_url = edit_url.replace('index','modify');
var edit_td_status  = 0;
function edit_td(e,col,id){
	if(edit_td_status==0){
		edit_td_status = 1;
		var ihtml = $(e).html();	
		if($.trim(ihtml)=="" || $.trim(ihtml)=="&nbsp;&nbsp;"){
			var span_width = 100;
		}else{
			var span_width = e.scrollWidth+2;
		}
		$(e).hide();
		$(e).html('<input type="text" style="width:'+span_width+'px;" value="'+ihtml+'" id="'+col+id+'"  onblur = "edit_td_save(this,\''+col+'\',\''+id+'\',\''+ihtml+'\')"  onkeydown="if(event.keyCode==13) edit_td_save(this,\''+col+'\',\''+id+'\',\''+ihtml+'\');"/>');
		$(e).show('fast');
		$("#"+col+id).focus();
	} 
	
}
function edit_td_save(e,col,id,phtml)
{
	var inputValue = $.trim($(e).val());
	if(inputValue=="") {
		edit_td_status = 0;
		$(e.parentNode).html(phtml)
		return false;
	}
	
	if(inputValue==$.trim(phtml)) {		
		edit_td_status = 0;
		$(e.parentNode).html(phtml)
		return false;
	}
	var ihtml = $(e.parentNode).html();
	$(e.parentNode).html(inputValue)
	$.getJSON(edit_url,{'id':id,'col':col,'values':inputValue},function(rs){
		//showAlert(rs.html)
		showMsg(rs.html);
		
	})	
	edit_td_status = 0;
}

function orderBy(col,sc){	
	if(location.search!=''){
		var order_url  = location.href;
		var reg = /orderby=[\w+]*[-.]*[\w+]*/;
		if(!reg.test(order_url)){
			var new_order_url = order_url+"&orderby="+col;
		}else{
			var new_order_url = order_url.replace(reg,"orderby="+col);
		}		
		order_url = new_order_url;
		
		
		var reg2 = /sc=[\w+]*/;		
		if(!reg2.test(order_url)){
			var new_order_url_two = order_url+"&sc="+sc;
			order_url = new_order_url_two;
		}else{
			var new_order_url_two = order_url.replace(reg2,"sc="+sc);
			order_url = new_order_url_two;
		}		
		
	}else{
		var order_url  = location.href+'?orderby='+col+'&sc='+sc;		
	}
	window.location.href= order_url;
}
function GetQueryString(name) {

	   var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)","i");

	   var r = window.location.search.substr(1).match(reg);

	   if (r!=null) return unescape(r[2]); return null;

}
$(document).ready(function(){
	var orderby = GetQueryString('orderby');
	
	var sc = GetQueryString('sc');	
	if(orderby){
		var e = document.getElementById("order_"+orderby);
		var ehtml = e.innerHTML;
		if(sc=='ASC'){			
			
			e.innerHTML = ehtml+'鈫�';
			//append('鈫�')	
			e.onclick = function(){orderBy(orderby,'DESC')};
			
		}else{		
			//.e.append('鈫�');	
			e.innerHTML = ehtml+'鈫�';
			e.onclick = function(){orderBy(orderby,'ASC')};
		}
	}
})

function showMsg(msg){
	parent.$("#error").html(msg);
	setTimeout(function(e){parent.$("#error").html('');},2000);
}

function reload(){
	
	setTimeout(function(e){
		window.location.reload();
	},3000)
}
