function getitems(id)
{
   var text = ''
   var DATA = {"id":id}
   $.ajax({
          type: "POST",
          url: "/rekoo/getitems/",
          data: DATA,
          async :false,
          success: function(msg){
              text = msg;
              }
   }); 
   return text;
}

jQuery(document).ready(function($){
$(".ITEM").mouseover(function(e){
    Data = this.rel;
    this.myHref = this.href;
    this.myHref = (this.myHref.length > 30 ? this.myHref.toString().substring(0,30)+"..." : this.myHref);
    My = Data
    //alert(My);
    this.myTitle = getitems(My);
    var tooltip = "<div id='tooltip'><p>"+this.myTitle+"<em>"+this.myHref+"</em>"+"</p></div>";
    $('body').append(tooltip);
    $('#tooltip').css({"opacity":"0.8","top":(e.pageY+20)+"px","left":(e.pageX+10)+"px"}).show('fast');
}).mouseout(function(){$('#tooltip').remove();
}).mousemove(function(e){$('#tooltip').css({"top":(e.pageY+20)+"px","left":(e.pageX+10)+"px"});
});
 
});
