var attachname = "attach";
var i=1;
          function   addInput(){
            if(i>0){
                  var attach = attachname + i ;
                  if(createInput(attach))
                      i=i+1;
              }
              
          } 
          function deleteInput(){
                  if(i>1){
                    i=i-1;
                    if(!removeInput())
                        i=i+1;
                }
          } 
          
          function createInput(nm){   
              var  aElement=document.createElement("input");   
             aElement.name=nm;
             aElement.id=nm;
             aElement.type="file";
             aElement.size="50";
              //aElement.value="thanks";   
             //aElement.onclick=Function("asdf()");  
               if(document.getElementById("upload").appendChild(aElement) == null)
                      return false;
               return true;
          }  

          function removeInput(nm){
               var aElement = document.getElementById("upload");
                if(aElement.removeChild(aElement.lastChild) == null)
                    return false;
                return true;   
          }  
