#!/bin/sh
#2012-09-22

#test network
#ps -ef | grep -E 'system-init.sh' |grep -v grep && exit 1
SCRIPTPATH="$PWD"



############ set hostname ################
IDC_name=`cat /var/tmp/hostname`
IP_num=`ifconfig em1 | grep "Bcast" | awk '{print $2}' | awk -F":" '{print $2}' | grep -Ev '192.168.1|127.0.0.1' | sed 's/.*.\.//g' `sed -i "s#HOSTNAME=.*#HOSTNAME=${IDC_name}-${IP_num}#"  /etc/sysconfig/network


echo "nameserver 114.114.114.114 >> /etc/resolv.conf"



funbase () {

##############set ntp#####################
yum makecache
yum clean all
yum repolist
yum -y install rdate dmidecode bind-utils* OpenIPMI*  ipmi* net-snmp mysql vim gcc make openssh-clients setuptool strace sysstat iotop rsync wget dos2unix dmidecode iotop python-setuptools python-simplejson MySQL-python python-devel lrzsz dmidecode
yum -y update glibc\*
yum -y update yum\* rpm\* python\*


if [[ $? -ne 0 ]];then

    IPR=`cat /var/tmp/ipaddr`
    enddate=`date "+%Y-%m-%d %H:%M:%S"`
    mysql -homs.useus.cn -uinit_log -pinit_db_log -S /tmp/mysql.sock oms -e "update uxin_systeminit_log set text='22',enddate=\"${enddate}\" where ip=\"$IPR\" order by id desc limit 1" > /dev/null 2<&1

    exit 1111
                     
fi


echo "*/5 * * * * date >>  /var/log/ntpdate.log; /usr/sbin/ntpdate -u ntp.api.bz >> /var/log/ntpdate.log 2>&1;/sbin/hwclock -w" >> /tmp/cron
crontab < /tmp/cron
rm -rf /tmp/cron
service crond restart

########  set ipmi #######################
/etc/init.d/ipmi start
########  set snmp #######################

cat > /etc/snmp/snmpd.conf << EOF
com2sec notConfigUser  default     useus.cn@2015
group   notConfigGroup v1           notConfigUser
group   notConfigGroup v2c           notConfigUser
view    systemview    included   .1.3.6.1.2.1.1
view    systemview    included   .1.3.6.1.2.1.25.1.1
access  notConfigGroup ""      any       noauth    exact  all none none
view all    included  .1                               80
syslocation Unknown (edit /etc/snmp/snmpd.conf)
syscontact Root <root@localhost> (configure /etc/snmp/snmp.local.conf)
EOF


#close snmpd log
sed -i 's#OPTIONS="-LS.*$#OPTIONS="-LS3d -Lf /dev/null -p /var/run/snmpd.pid"#g'   /etc/init.d/snmpd
/etc/init.d/snmpd restart
chkconfig snmpd on


################################################
#histsize
sed -i 's@HISTSIZE=[0-9]*@HISTSIZE=2000@' /etc/profile
source /etc/profile

#Close atime
sed -i  '/data/s@defaults @defaults,noatime,nodiratime@'  /etc/fstab

################   vim  ########################
sed -i "8 s/^/alias vi='vim'/" /root/.bashrc
echo 'syntax on' > /root/.vimrc


################set purview#####################
chmod -R 700 /etc/rc.d/init.d/* 
chmod 600 /etc/shadow
chmod 600 /etc/gshadow


################disable selinux#################
sed -i '/SELINUX/s/enforcing/disabled/' /etc/selinux/config 


################   ssh  ########################
ssh_cf="/etc/ssh/sshd_config" 

###set 60010####
sed -i 's/.*Port .*/Port 60010/' $ssh_cf
sed -i 's@.*ermitRootLogin .*@PermitRootLogin no@' $ssh_cf

###set 60012####
cat /etc/ssh/sshd_config > /etc/ssh/sshd_config-sec

sed -i -e 's@Port 60010@Port 60012@' -e 's@PermitRootLogin no@PermitRootLogin yes@' /etc/ssh/sshd_config-sec

#grep '/usr/sbin/sshd -f /etc/ssh/sshd_config-sec' /etc/rc.local || echo "/usr/sbin/sshd -f /etc/ssh/sshd_config-sec" >> /etc/rc.local

grep '/usr/sbin/sshd -f /etc/ssh/sshd_config-sec' /etc/init.d/sshd || sed -i "/esac/a\/usr/sbin/sshd -f /etc/ssh/sshd_config-sec" /etc/init.d/sshd

#��ssh��
sed -i "s/#UseDNS yes/UseDNS no/" /etc/ssh/sshd_confi* 
sed -i "s#GSSAPIAuthentication yes#GSSAPIAuthentication no#g" /etc/ssh/sshd_confi*

###set tcp_wrappers ###
##/etc/hosts.allow##
echo 'sshd:ALL' > /etc/hosts.allow

###    hosts.deny   ###
echo "#sshd:all:deny" > /etc/hosts.deny
grep '/usr/sbin/sshd -f /etc/ssh/sshd_config-sec' /etc/init.d/sshd || sed -i "/esac/a\/usr/sbin/sshd -f /etc/ssh/sshd_config-sec" /etc/init.d/sshd
/etc/init.d/sshd restart

echo "ssh is init is ok.............."

#########add manager user######################

	awk -F ':' '{print $1}' /etc/group | grep -wq maintain
        if [[ $? -ne 0 ]];then
			useradd -o -u 0 -g 0 -d /root maintain && echo "useus#@!_mt2015" | passwd --stdin "maintain"
        fi
	awk -F ':' '{print $1}' /etc/group |grep -wq dev || groupadd dev
        awk -F ':' '{print $1}' /etc/group |grep -wq useus  || groupadd useus

        for i in wanglong
                do
                        awk -F ':' '{print $1}' /etc/passwd | grep -wq $i
                        if [[ $? -ne 0 ]];then
                            useradd $i;usermod -G useus,wheel,dev $i; echo "useus.cn" | passwd --stdin "$i" ; chage -d 0 $i
                        fi
                done

	echo "useus.cn" | passwd --stdin "root"
	echo "useus#@!_mt2015" | passwd --stdin "maintain"



###############################################
	sed -i '/so use_uid/s#\#auth#auth#' /etc/pam.d/su

	grep -q '%dev' /etc/sudoers || echo '%dev             ALL=(ALL)       ALL' >> /etc/sudoers

	grep -q 'source /etc/profile' /etc/bashrc  || echo 'source /etc/profile' >> /etc/bashrc

	mkdir -p /data/audit
	touch /data/audit/audit.log || chattr -a /data/audit/audit.log
	chown nobody:nobody /data/audit/audit.log
	chmod 006 /data/audit/audit.log

sed -i '/export HISTTIMEFORMAT' -e '/export HISTORY_FILE/d' -e '/export logfromat/d' -e '/export HISTTIMEFORMAT/d' -e '/export PROMPT_COMMAND/d' /etc/profile > /dev/null 2<&1
sed -i '/export HISTTIMEFORMAT' -e '/export HISTORY_FILE/d' -e '/export logfromat/d' -e '/export HISTTIMEFORMAT/d' -e '/export PROMPT_COMMAND/d' /etc/bashrc > /dev/null 2<&1

chmod 006 /data/audit/audit.log
chattr +a /data/audit/audit.log



chattr +i /usr/bin/mysql

cat >> /etc/bashrc <<\EOF

export HISTTIMEFORMAT="`whoami`:%Y/%m/%d-%H:%M:%S  ";export HISTTIMEFORMAT
export HISTORY_FILE=/data/audit/audit.log
export logfromat=`who -u am i|awk '{printf("%s%sPID[%s]#[LOGIN:%s %s]",$1,$7,$6,$3,$4)}'|tr '/' '-' |tr '(' '@' |tr ')' '|'|tr '-' '/'`;export logfromat
export histfilepid=`who -u m i|cut -d . -f2 | sed -e 's# ##g' -e 's#(##g'`;export logfromat
export PROMPT_COMMAND='{ thisHistID=`history 1|awk "{print \\$1}"`;lastCommand=`history 1| awk "{\\$1=\"\" ;print}"`;user=`id -un`;if [ ${thisHistID}x != ${lastHistID}x ];then echo -E `date "+%Y/%m/%d %H:%M:%S"` ${user}\#\#${logfromat} --- $lastCommand ;lastHistID=$thisHistID;fi; } | tee -a > /dev/null $HISTORY_FILE > /var/tmp/${histfilepid}.txt;\cp /var/tmp/inserthistory.sh /var/tmp/${histfilepid}.sh;sh /var/tmp/${histfilepid}.sh'

EOF

cat > /var/tmp/inserthistory.sh <<\EOFEOF
#!/bin/bash

FILEPH="/var/tmp"
BASICINFO=($(awk -F'#| |@|\\[|\\||\\]|LOGIN:' '{OFS="\n"}{print $5,$6,$11$12"-"$13,$8,$3,$1"-"$2}' $FILEPH/${histfilepid}.txt))
STARTTIME=`awk -F' --- ' '{print $2}' $FILEPH/${histfilepid}.txt | awk '{print $1}' | cut -d : -f2-`
SERVERIP=`/sbin/ifconfig | grep "Bcast" | awk '{print $2}' | awk -F":" '{print $2}' | grep -Ev '192.168.1|192.168.0|127.0.0.1'`
FAILPIDTIME="${histfilepid}-`date +%s%N`"
sqlwrite=0

test -z $BASICINFO && exit 1

HISTORYEXEDIFF=`tail -2 /data/audit/audit.log |head -1 | awk '{ for(i=1;i<=6;i++){$i=""}; print $0 }' | sed 's#^[[:space:]]*##' |sed -e "s#'#\"#g"`

HISTORYEXE=`awk '{ for(i=1;i<=6;i++){$i=""}; print $0 }' $FILEPH/${histfilepid}.txt | sed 's#^[[:space:]]*##' | sed -e "s#'#\"#g"`

if [ "$HISTORYEXEDIFF"x = "${HISTORYEXE}"x ];then
        rm -rf $FILEPH/${histfilepid}.sql
        rm -rf $FILEPH/${histfilepid}.txt
        rm $0
        exit 0
fi

cat > $FILEPH/${histfilepid}.sql << EOF
insert into notes(SERVER_IP, LOGIN_NAME, LOGIN_IP, LOGIN_TIME, LOGIN_PID, EXE_USER, EXE_PATH, EXE_STARTTIME, EXE_ENDTIME, Message) values('$SERVERIP','${BASICINFO[0]}','${BASICINFO[1]}','${BASICINFO[2]}','${BASICINFO[3]}','${BASICINFO[4]}','$PWD','$STARTTIME','${BASICINFO[5]}','${HISTORYEXE}   ');
EOF
chmod o+w $FILEPH/${histfilepid}.sql
mysql -h121.40.28.209 -uuser_log -puser_db_log -S /tmp/mysql.sock Syslog < $FILEPH/${histfilepid}.sql > /dev/null 2<&1

if [[ $? -ne 0 ]];then
        cp $FILEPH/${histfilepid}.sql $FILEPH/${FAILPIDTIME}.sql
        sqlwrite=1
else
        rm -rf $FILEPH/${histfilepid}.sql
        rm -rf $FILEPH/${histfilepid}.txt
fi

rm $0

failwrite () {
if [[ ${sqlwrite} -eq 1 ]];then
        EXENUM=1
        while(($EXENUM<1000))
        do
                mysql -h121.40.28.209 -uuser_log -puser_db_log -S /tmp/mysql.sock Syslog < $FILEPH/${FAILPIDTIME}.sql > /dev/null 2<&1
                if [[ $? -eq 0 ]];then
        #               write="0"
                        rm -rf $FILEPH/${FAILPIDTIME}.sql
                        exit 0
                else
                          EXENUM=$(($EXENUM+1))
                fi
                sleep 10
        done
fi
}
failwrite &
EOFEOF



	source /etc/profile

###############  set sysctl ###################
true > /etc/sysctl.conf
cat >> /etc/sysctl.conf << EOF
net.ipv4.ip_forward = 1
net.ipv4.conf.default.rp_filter = 1
net.ipv4.conf.default.accept_source_route = 0
kernel.sysrq = 0
kernel.core_uses_pid = 1
net.ipv6.conf.all.disable_ipv6 = 1
net.ipv4.tcp_syncookies = 1
net.ipv4.ip_local_port_range = 1024 65535
net.core.rmem_max=16777216
net.core.wmem_max=16777216
net.ipv4.tcp_rmem=4096 87380 16777216
net.ipv4.tcp_wmem=4096 65536 16777216
kernel.shmall = 4294967296
net.ipv4.tcp_fin_timeout = 10
net.ipv4.tcp_tw_recycle = 1
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_timestamps = 0
net.ipv4.tcp_window_scaling = 0
net.ipv4.tcp_sack = 0
net.core.netdev_max_backlog = 30000
net.ipv4.tcp_no_metrics_save=1
net.core.somaxconn = 262144
net.ipv4.tcp_max_orphans = 262144
net.ipv4.tcp_max_syn_backlog = 262144
net.ipv4.tcp_synack_retries = 2
net.ipv4.tcp_syn_retries = 2
net.ipv4.tcp_keepalive_time=1800
net.nf_conntrack_max = 6553600
EOF

/sbin/sysctl -p
echo "sysctl set OK!"

############### services #################
for i in `ls /etc/rc3.d/S*`
do
              SERVER=`echo $i|cut -c 15-`
echo $SERVER
case $SERVER in
          crond | network | sshd | rsyslog | syslog | sysstat |messagebus | local | snmpd |php-fpm | nginx | mysql | tomcat )
      echo "Skip..........!"
      ;;
      *)
          chkconfig --level 235 $SERVER off
          service $SERVER stop
      ;;
esac
done

}


########redhat 6.  #######################

funredhat6 () {

#set yum #
cd /etc/yum.repos.d
#mv CentOS-Base.repo  CentOS-Base.repo.bak
#yum makecache
#yum clean all
#yum repolist
#
#yum -y update glibc\*
#yum -y update yum\* rpm\* python\*
#yum -y install vim gcc make openssh-clients setuptool strace sysstat iotop rsync wget dos2unix dmidecode iotop python-setuptools python-simplejson MySQL-python python-devel lrzsz dmidecode
#easy_install apns flask cherrypy dbutils apscheduler httplib2 lsof strace

#disable ipv6#
grep 'net-pf-10 off' /etc/modprobe.d/dist.conf || echo "alias net-pf-10 off" >> /etc/modprobe.d/dist.conf 
grep 'ipv6 off' /etc/modprobe.d/dist.conf || echo "alias ipv6 off" >> /etc/modprobe.d/dist.conf 
/sbin/chkconfig --level 35 ip6tables off
echo "ipv6 is disabled!"

#close ctrl+alt+del#

sed -i 's/^/#/' /etc/init/control-alt-delete.conf

#############set ulimit########################
cat > /etc/security/limits.conf << EOF
*       soft nofile 65535
*       hard nofile 65535
root   soft    nproc   65535
root   soft    nproc   65535
mysql   hard    nproc   65535
mysql   hard    nproc   65535
EOF


cat > /etc/security/limits.d/90-nproc.conf << EOF
*       soft nofile 65535
*       hard nofile 65535
root   soft    nproc   65535
root   soft    nproc   65535
mysql   hard    nproc   65535
mysql   hard    nproc   65535
EOF

cat > /etc/rsyslog.conf <<\EOF
$ModLoad imuxsock.so    # provides support for local system logging (e.g. via logger command)
$ModLoad imklog.so      # provides kernel logging support (previously done by rklogd)
$ActionFileDefaultTemplate RSYSLOG_TraditionalFileFormat
*.info;mail.none;authpriv.none;cron.none                /var/log/messages
authpriv.*                                              /var/log/secure
mail.*                                                  -/var/log/maillog
cron.*                                                  /var/log/cron
*.emerg                                                 *
uucp,news.crit                                          /var/log/spooler
# Save boot messages also to boot.log
local7.*                                                /var/log/boot.log
:rawmsg, contains, "/usr/local/sbin/opensips" ~
:rawmsg, contains, "rtpp_checkmedia_timeo_handle@rtpp_main.c" ~
:rawmsg, contains, "Connection from UDP:" ~
:rawmsg, contains, "warning: /etc/hosts.allow," ~
:rawmsg, contains, "Received SNMP packet(s) from UDP:" ~
:rawmsg, contains, "RCB online active call num:0" ~
:rawmsg, contains, "disconnect from localhost.localdomain" ~
:rawmsg, contains, "lost connection after RSET from localhost.localdomain" ~
:rawmsg, contains, "warning: localhost.localdomain" ~
:rawmsg, contains, "connect from localhost.localdomain" ~
:rawmsg, contains, "the node i_dport:" ~
:rawmsg, contains, "HM_hold_timer_proc@HM.c." ~
:rawmsg, contains, "HM_TPRelMsgPrc@HM.c." ~
:rawmsg, contains, "HM_recCBRequest@HM.c." ~
:rawmsg, contains, "HM_alloc_obj@HM.c." ~
:rawmsg, contains, "HM_recCBRequest@HM.c." ~
:rawmsg, contains, "OSAL_moduleStatisticsShow@OSAL_mi.c." ~
:rawmsg, contains, "HM_calc_rps@HM" ~
:rawmsg, contains, "HM_sendCalleeBToBcp@HM.c" ~
:rawmsg, contains, "PM_msgHandler@PM_client.c" ~

*.* @121.40.28.209:514
EOF

###change 6.3 network name em to eth ##

ifconfig | grep -q '^em'
if [[ $? -eq "0" ]];then
KERNELLINE=`cat -n /boot/grub/grub.conf | grep  'kernel'  | grep 'UUID' | awk '{print $1}'`

#20141104 IPMI
grep -q 'T0:23:respawn:/sbin/getty -L ttyS1 115200n8 vt100' /etc/inittab || echo "T0:23:respawn:/sbin/getty -L ttyS1 115200n8 vt100" >> /etc/inittab 
sed -i -e  's#^hiddenmenu#\#hiddenmenu#g' -e 's#^splashimage#\#splashimage#g' /boot/grub/grub.conf

cat >  /etc/init/ttyS1.conf <<\IPMICONFIG
# ttyS1 - agetty
#
# This service maintains a agetty on ttyS1.
stop on runlevel [S016]
start on runlevel [23]
respawn
exec agetty /dev/ttyS1 115200n8 vt102
IPMICONFIG

grep -q 'ttyS1' /etc/securetty  || echo "ttyS1" >> /etc/securetty

#20141104 �����
for i in $KERNELLINE ;do sed -n ${i}p /boot/grub/grub.conf | grep -q 'biosdevname=0 console=ttyS1,115200n8 console=tty0'   || sed -i ""$i"s/$/ biosdevname=0 console=ttyS1,115200n8 console=tty0/" /boot/grub/grub.conf ; done

rm -f /etc/udev/rules.d/70-persistent-net.rules
mv /etc/sysconfig/network-scripts/ifcfg-em1 /etc/sysconfig/network-scripts/ifcfg-eth0 > /dev/null 2<&1
mv /etc/sysconfig/network-scripts/ifcfg-em2 /etc/sysconfig/network-scripts/ifcfg-eth1 > /dev/null 2<&1
sed -i 's/em1/eth0/g' /etc/sysconfig/network-scripts/ifcfg-eth0 > /dev/null 2<&1
sed -i 's/em2/eth1/g' /etc/sysconfig/network-scripts/ifcfg-eth1 > /dev/null 2<&1

else

KERNELLINE=`cat -n /boot/grub/grub.conf | grep  'kernel'  | grep 'UUID' | awk '{print $1}'`
#20141104 IPMI
grep -q 'T0:23:respawn:/sbin/getty -L ttyS1 115200n8 vt100' /etc/inittab || echo "T0:23:respawn:/sbin/getty -L ttyS1 115200n8 vt100" >> /etc/inittab
sed -i -e  's#^hiddenmenu#\#hiddenmenu#g' -e 's#^splashimage#\#splashimage#g' /boot/grub/grub.conf

cat >  /etc/init/ttyS1.conf <<\IPMICONFIG
# ttyS1 - agetty
#
# This service maintains a agetty on ttyS1.
stop on runlevel [S016]
start on runlevel [23]
respawn
exec agetty /dev/ttyS1 115200n8 vt102
IPMICONFIG

grep -q 'ttyS1' /etc/securetty  || echo "ttyS1" >> /etc/securetty

for i in $KERNELLINE ;do sed -n ${i}p /boot/grub/grub.conf | grep -q 'biosdevname=0 console=ttyS1,115200n8 console=tty0'   || sed -i ""$i"s/$/ biosdevname=0 console=ttyS1,115200n8 console=tty0/" /boot/grub/grub.conf ; done
fi
######################################

#run base
funbase

}


######## redhat 5.########################

funredhat5 () {

#set yum #
cd /etc/yum.repos.d

yum clean all
yum repolist
#mv CentOS-Base.repo  CentOS-Base.repo.bak
yum makecache

yum -y update glibc\*
yum -y update yum\* rpm\* python\*
yum -y install vim gcc make openssh-clients setuptool strace sysstat iotop rsync wget dos2unix dmidecode iotop python-setuptools python-simplejson MySQL-python python-devel lrzsz dmidecode telnet expect


#disable ipv6#
grep 'net-pf-10 off' /etc/modprobe.conf ||echo "alias net-pf-10 off" >> /etc/modprobe.conf
grep 'ipv6 off' /etc/modprobe.conf ||echo "alias ipv6 off" >> /etc/modprobe.conf
/sbin/chkconfig --level 35 ip6tables off
echo "ipv6 is disabled!"

#syslog
cat > /etc/syslog.conf <<\EOF
*.info;mail.none;authpriv.none;cron.none                /var/log/messages
authpriv.*                                              /var/log/secure
mail.*                                                  -/var/log/maillog
cron.*                                                  /var/log/cron
*.emerg                                                 *
uucp,news.crit                                          /var/log/spooler
local7.*                                                /var/log/boot.log
*.debug                                                 /var/log/authdebug
:rawmsg, contains, "/usr/local/sbin/opensips" ~
:rawmsg, contains, "rtpp_checkmedia_timeo_handle@rtpp_main.c" ~
:rawmsg, contains, "Connection from UDP:" ~
:rawmsg, contains, "warning: /etc/hosts.allow," ~
:rawmsg, contains, "Received SNMP packet(s) from UDP:" ~
:rawmsg, contains, "RCB online active call num:0" ~
:rawmsg, contains, "disconnect from localhost.localdomain" ~
:rawmsg, contains, "lost connection after RSET from localhost.localdomain" ~
:rawmsg, contains, "warning: localhost.localdomain" ~
:rawmsg, contains, "connect from localhost.localdomain" ~
:rawmsg, contains, "the node i_dport:" ~
:rawmsg, contains, "HM_hold_timer_proc@HM.c." ~
:rawmsg, contains, "HM_TPRelMsgPrc@HM.c." ~
:rawmsg, contains, "HM_recCBRequest@HM.c." ~
:rawmsg, contains, "HM_alloc_obj@HM.c." ~
:rawmsg, contains, "HM_recCBRequest@HM.c." ~
:rawmsg, contains, "OSAL_moduleStatisticsShow@OSAL_mi.c." ~
*.*                             @121.40.28.209
EOF

#close ctrl+alt+del#
sed -i "s/ca::ctrlaltdel:\/sbin\/shutdown -t3 -r now/#ca::ctrlaltdel:\/sbin\/shutdown -t3 -r now/" /etc/inittab

#############set ulimit########################
cat > /etc/security/limits.conf << EOF
*       soft nofile 65535
*       hard nofile 65535
root   soft    nproc   65535
root   soft    nproc   65535
mysql   hard    nproc   65535
mysql   hard    nproc   65535
EOF



#run funbase
funbase

}


###########################################
###########################################

VERSIONS=`cat /etc/issue | grep "6\."`
cd /etc/yum.repos.d
#mv CentOS-Base.repo  CentOS-Base.repo.bak

#yum�?63
cat > /etc/yum.repos.d/WYI.repo <<\WYI
[base]
name=CentOS-$releasever - Base - 163.com
baseurl=http://mirrors.163.com/centos/$releasever/os/$basearch/
#mirrorlist=http://mirrorlist.centos.org/?release=$releasever&arch=$basearch&repo=os
gpgcheck=1
gpgkey=http://mirror.centos.org/centos/RPM-GPG-KEY-CentOS-6

#released updates 
[updates]
name=CentOS-$releasever - Updates - 163.com
baseurl=http://mirrors.163.com/centos/$releasever/updates/$basearch/
#mirrorlist=http://mirrorlist.centos.org/?release=$releasever&arch=$basearch&repo=updates
gpgcheck=1
gpgkey=http://mirror.centos.org/centos/RPM-GPG-KEY-CentOS-6

#additional packages that may be useful
[extras]
name=CentOS-$releasever - Extras - 163.com
baseurl=http://mirrors.163.com/centos/$releasever/extras/$basearch/
#mirrorlist=http://mirrorlist.centos.org/?release=$releasever&arch=$basearch&repo=extras
gpgcheck=1
gpgkey=http://mirror.centos.org/centos/RPM-GPG-KEY-CentOS-6

#additional packages that extend functionality of existing packages
[centosplus]
name=CentOS-$releasever - Plus - 163.com
baseurl=http://mirrors.163.com/centos/$releasever/centosplus/$basearch/
#mirrorlist=http://mirrorlist.centos.org/?release=$releasever&arch=$basearch&repo=centosplus
gpgcheck=1
enabled=0
gpgkey=http://mirror.centos.org/centos/RPM-GPG-KEY-CentOS-6

#contrib - packages by Centos Users
[contrib]
name=CentOS-$releasever - Contrib - 163.com
baseurl=http://mirrors.163.com/centos/$releasever/contrib/$basearch/
#mirrorlist=http://mirrorlist.centos.org/?release=$releasever&arch=$basearch&repo=contrib
gpgcheck=1
enabled=0
gpgkey=http://mirror.centos.org/centos/RPM-GPG-KEY-CentOS-6
WYI


#备用yum�?清华
cat > /etc/yum.repos.d/TSINGHUA.repo <<\REPO
[base]
name=CentOS-$releasever - Base
baseurl=http://mirrors.tuna.tsinghua.edu.cn/centos/$releasever/os/$basearch/
gpgcheck=0

[updates]
name=CentOS-$releasever - Updates
baseurl=http://mirrors.tuna.tsinghua.edu.cn/centos/$releasever/updates/$basearch/
gpgcheck=0

#additional packages that may be useful
[extras]
name=CentOS-$releasever - Extras
baseurl=http://mirrors.tuna.tsinghua.edu.cn/centos/$releasever/extras/$basearch/
gpgcheck=0

#additional packages that extend functionality of existing packages
[centosplus]
name=CentOS-$releasever - Plus
baseurl=http://mirrors.tuna.tsinghua.edu.cn/centos/$releasever/centosplus/$basearch/
gpgcheck=0
enabled=0

#contrib - packages by Centos Users
[contrib]
name=CentOS-$releasever - Contrib
baseurl=http://mirrors.tuna.tsinghua.edu.cn/centos/$releasever/contrib/$basearch/
gpgcheck=0
enabled=0
REPO


yum -y install  iotop  > /dev/null 2<&1 
if [[ $? -ne "0" ]];then
        echo "YUM install Error, Please Check"
        exit 1
fi

if [[ ${VERSIONS} = "" ]];then
        funredhat5 > /var/log/system-init.log 2<&1
else
        funredhat6  > /var/log/system-init.log 2<&1
fi

echo "service is init is ok.............."

#��OPENSSL��
openssl version | grep -q '1.0.2d'
if [[ $? -ne 0 ]];then
cd /usr/local/src/
wget http://www.openssl.org/source/openssl-1.0.2d.tar.gz
tar xvf openssl-1.0.2d.tar.gz
cd openssl-1.0.2d
./config
make && make install
#backup old openssl
mv /usr/bin/openssl /usr/bin/openssl.OLD

#backup old openssl include
mv /usr/include/openssl /usr/include/openssl.OLD

#link new openssl
ln -s /usr/local/ssl/bin/openssl /usr/bin/openssl
ln -s /usr/local/ssl/include/openssl /usr/include/openssl
echo "/usr/local/openssl/lib" >> /etc/ld.so.conf
ldconfig -v
/data/soft/nginx/sbin/nginx -s reload
fi

rm -rf /tmp/oms-init.s*

IPR=`cat /var/tmp/ipaddr`
enddate=`date "+%Y-%m-%d %H:%M:%S"`
mysql -homs.useus.cn -uinit_log -pinit_db_log -S /tmp/mysql.sock oms -e "update uxin_systeminit_log set text='0',enddate=\"${enddate}\" where ip=\"$IPR\" order by id desc limit 1" > /dev/null 2<&1
#reboot
