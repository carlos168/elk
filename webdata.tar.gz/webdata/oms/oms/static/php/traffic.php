<HTML> 
<HEAD> 
<meta http-equiv="refresh" content="60">

<style type="text/css">
img {
width: 460;
Height: 200;
}
</style>
</HEAD> 
<style type="text/css"> 
.STYLE18 {text-decoration: none; font-size: 20px; font-color red;font-weight:bold;}
</style>


<BODY  bgcolor="#ffffff" text="#000000" link="#000000" vlink="#000000" alink="#000000"> 
<H1 align="center" style="color:red;"> 流量监控</H1> 
 <table width="1024" border="1" align="center" cellspacing="1" bordercolor="#666666" bgcolor="#FFFFFF"> 
  <tr> 
    <td width="1032" valign="bottom"><table width="100%" border="1" cellspacing="0" bordercolor="#FFFFFF" bgcolor="#CCCCCC">
      <tr>
        <td width="50" height="40" align="center"><span class="STYLE18"><a href="TJHY.php" target="">天津华苑</a></span></td>
        <td width="50" height="40" align="center"><span class="STYLE18"><a href="BJZWQ.php" target="">北京兆维(前景世纪)</a></span></td>
        <td width="50" height="40" align="center"><span class="STYLE18"><a href="BJZWH.php" target="">北京兆维(互联通)</a></span></td>
        <td width="50" height="40" align="center"><span class="STYLE18"><a href="GZ.php" target="">广州</a></span></td>
        <td width="50" height="40" align="center"><span class="STYLE18"><a href="SX.php" target="">三线(无锡 武汉 成都)</a></span></td>
        <td width="50" height="40" align="center"><span class="STYLE18"><a href="HKUSA.php" target="">香港 美国</a></span></td>
      </tr>
    </td>
</tr> 
</table>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 
<TABLE border=1  bgcolor="#FFFFFF" align="center">
<tr bgcolor="#FFFFF">
<td><DIV align="center"><B>IDC总流量</B></DIV>
<DIV><A HREF="/cacti/graph.php?action=view&amp;local_graph_id=4707&amp;rra_id=all"><IMG BORDER=1 SRC="/cacti/graph_image.php?local_graph_id=4707&amp;rra_id=0&amp;view_type=tree&amp;graph_start=<?php print time()-86400;?>&amp;graph_end=<?php print time();?>" ></A><BR>
<SMALL></SMALL></DIV>
</td>
<td><DIV align="center"><B>天津华苑总流量</B></DIV>
<DIV><A HREF="/cacti/graph.php?action=view&amp;local_graph_id=3389&amp;rra_id=all"><IMG BORDER=1 SRC="/cacti/graph_image.php?local_graph_id=3389&amp;rra_id=0&amp;view_type=tree&amp;graph_start=<?php print time()-86400;?>&amp;graph_end=<?php print time();?>" ></A><BR>
<SMALL></SMALL></DIV>
</td>
<td><DIV align="center"><B>北京机房(互联通)总流量</B></DIV>
<DIV><A HREF="/cacti/graph.php?action=view&amp;local_graph_id=4708&amp;rra_id=all"><IMG BORDER=1 SRC="/cacti/graph_image.php?local_graph_id=4708&amp;rra_id=0&amp;view_type=tree&amp;graph_start=<?php print time()-86400;?>&amp;graph_end=<?php print time();?>" ></A><BR>
<SMALL></SMALL></DIV>
</td>
</tr>
</TABLE>

<TABLE border=1  bgcolor="#FFFFFF" align="center">
<tr bgcolor="#FFFFF">
<td><DIV align="center"><B>无锡机房总流量</B></DIV>
<DIV><A HREF="/cacti/graph.php?action=view&amp;local_graph_id=4601&amp;rra_id=all"><IMG BORDER=1 SRC="/cacti/graph_image.php?local_graph_id=4601&amp;rra_id=0&amp;view_type=tree&amp;graph_start=<?php print time()-86400;?>&amp;graph_end=<?php print time();?>" ></A><BR>
<SMALL></SMALL></DIV>
</td>
<td><DIV align="center"><B>成都机房总流量</B></DIV>
<DIV><A HREF="/cacti/graph.php?action=view&amp;local_graph_id=4347&amp;rra_id=all"><IMG BORDER=1 SRC="/cacti/graph_image.php?local_graph_id=4347&amp;rra_id=0&amp;view_type=tree&amp;graph_start=<?php print time()-86400;?>&amp;graph_end=<?php print time();?>" ></A><BR>
<SMALL></SMALL></DIV>
</td>
<td><DIV align="center"><B>广州科学城机房总流量</B></DIV>
<DIV><A HREF="/cacti/graph.php?action=view&amp;local_graph_id=3410&amp;rra_id=all"><IMG BORDER=1 SRC="/cacti/graph_image.php?local_graph_id=3410&amp;rra_id=0&amp;view_type=tree&amp;graph_s
tart=<?php print time()-86400;?>&amp;graph_end=<?php print time();?>" ></A><BR><SMALL></SMALL></DIV>
</td>
</tr>
</TABLE>

<TABLE border=1  bgcolor="#FFFFFF" align="center">
<tr bgcolor="#FFFFF">
<td><DIV align="center"><B>有信业务流量</B></DIV>
<DIV><A HREF="/cacti/graph.php?action=view&amp;local_graph_id=3232&amp;rra_id=all"><IMG BORDER=1 SRC="/cacti/graph_image.php?local_graph_id=3232&amp;rra_id=0&amp;view_type=tree&amp;graph_start=<?php print time()-86400;?>&amp;graph_end=<?php print time();?>" ></A><BR><SMALL></SMALL></DIV>
</td>
<!--<td><DIV align="center"><B>KC业务流量</B></DIV>
<DIV><A HREF="/cacti/graph.php?action=view&amp;local_graph_id=4695&amp;rra_id=all"><IMG BORDER=1 SRC="/cacti/graph_image.php?local_graph_id=4695&amp;rra_id=0&amp;view_type=tree&amp;graph_start=<?php print time()-86400;?>&amp;graph_end=<?php print time();?>" ></A><BR>
<SMALL></SMALL></DIV>
</td>
<td><DIV align="center"><B>UU业务流量</B></DIV>
<DIV><A HREF="/cacti/graph.php?action=view&amp;local_graph_id=4697&amp;rra_id=all"><IMG BORDER=1 SRC="/cacti/graph_image.php?local_graph_id=4697&amp;rra_id=0&amp;view_type=tree&amp;graph_s
tart=<?php print time()-86400;?>&amp;graph_end=<?php print time();?>" ></A><BR><SMALL></SMALL></DIV>
</td>

</tr>
</TABLE>

<TABLE border=1  bgcolor="#FFFFFF" align="left">
<tr bgcolor="#FFFFF">-->
<td><DIV align="center"><B>终端业务流量</B></DIV>
<DIV><A HREF="/cacti/graph.php?action=view&amp;local_graph_id=4698&amp;rra_id=all"><IMG BORDER=1 SRC="/cacti/graph_image.php?local_graph_id=4698&amp;rra_id=0&amp;view_type=tree&amp;graph_start=<?php print time()-86400;?>&amp;graph_end=<?php print time();?>" ></A><BR><SMALL></SMALL></DIV>
</td>
<td><DIV align="center"><B>统一平台流量</B></DIV>
<DIV><A HREF="/cacti/graph.php?action=view&amp;local_graph_id=4699&amp;rra_id=all"><IMG BORDER=1 SRC="/cacti/graph_image.php?local_graph_id=4699&amp;rra_id=0&amp;view_type=tree&amp;graph_start=<?php print time()-86400;?>&amp;graph_end=<?php print time();?>" ></A><BR>
<SMALL></SMALL></DIV>
</td>
</tr>
</TABLE>
</BODY>
</HTML>
