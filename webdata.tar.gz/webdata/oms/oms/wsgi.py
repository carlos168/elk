import os
import sys

from site import addsitedir
from os.path import abspath, dirname, join
#from django.core.wsgi import get_wsgi_application

sys.path.insert(0, abspath(join(dirname(__file__), "..")))

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "oms.settings")
#os.environ['DJANGO_SETTINGS_MODULE'] = 'oms.settings'
import django.core.handlers.wsgi

#2.6python
application = django.core.handlers.wsgi.WSGIHandler()


#2.7python
#application = get_wsgi_application() 
